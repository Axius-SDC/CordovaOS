# Maritime Port Authority 4.4.0

**Model ID**: `dm-v42afzhs22bvschuo56rdpzi`
**Project**: Cordova
**Description**: Record all maritime operations, vessel movements, crew, cargo, and customs at Porto Sereno.

### Dublin Core Metadata
- **Subject**: Maritime Port Call
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal
- **Publisher**: Axius SDC, Inc.

## Package Contents

- `dm-v42afzhs22bvschuo56rdpzi.xsd` -- XML Schema Definition (data model structure)
- `dm-v42afzhs22bvschuo56rdpzi.xml` -- XML instance example with sample data
- `dm-v42afzhs22bvschuo56rdpzi-instance.json` -- JSON instance example (same structure as XML)
- `dm-v42afzhs22bvschuo56rdpzi.jsonld` -- JSON-LD semantic schema description
- `dm-v42afzhs22bvschuo56rdpzi.html` -- Human-readable model documentation
- `dm-v42afzhs22bvschuo56rdpzi_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-v42afzhs22bvschuo56rdpzi.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-v42afzhs22bvschuo56rdpzi.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-v42afzhs22bvschuo56rdpzi.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-v42afzhs22bvschuo56rdpzi.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **Maritime Governed Record** | Cluster | `wbo3dcvxu74dgnqugop9dv2m` | 1 components; 4 sub-cluster(s) |
|   Digital Signature Proof | XdFile | `gug5dhtqfv7exbgmm2raxpkq` | -- |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **Port Call Record** | Cluster | `rl0vow8jvafpkt9eph1mgkzh` | 3 components; 6 sub-cluster(s) |
|     Port Call ID | XdString | `pbfvurdvio38rt6puifhippe` | minLen=1; maxLen=50 |
|     Crew Count | XdCount | `p5qzw565y1dm5f3s6lg2q3ft` | units=Persons |
|     Passenger Count | XdCount | `x720xrlooqij75bk26pvzrtl` | units=Persons |
|     **Cargo Manifest** | Cluster | `n1t42tkwjrpukvnqog59mvh4` | 2 components; 1 sub-cluster(s) |
|       Business Registry Number | XdString | `l8f0m7op4xhrxqy1jrnvbuly` | exactLen=10; pattern=`BIZ-[0-9]{6}` |
|       Container Count | XdCount | `y5se2qd3r6xx6pz8t7d8cqvf` | units=Twenty-foot Equivalent Units (TEU) |
|       **Cargo** | Cluster | `xsp8yygkpibd6z8clfwrd4ad` | 20 components; 1 sub-cluster(s) |
|         Cargo Hazardous Material Indicator | XdBoolean | `dizybfusc6f6pzju5p763jf5` | -- |
|         Cargo Packaged Indicator | XdBoolean | `vhurb72qrcql2mfgee4qqfpr` | -- |
|         Cargo Residue Indicator | XdBoolean | `f6z8n84yeecaldnpwlvkwxu6` | -- |
|         Item Requires Temperature Controlled Storage Indicator | XdBoolean | `upsbblpa1ive15ga77zi1gsb` | -- |
|         Cargo Category | XdString | `h41dw3visq44p6smrfvn2uxh` | maxLen=4000 |
|         Cargo Destination Location Reference | XdString | `aa2uzc2ufbngl6rws215d86w` | maxLen=2000; pattern=`\S+` |
|         Cargo Identification | XdString | `cy3yi9wo6v1oxud9puiy6gzj` | maxLen=64 |
|         Cargo Origin Location Reference | XdString | `uha0u3z41fcp9jpotibaog72` | maxLen=2000; pattern=`\S+` |
|         Item Description | XdString | `nthc5cxvqgbwptwn3rc9oyh9` | maxLen=4000 |
|         Cargo Chargeable Weight | XdQuantity | `wlny1btrrgj191e2phm7u95c` | units=Mass Units (SI and customary) |
|         Cargo Customs Value Amount | XdQuantity | `guntplk8ac1aef631b8ttjie` | units=Currency |
|         Cargo Diameter | XdQuantity | `j15lyr8t65m6ga2atkrb7ecu` | units=Length Units (SI and customary) |
|         Cargo Drained Weight | XdQuantity | `wnpxggyzzdpulq9yyo0sz2zo` | units=Mass Units (SI and customary) |
|         Cargo Gross Volume | XdQuantity | `mvfbpjrriv02bztcn1umkm1x` | units=Volume Units (SI and customary) |
|         Cargo Gross Weight | XdQuantity | `lku1e3t3ytrznprbdzzv1o2t` | units=Mass Units (SI and customary) |
|         Cargo Net Volume | XdQuantity | `q0h35kfehr7ix1j7876lxwac` | units=Volume Units (SI and customary) |
|         Cargo Net Weight | XdQuantity | `vwhs6jth0y0blte839iudo19` | units=Mass Units (SI and customary) |
|         Cargo Tare Weight | XdQuantity | `x1wt3ndkddxmjh0dvq6yuxg1` | units=Mass Units (SI and customary) |
|         Item Maximum Acceptable Temperature | XdQuantity | `a18a64f1nyy1ex5anp4gd2nd` | units=Temperature Units (Celsius, Fahrenheit, Kelvin) |
|         Item Minimum Acceptable Temperature | XdQuantity | `njyc6t0suq0j7u0c3xmhfljr` | units=Temperature Units (Celsius, Fahrenheit, Kelvin) |
|         **Hazmat Declaration** | Cluster | `frlybtpebuldvqgrz346dmz0` | 7 components; 2 sub-cluster(s) |
|           Hazmat Declaration Chemical Common Name | XdString | `oghz7a04ynuxx2a49i01r4rq` | maxLen=255 |
|           Hazmat Declaration Description | XdString | `ymuhcio48ie4kquqn029f1zh` | maxLen=4000 |
|           Hazmat Declaration Destination Location Reference | XdString | `xsycj9rldxdpn4zyf8vif4r6` | maxLen=2000; pattern=`\S+` |
|           Hazmat Declaration Hazmat Class | XdString | `fdnngpymm3dl8j08y4nzdrkt` | maxLen=4000 |
|           Hazmat Declaration Origin Location Reference | XdString | `a8zrgx586sf2ux80vljx47n0` | maxLen=2000; pattern=`\S+` |
|           Hazmat Declaration UN Hazmat Page | XdString | `il5tl68djpz9k1qvr40chq1a` | maxLen=4000 |
|           Hazmat Declaration Flash Point | XdQuantity | `idjto7ffq4ajnslfsrro4r55` | units=Temperature Units (Celsius, Fahrenheit, Kelvin) |
|           **Contact Information (NIEM)** | Cluster | `v40dwrznm5fwko7b4n6ryrzi` | 3 components; 2 sub-cluster(s) |
|             Contact Entity Description | XdString | `b3yv6tmx5q9tq61zrrbrl8v3` | maxLen=4000 |
|             Contact Information Description | XdString | `m6hyj5gbbwiaepgiioklhtg3` | maxLen=4000 |
|             Contact Information Availability Code | XdToken | `wyevwvpluw19t8wge0psgpjs` | 6 enum(s) |
|             **Address (NIEM)** | Cluster | `doa46sdyoadezgc0tpj379th` | 10 components; 2 sub-cluster(s) |
|               Address Building Name | XdString | `bgn0jx6ubvcjtwa17hxvini2` | maxLen=255 |
|               Address County Name | XdString | `vkbg8z0vmi1a4u99xp1mbsal` | maxLen=255 |
|               Address Delivery Point | XdString | `ep615o1qzzlhz9f2g2quf6sp` | maxLen=4000 |
|               Address Full | XdString | `dwy0u03b1iidzxi4ega2iy5r` | maxLen=4000 |
|               Address Postal Extension Code | XdString | `lckcihuej9hiyqfjhekk6nid` | maxLen=255 |
|               Address Private Mailbox | XdString | `jx13ihzux8cd382oenzlkn05` | maxLen=4000 |
|               Address Recipient Name | XdString | `qcngrwgzzjxvcbxbm9oxonei` | maxLen=255 |
|               Address Secondary Unit | XdString | `fvznldoks6w41g7a4pwvd2ub` | maxLen=4000 |
|               Address Urbanization Name | XdString | `fzjp1m1u66usm20aamjygmun` | maxLen=255 |
|               Address Category Code | XdToken | `k0ixe4ybmx5vp11f7de4k204` | 5 enum(s) |
|               **County (fips)** | Cluster | `bahj0gy7mbmyobqhfy70x190` | 3 components |
|                 Code List: fips US County5 Digit | XdLink | `s5u98t1ah8l5069q0x704tdt` | -- |
|                 Code Display Text | XdString | `kr8fmao4yji8vr46kiw150me` | maxLen=500 |
|                 County Code (fips) | XdString | `dy9dwf3fhe3y6hyf1ka5fbfz` | maxLen=5; pattern=`[0-9]{5,5}` |
|               **International Address** | Cluster | `upawqojmcfg3qsf4ffzi47ho` | 7 components |
|                 Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|                 Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|                 City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|                 Postal Code | XdString | `gf841eedvv6cjiegs934srai` | maxLen=15 |
|                 Region Name | XdString | `jw1b9q6ulyte599sdsqp2mvp` | maxLen=100 |
|                 Address Use | XdToken | `b25dj42zxhm19pih328ga8pl` | 5 enum(s) |
|                 Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|             **Contact Point** | Cluster | `d2xwhnb2vqzxw70jcizj9csx` | 6 components |
|               Website URL | XdLink | `wriny2gz8aqcvffmfpwbompk` | -- |
|               Email Address | XdString | `q922mqaon3yn5zlwf2bszf28` | maxLen=254; pattern=`.+@.+\..+` |
|               Fax Number | XdString | `ll6ltsnvakomixuitxkbkxfz` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|               Phone Number | XdString | `zpfwg52r88j6jdypj7rg71ke` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|               Contact Method | XdToken | `miqo30r5b554nyj7ubryw43x` | 7 enum(s) |
|               Contact Use | XdToken | `vmruk4j9y1orvvz8cwafrax5` | 5 enum(s) |
|           **Hazmat Declaration UN Hazmat (hazmat)** | Cluster | `rsv0xcrhqso3ypcty9dtcude` | 3 components |
|             Code List: hazmat Hazmat | XdLink | `er6mk67kadl5j6b6xza1p076` | -- |
|             Code Display Text | XdString | `kr8fmao4yji8vr46kiw150me` | maxLen=500 |
|             Hazmat Declaration UN Hazmat Code (hazmat) | XdString | `bht8zdqfui2i5z6wk7lylm3a` | maxLen=6; pattern=`[A-Z0-9]{6,6}` |
|     **Person on Vessel** | Cluster | `iszrz5bn4iw6m2rx06dihlug` | 7 components; 4 sub-cluster(s) |
|       Crew Role | XdString | `muds8ss2ntcic0wmdv2nnh0q` | maxLen=4000 |
|       Person Cabin Number | XdString | `o05jqv95ntsi2cbcacav3ffs` | maxLen=4000 |
|       Person Debarkation Location Reference | XdString | `zbpx9uosr4g9wfgvkmt3k2d2` | maxLen=2000; pattern=`\S+` |
|       Person Embarkation Location Reference | XdString | `vj995cn5lh2tj2umyfm29hz6` | maxLen=2000; pattern=`\S+` |
|       Crew Role Code | XdToken | `iug560nmejpzg9awf5dkq2j0` | 87 enum(s) |
|       Person Debarkation Date | XdTemporal | `i9n1t0ckp7q8kpelk8x8lb3i` | -- |
|       Person Embarkation Date | XdTemporal | `oinjadlfuwbbbgxa0ais3zmk` | -- |
|       **Person Country Of Residence ISO3166 Alpha2 (iso_3166)** | Cluster | `uzizeupcso7xxao5eeziwrni` | 3 components |
|         Code List: iso_3166 Country Alpha2 | XdLink | `cofpmwotzqvohlh9zugdm2rm` | -- |
|         Code Display Text | XdString | `kr8fmao4yji8vr46kiw150me` | maxLen=500 |
|         Person Country Of Residence ISO3166 Alpha2 Code (iso_3166) | XdString | `sch6jgvn2anmpdn3s4ewbazl` | maxLen=2; pattern=`[A-Z]{2,2}` |
|       **Person (Demographics)** | Cluster | `vag4j8x1v4bp92xkmks7q4to` | 4 components; 1 sub-cluster(s) |
|         Administrative Gender | XdToken | `gxzbm758mhdz51xd4bawlfhh` | 4 enum(s) |
|         Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|         Language Code | XdToken | `no649c8yiebkyujhlbwjuppx` | 184 enum(s) |
|         Date of Birth | XdTemporal | `js564tazefb6udqlh12rj04l` | -- |
|         **Full Name (Person)** | Cluster | `ytw6qjtq5gilrvkfsohsrlkh` | 6 components |
|           Given Name (Person) | XdString | `l9l169co9r23e6fftpvdz4e3` | minLen=1; maxLen=100 |
|           Middle Name (Person) | XdString | `zcf4f5kjjo497jeb9vtt9rmr` | minLen=1; maxLen=100 |
|           Name Prefix | XdString | `yahxccv0l1z6ykjxayzkdlkq` | maxLen=20 |
|           Name Suffix | XdString | `l509t0zajfl5atns64d5kl97` | maxLen=20 |
|           Surname (Person) | XdString | `jc1lfk3ovt6l8frhxvx8b669` | minLen=1; maxLen=100 |
|           Name Use | XdToken | `bfqinvm7qrgi9jjw1i637moh` | 7 enum(s) |
|       **Visa** | Cluster | `ejzq5hi55m4c3dtb7zsrcn22` | 13 components; 2 sub-cluster(s) |
|         Visa Waiver Indicator | XdBoolean | `c7qyedp9nhqssr5mr5y0jvjc` | -- |
|         Document Identification | XdString | `o0b8101wnwebagfecgq8rjsr` | maxLen=64 |
|         Visa Application Disposition Status | XdString | `ftdt9rdkpma84fl1u85hrpdb` | maxLen=255 |
|         Visa Application Location Reference | XdString | `xh6pyeokg7gndyiowsj0t8h7` | maxLen=2000; pattern=`\S+` |
|         Visa Cancel Category Description | XdString | `srny9xiovlebo85vd12og2ou` | maxLen=4000 |
|         Visa Control Number ID | XdString | `rfgz0j1f4hf3ubj192mgk0om` | maxLen=255 |
|         Visa Foil Number ID | XdString | `ni6t8gpjwoadyaf9tar48mqz` | maxLen=255 |
|         Visa Number ID | XdString | `p4mr4yob8zj1yhp7ahrrb1qz` | maxLen=255 |
|         Document Category Code | XdToken | `dtg41yteb30gsktl80krdm81` | 66 enum(s) |
|         Visa Cancel Category Code | XdToken | `msxn0dqsmg0b2nff6bt71lvq` | 8 enum(s) |
|         Document Expiration Date | XdTemporal | `denuc00hfkjpns78bl2x2unj` | -- |
|         Document Issue Date | XdTemporal | `e7xtsqpgazd5rhn9syloijdc` | -- |
|         Visa Application Date | XdTemporal | `y401dcltvn4kn6hg9t8l6dm6` | -- |
|         **Person Citizenship Country (genc)** | Cluster | `tu7p00j80fbm2th9ov2d4vk8` | 3 components |
|           Code List: genc Country Alpha3 | XdLink | `g7jyi7jqap1f00w7sf6cx7qn` | -- |
|           Code Display Text | XdString | `kr8fmao4yji8vr46kiw150me` | maxLen=500 |
|           Person Citizenship Country Code (genc) | XdString | `jyhn545sm1e7yuhxje1fj7vg` | maxLen=3; pattern=`[A-Z0-9]{3,3}` |
|     **Port Fees** | Cluster | `jmrewm6ip02a8jf9je37jj8h` | 4 components |
|       Fee Type | XdToken | `wvfcfa6u4ers75egrbi25x9l` | 8 enum(s) |
|       Payment Status | XdToken | `vt5nh89ol3g5gj0oz35tl6y0` | 3 enum(s) |
|       Port Fee Amount | XdQuantity | `e92ud8io69rm826g9b1jrrgh` | min=0.00000; units=Cordova Córdoba (COR) |
|       Fee Date | XdTemporal | `zub98dao6k8cbbhsddzoq62w` | -- |
|     **Port Visit** | Cluster | `q6s9tcbnq5r4bzi2l6jdxo0x` | 7 components; 1 sub-cluster(s) |
|       Visit Anchorage | XdString | `rqh1k3syvt106xza6v3mnt6r` | maxLen=4000 |
|       Visit Location In Port Reference | XdString | `e1orf3vh0i30pmml6zwvrts5` | maxLen=2000; pattern=`\S+` |
|       Visit Receiving Facility Name | XdString | `lo62b4obm9nszn2f900grt6i` | maxLen=255 |
|       Visit Actual Arrival Date Time | XdTemporal | `pvf4bvtxrozkf1goofqr03js` | -- |
|       Visit Actual Departure Date Time | XdTemporal | `ui7i3tpzb2c9cll5gtbw08pi` | -- |
|       Visit Expected Arrival Date Time | XdTemporal | `ld7108yehox40p8x11fwthv6` | -- |
|       Visit Expected Departure Date Time | XdTemporal | `a9dd56h2sqblsmvayxpltsyc` | -- |
|       **Port** | Cluster | `pa9ibnbd0m1kb3b85j31u9jg` | 19 components |
|         Port ISPS Compliant Indicator | XdBoolean | `sp8lzext22ekhesq09dxvdbm` | -- |
|         Port Strategic Port Of Embarkation Indicator | XdBoolean | `boj8h4bx6wdxwokeju55uabk` | -- |
|         Port Anchorage Capability | XdString | `kv4ck60settfh4dy4ppzvrgy` | maxLen=4000 |
|         Port BE Number | XdString | `qc6i6bom51f6e5bk0puy5uej` | maxLen=4000 |
|         Port Cargo Capability | XdString | `luo96pj032hei8e1kjtrw5ay` | maxLen=4000 |
|         Port Code | XdString | `bv8v2gr8qme278at9s5bzo1j` | maxLen=4000 |
|         Port Description | XdString | `cbxqalnvq4oejubnbn2z4ac9` | maxLen=4000 |
|         Port Government | XdString | `dxe0jvpcsae1vodnxrtref1d` | maxLen=4000 |
|         Port Name | XdString | `dyqfc3fbn1m2ss0ov8zbsmgi` | maxLen=255 |
|         Port Operational Status | XdString | `mmltxsb066fxe5i6ndnuevde` | maxLen=255 |
|         Port Threat Level | XdString | `ol3vlxq0quuxfk9iuxhu75if` | maxLen=4000 |
|         Port UNLOCODE | XdString | `irtdoeuyky66rx8bzyt7dz0n` | maxLen=4000 |
|         City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|         Region Name | XdString | `jw1b9q6ulyte599sdsqp2mvp` | maxLen=100 |
|         Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|         Port Depth | XdQuantity | `f6yfxyraeym4scrj440urxzk` | units=Length Units (SI and customary) |
|         Port Dock Quantity | XdQuantity | `bdgeuo844vq9rjv7h11pvsp7` | units=Unitless |
|         Port Maximum Vessel Quantity | XdQuantity | `vfekd25ni2lljhyzcly4i2ww` | units=Unitless |
|         Port Pilot Boat Quantity | XdQuantity | `q9kszseel150b3yw0w68ji23` | units=Unitless |
|     **Vessel** | Cluster | `op8351ab3zorl15xossocp8h` | 64 components; 4 sub-cluster(s) |
|       Vessel Cargo On Board Indicator | XdBoolean | `ak01nt23hkxpbpgya06jnia0` | -- |
|       Vessel CDC Capable Indicator | XdBoolean | `i7873nmrbfh6ptcbfev5zh2d` | -- |
|       Vessel CDC Cargo On Board Indicator | XdBoolean | `urw4r7624cktfvh0amiiea2f` | -- |
|       Vessel CVSSA On Board Indicator | XdBoolean | `oovifdbbxiqs7hl5i8c9swye` | -- |
|       Vessel Non Tank Vessel Response Plan Indicator | XdBoolean | `ptg4yom0q4l2d5p0i5xyh305` | -- |
|       Vessel Activity History Summary | XdString | `m9csgwrbb9bhw1evqgazcoeu` | maxLen=4000 |
|       Vessel Call Sign | XdString | `rmc4i7gk31trj6ywjhe4dbqq` | maxLen=4000 |
|       Vessel Cargo Capability | XdString | `re1iab909up6ev7hsuu9y3vs` | maxLen=4000 |
|       Vessel Cargo Category | XdString | `kb4brkah533ikq7rkymw67yy` | maxLen=4000 |
|       Vessel Charterer Reference | XdString | `ztba28zokcz5vc513hf0h1aw` | maxLen=2000; pattern=`\S+` |
|       Vessel Class | XdString | `fn294o2fj6b5n3i7xyu8hiny` | maxLen=4000 |
|       Vessel Classification Society Name | XdString | `i5aduq5752a00eumr4d95e0o` | maxLen=255 |
|       Vessel Description | XdString | `vzudmmvtq74b5xm3t0iphawz` | maxLen=4000 |
|       Vessel Engine Category Description | XdString | `i03g7d69wznq6eyqsqljt0ay` | maxLen=4000 |
|       Vessel Fuel Category | XdString | `crwvmyk1iez0uyy6pglqtt7d` | maxLen=4000 |
|       Vessel Hailing Port Reference | XdString | `d9jvphqbyp0csxjpu5n98rbk` | maxLen=2000; pattern=`\S+` |
|       Vessel HIN | XdString | `pabitwleaz2r506k1qgqzonw` | maxLen=4000 |
|       Vessel Hull Category | XdString | `zprxlini8tmula1dskm1od6k` | maxLen=4000 |
|       Vessel Hull Number | XdString | `lnfriohyxtqenbkomt5jjzc5` | maxLen=4000 |
|       Vessel Identification | XdString | `rl25uxb0375uuk62fnwo6lwv` | maxLen=64 |
|       Vessel IMO Number | XdString | `aivao35pi0nrx4r9iny9pt78` | maxLen=4000 |
|       Vessel Incident History Summary | XdString | `ov4ucz4x8ltxh3lu2o5dw6su` | maxLen=4000 |
|       Vessel IRCS | XdString | `bprbvczg1qmq02y7mhxfcw2v` | maxLen=4000 |
|       Vessel ISSC Reference | XdString | `qz4rkcjh7ci86cf98oaoo1v1` | maxLen=2000; pattern=`\S+` |
|       Vessel Location Reference | XdString | `dylotzkdapfdg24vwns9ky9g` | maxLen=2000; pattern=`\S+` |
|       Vessel Manager Reference | XdString | `fjka53scfi7pd0t1jjhb2lvy` | maxLen=2000; pattern=`\S+` |
|       Vessel MMSI | XdString | `k9ebafypg105tcjodop0904l` | maxLen=4000 |
|       Vessel Name | XdString | `l3wb162tkmbj8pn82k5s05k6` | maxLen=255 |
|       Vessel National Flag | XdString | `mljbs0qjlqa4vxwdouplatqc` | maxLen=4000 |
|       Vessel Navigation Status | XdString | `m2c5v3tp1goncs7gayn73l94` | maxLen=255 |
|       Vessel Non Tank Vessel Response Plan Identification | XdString | `bp1a2e22lks229huzfrus41u` | maxLen=64 |
|       Vessel Official Coast Guard Number | XdString | `vyk7fpaxtgm8l3r94kd2ieus` | maxLen=4000 |
|       Vessel Operator Reference | XdString | `xkiqi3nls0gwngcvn9mpe7p2` | maxLen=2000; pattern=`\S+` |
|       Vessel Owner Reference | XdString | `vbkqueiz3gnnurgucfngki2l` | maxLen=2000; pattern=`\S+` |
|       Vessel Safety Management Certificate Reference | XdString | `a5wfz7oedbsb01q3oqwakpav` | maxLen=2000; pattern=`\S+` |
|       Vessel SCONUM | XdString | `jp7ppmep64y2ub6r5nxiqxp0` | maxLen=4000 |
|       Vessel State Identification | XdString | `rqrgi2hipvrwmee08qz1i2pd` | maxLen=64 |
|       Vessel Sub Category | XdString | `znowdgk6s29ov01b8fwjgw6b` | maxLen=4000 |
|       Vessel Hull Color Code | XdToken | `jiebkzm0ysaf7pdhu4w2wj9k` | 32 enum(s) |
|       Vessel Operational Condition Of Equipment Code | XdToken | `erhg9qdth7ta760pwxhmrltg` | 3 enum(s) |
|       Vessel Image | XdFile | `okry83x4tw4j6bcbibpqpv6i` | -- |
|       Vessel Gross Tonnage Value | XdCount | `aztdy909x45e38kshz3xbp0d` | units=Unitless |
|       Vessel Beam | XdQuantity | `ermiig98krfcml43mnz9iupf` | units=Length Units (SI and customary) |
|       Vessel Crane Quantity | XdQuantity | `v8ln42mj9qs6d4gds6kjndgl` | units=Unitless |
|       Vessel Cruise Range | XdQuantity | `vuu4c5v3s1d0drgc901liitx` | units=Length Units (SI and customary) |
|       Vessel Cruise Speed | XdQuantity | `ijujbmk8ldaek9nvzacnr7qe` | units=Speed Units |
|       Vessel Dead Weight | XdQuantity | `izxarb6yd3qy1owp0panf3vi` | units=Mass Units (SI and customary) |
|       Vessel Displacement | XdQuantity | `fmde90hktzp5fddjo9mc25a7` | units=Volume Units (SI and customary) |
|       Vessel Draft | XdQuantity | `r225rzgxq2g3ofec2jpjnrij` | units=Length Units (SI and customary) |
|       Vessel Draft Unloaded | XdQuantity | `i8l62l2hvnww1kx7fc5wavdy` | units=Length Units (SI and customary) |
|       Vessel Endurance | XdQuantity | `lwuk9c4ciatuok980tvr69e9` | units=Time Units |
|       Vessel Fuel Consumption Rate | XdQuantity | `wtrmzepgdukv7undsbtjemu1` | units=Fuel Consumption Rate Units |
|       Vessel Holds Quantity | XdQuantity | `lfrukaqchc3fwi4f79y84f88` | units=Unitless |
|       Vessel Mast Height | XdQuantity | `sff56vtgfttm0e370yuzk0q9` | units=Length Units (SI and customary) |
|       Vessel Maximum Crew Quantity | XdQuantity | `an9pjv60uzlnrxky78ryxeed` | units=Unitless |
|       Vessel Maximum Passenger Quantity | XdQuantity | `dchwr7t6ic13qq2q519qadjr` | units=Unitless |
|       Vessel Maximum Range | XdQuantity | `aezxi2nqejww0ep101rjqm5w` | units=Length Units (SI and customary) |
|       Vessel Maximum Speed | XdQuantity | `cajb3p2aoulkzthzizn3yrjf` | units=Speed Units |
|       Vessel Maximum Static Draft | XdQuantity | `je8f7a8qkjsqmhh496lxeyzt` | units=Length Units (SI and customary) |
|       Vessel Net Tonnage Volume | XdQuantity | `k8lbszstxig4a4c78bhwmaiw` | units=Volume Units (SI and customary) |
|       Vessel Overall Length | XdQuantity | `j5blww57jcwp0z04jq489lce` | units=Length Units (SI and customary) |
|       Vessel Ramp Quantity | XdQuantity | `kwub1xjxijy2pj3lrjve391k` | units=Unitless |
|       Vessel Build Date | XdTemporal | `g195vhqb6co2rjp5g44wfgqq` | -- |
|       Vessel Keel Date | XdTemporal | `lq4lsb4tei7ps90onvthqang` | -- |
|       **Certificate (Maritime)** | Cluster | `uz2vgvsk1jy9chuuxqkfl0xe` | 5 components; 1 sub-cluster(s) |
|         Certificate Endorsement | XdString | `ltb7mgfukp27uvvd2i6ckv0j` | maxLen=4000 |
|         Certificate Issuing Agency Reference | XdString | `vsicyx8gbscwt6xvn17go9x1` | maxLen=2000; pattern=`\S+` |
|         Certificate Jurisdiction Reference | XdString | `uvgji61iymtbqsx35plx69dk` | maxLen=2000; pattern=`\S+` |
|         Certificate Restriction | XdString | `czeqt7znxmnyrp1yh403s08p` | maxLen=4000 |
|         Certificate Issue Date | XdTemporal | `w1zx8127gj3286rm2wcczvlr` | -- |
|         **Document (NIEM)** | Cluster | `ai8ura28ys4ad4ze83zzh2jb` | 41 components |
|           Document Approved Indicator | XdBoolean | `bk6su7a9272t2jb5np0xrswu` | -- |
|           Document Copyright Indicator | XdBoolean | `zluf5pm3zfrq81cvuibojmi9` | -- |
|           Document Permanent Record Indicator | XdBoolean | `o22r2bod1s8auw9t4vl1cnli` | -- |
|           Document Privacy Act Indicator | XdBoolean | `hd5pstne89jto5fwzgss49a7` | -- |
|           Document Vital Indicator | XdBoolean | `mj8llv0mgjoullggu8yn0eye` | -- |
|           Document Author Reference | XdString | `p0qa6xm1ijnf9w3s4uawqi8e` | maxLen=2000; pattern=`\S+` |
|           Document Category | XdString | `kebb986befzd97jjyha64cfd` | maxLen=4000 |
|           Document Contributor Reference | XdString | `nn764wjllssekk1zqf6wy9ww` | maxLen=2000; pattern=`\S+` |
|           Document Description | XdString | `qgvwysjyxajrbd0qj8j1qjbq` | maxLen=4000 |
|           Document File Control ID | XdString | `tan0xz282f4bc2vd7cfn9e7a` | maxLen=255 |
|           Document File Extension | XdString | `qkgh98flk2k8yv8i39pljpdh` | maxLen=4000 |
|           Document File Name | XdString | `fon72vu4ai1jvb9zvtgrqcyt` | maxLen=255 |
|           Document Group ID | XdString | `edoe8b7dhqkhq4tphqgc1ux5` | maxLen=255 |
|           Document Identification | XdString | `o0b8101wnwebagfecgq8rjsr` | maxLen=64 |
|           Document Keyword | XdString | `inu67uwr6vbkk3r55uh0e8n4` | maxLen=4000 |
|           Document Location URI | XdString | `j0dg7u71oo1i1hjn8ubxlmsc` | maxLen=2000; pattern=`\S+` |
|           Document Recipient Reference | XdString | `ahxxa6bxpmn0qy5scookdgk6` | maxLen=2000; pattern=`\S+` |
|           Document Rights | XdString | `e0uz8mcoo6irzg6ve0se560w` | maxLen=4000 |
|           Document Sensitivity | XdString | `gs3r0x7d1paumiuudsp85a3s` | maxLen=4000 |
|           Document Sequence ID | XdString | `ssv3mlmi666j9mkiw0xwqqia` | maxLen=255 |
|           Document Source Reference | XdString | `kkz5i6e80o9m754aflnm7upu` | maxLen=2000; pattern=`\S+` |
|           Document Status | XdString | `kyx8j945qq8fp4k9zj1iu7i7` | maxLen=255 |
|           Document Subject | XdString | `qfq5mjxc6egjkbhwb0lle6f5` | maxLen=4000 |
|           Document Submitter Reference | XdString | `rt9jkbvvjb59hpe0zxtuabgv` | maxLen=2000; pattern=`\S+` |
|           Document Summary | XdString | `ambaf9clrk834ryvpu2zg8a5` | maxLen=4000 |
|           Document Supplemental Marking | XdString | `ji1ciltzkswki5irxb6fectk` | maxLen=4000 |
|           Document Text | XdString | `r9djjx8ffwdagon0z79n8ejy` | maxLen=4000 |
|           Document Title | XdString | `akpb3fdbdckvu1s99wl62h4x` | maxLen=4000 |
|           Document Title Alternative | XdString | `gg3jnztfkx9dklglxn4gvar6` | maxLen=4000 |
|           Media Type | XdToken | `nsapfk3gom5sc51bvfo1nkns` | 16 enum(s) |
|           Language Code | XdToken | `no649c8yiebkyujhlbwjuppx` | 184 enum(s) |
|           Document Binary | XdFile | `rn54c8rtza0msexichiq51g2` | -- |
|           Document Submission Amount | XdQuantity | `fha0ia2fu8l00zoripl8g6pr` | units=Currency |
|           Document Creation Date | XdTemporal | `fcyq6rfjhjrv3li6mqiunzm5` | -- |
|           Document Effective Date | XdTemporal | `m9x5l7wukvuijhpjmdshp1uk` | -- |
|           Document Expiration Date | XdTemporal | `denuc00hfkjpns78bl2x2unj` | -- |
|           Document Filed Date | XdTemporal | `bp5pznhivpneslnqwz3kabd4` | -- |
|           Document Issue Date | XdTemporal | `e7xtsqpgazd5rhn9syloijdc` | -- |
|           Document Last Modified Date | XdTemporal | `jfhyfzw2tp4921wowsqonnup` | -- |
|           Document Publication Date | XdTemporal | `n9n48ynbn2di5oocj51jsu44` | -- |
|           Document Received Date | XdTemporal | `vejhikm0gmmvka7ah3ipxi8b` | -- |
|       **Vessel National Flag ISO3166 Alpha2 (iso_3166)** | Cluster | `q569cu7m4n1vrjck4gzhq1tg` | 3 components |
|         Code List: iso_3166 Country Alpha2 | XdLink | `cofpmwotzqvohlh9zugdm2rm` | -- |
|         Code Display Text | XdString | `kr8fmao4yji8vr46kiw150me` | maxLen=500 |
|         Vessel National Flag ISO3166 Alpha2 Code (iso_3166) | XdString | `dkk8m5i1g66txlf9gxs6xe5e` | maxLen=2; pattern=`[A-Z]{2,2}` |
|     **Voyage** | Cluster | `pzj4377fxmvrb3iobralx81g` | 7 components; 1 sub-cluster(s) |
|       Voyage Category | XdString | `k8m2895orzgamwoy83zjxm2l` | maxLen=4000 |
|       Voyage Destination Location Reference | XdString | `dlqpv17jlihurr0c83ipr7f7` | maxLen=2000; pattern=`\S+` |
|       Voyage Identification | XdString | `ipthnnocq1pd638th6e60cav` | maxLen=64 |
|       Voyage Summary | XdString | `m5bnfxnbs1tepl7je0q7b5tt` | maxLen=4000 |
|       Voyage Vessel Use | XdString | `hgz6gu8apyown5vc51d8ti0g` | maxLen=4000 |
|       Voyage Begin Date Time | XdTemporal | `vbwrvcj810xe6oxszsm63fdn` | -- |
|       Voyage End Date Time | XdTemporal | `dqzc80tlv0m4lqhnjdnvr29x` | -- |
|       **Location (NIEM)** | Cluster | `o01gifxohfe46jfdyh62noig` | 10 components; 3 sub-cluster(s) |
|         Location Category | XdString | `fenldej2l73b84w956gawyqd` | maxLen=4000 |
|         Location Description | XdString | `zlqtx5yr8wdxavl2hc4y9uq4` | maxLen=4000 |
|         Location Directions | XdString | `fwusqzhkfgeh7gwrsgihp0rx` | maxLen=4000 |
|         Location Identification | XdString | `c9n7299dj2fdzlmqe8ixvb2z` | maxLen=64 |
|         Location Landmark Name | XdString | `vw3tuujru1u95k6kavnc946v` | maxLen=255 |
|         Location Name | XdString | `ouramzsx8f7nis27vjj265l9` | maxLen=255 |
|         Location Range Description | XdString | `ces753kz92cp4zdyva7qw530` | maxLen=4000 |
|         Location Surrounding Area Description | XdString | `enu405jym8hdu571utuznru3` | maxLen=4000 |
|         Location Altitude | XdQuantity | `qjl8rgtsnazid1rvxqof65yy` | units=Length Units (SI and customary) |
|         Location Elevation | XdQuantity | `n3luxpr7zt9z2ylpmp2wioy4` | units=Length Units (SI and customary) |
|         **Geolocation** | Cluster | `jwfl94g8mj8aevupivyfsnwj` | 4 components |
|           Geodetic Datum | XdToken | `i3qpmie9hle8ma5kt6ogxqnp` | 3 enum(s) |
|           Altitude | XdQuantity | `scdlxu6vex8iwbfc8sijmjff` | units=Length/Distance (SI - Metric) |
|           Latitude | XdQuantity | `c5e0wv21cmlouukx6ga2o5uz` | units=Degrees (Angle) |
|           Longitude | XdQuantity | `qh625ukiiju3ak4x45tehcnr` | units=Degrees (Angle) |
|         **Locale** | Cluster | `ru0fwf4ubdvcizzaau0mpftg` | 16 components |
|           Locale Census Block ID | XdString | `ji7mja9le7x3k2fnstyflgd9` | maxLen=255 |
|           Locale Census Tract ID | XdString | `b1qnngc94yrhnzw0a0qylc8m` | maxLen=255 |
|           Locale Community Name | XdString | `d62un867sx8pfuoiw9vmyvhc` | maxLen=255 |
|           Locale Description | XdString | `qhmp2uf6xmb86vdwzt9pz0z4` | maxLen=4000 |
|           Locale District Name | XdString | `xrx13kgg5bxgodid3gojzc4u` | maxLen=255 |
|           Locale Emergency Services Jurisdiction ID | XdString | `nmhyp4tz6uzhm9rcbxksrkad` | maxLen=255 |
|           Locale Emergency Services Name | XdString | `zza5jn63yvlxhjgkajypacqi` | maxLen=255 |
|           Locale Fire Jurisdiction ID | XdString | `nvonmskk57e6buoa4bjo4yq5` | maxLen=255 |
|           Locale Judicial District Name | XdString | `ep6d634smvqdn890vnjs8umh` | maxLen=255 |
|           Locale Neighborhood Name | XdString | `hs4ke1zgmxvea6nd41ivepg5` | maxLen=255 |
|           Locale Police Beat | XdString | `dt27rd2aw6bfydiru5ti7gyh` | maxLen=4000 |
|           Locale Police Grid | XdString | `rdk1jsosk7dgsbn7hkq3k10i` | maxLen=4000 |
|           Locale Police Jurisdiction ID | XdString | `end6e085n8tw4850taf7jjl2` | maxLen=255 |
|           Locale Region Name | XdString | `xswwghxc0mdmucw58sa5axse` | maxLen=255 |
|           Locale Subdivision Name | XdString | `f0j0mvmsjdjfccynvpynntd8` | maxLen=255 |
|           Locale Zone Name | XdString | `fypmwmyh1gcv597iesiyxdzd` | maxLen=255 |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: Maritime Port Authority 4.4.0
  [Cluster] Maritime Governed Record
    [XdFile] Digital Signature Proof
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] Port Call Record
      [XdString] Port Call ID
      [XdCount] Crew Count
      [XdCount] Passenger Count
      [Cluster] Cargo Manifest
        [XdString] Business Registry Number
        [XdCount] Container Count
        [Cluster] Cargo
          [XdBoolean] Cargo Hazardous Material Indicator
          [XdBoolean] Cargo Packaged Indicator
          [XdBoolean] Cargo Residue Indicator
          [XdBoolean] Item Requires Temperature Controlled Storage Indicator
          [XdString] Cargo Category
          [XdString] Cargo Destination Location Reference
          [XdString] Cargo Identification
          [XdString] Cargo Origin Location Reference
          [XdString] Item Description
          [XdQuantity] Cargo Chargeable Weight
          [XdQuantity] Cargo Customs Value Amount
          [XdQuantity] Cargo Diameter
          [XdQuantity] Cargo Drained Weight
          [XdQuantity] Cargo Gross Volume
          [XdQuantity] Cargo Gross Weight
          [XdQuantity] Cargo Net Volume
          [XdQuantity] Cargo Net Weight
          [XdQuantity] Cargo Tare Weight
          [XdQuantity] Item Maximum Acceptable Temperature
          [XdQuantity] Item Minimum Acceptable Temperature
          [Cluster] Hazmat Declaration
            [XdString] Hazmat Declaration Chemical Common Name
            [XdString] Hazmat Declaration Description
            [XdString] Hazmat Declaration Destination Location Reference
            [XdString] Hazmat Declaration Hazmat Class
            [XdString] Hazmat Declaration Origin Location Reference
            [XdString] Hazmat Declaration UN Hazmat Page
            [XdQuantity] Hazmat Declaration Flash Point
            [Cluster] Contact Information (NIEM)
              [XdString] Contact Entity Description
              [XdString] Contact Information Description
              [XdToken] Contact Information Availability Code
              [Cluster] Address (NIEM)
                [XdString] Address Building Name
                [XdString] Address County Name
                [XdString] Address Delivery Point
                [XdString] Address Full
                [XdString] Address Postal Extension Code
                [XdString] Address Private Mailbox
                [XdString] Address Recipient Name
                [XdString] Address Secondary Unit
                [XdString] Address Urbanization Name
                [XdToken] Address Category Code
                [Cluster] County (fips)
                  [XdLink] Code List: fips US County5 Digit
                  [XdString] Code Display Text
                  [XdString] County Code (fips)
                [Cluster] International Address
                  [XdString] Address (Line 1)
                  [XdString] Address (Line 2)
                  [XdString] City Name
                  [XdString] Postal Code
                  [XdString] Region Name
                  [XdToken] Address Use
                  [XdToken] Country Code ISO 3166
              [Cluster] Contact Point
                [XdLink] Website URL
                [XdString] Email Address
                [XdString] Fax Number
                [XdString] Phone Number
                [XdToken] Contact Method
                [XdToken] Contact Use
            [Cluster] Hazmat Declaration UN Hazmat (hazmat)
              [XdLink] Code List: hazmat Hazmat
              [XdString] Code Display Text
              [XdString] Hazmat Declaration UN Hazmat Code (hazmat)
      [Cluster] Person on Vessel
        [XdString] Crew Role
        [XdString] Person Cabin Number
        [XdString] Person Debarkation Location Reference
        [XdString] Person Embarkation Location Reference
        [XdToken] Crew Role Code
        [XdTemporal] Person Debarkation Date
        [XdTemporal] Person Embarkation Date
        [Cluster] Contact Information (NIEM) (circular ref)
        [Cluster] Person Country Of Residence ISO3166 Alpha2 (iso_3166)
          [XdLink] Code List: iso_3166 Country Alpha2
          [XdString] Code Display Text
          [XdString] Person Country Of Residence ISO3166 Alpha2 Code (iso_3166)
        [Cluster] Person (Demographics)
          [XdToken] Administrative Gender
          [XdToken] Country Code ISO 3166
          [XdToken] Language Code
          [XdTemporal] Date of Birth
          [Cluster] Full Name (Person)
            [XdString] Given Name (Person)
            [XdString] Middle Name (Person)
            [XdString] Name Prefix
            [XdString] Name Suffix
            [XdString] Surname (Person)
            [XdToken] Name Use
        [Cluster] Visa
          [XdBoolean] Visa Waiver Indicator
          [XdString] Document Identification
          [XdString] Visa Application Disposition Status
          [XdString] Visa Application Location Reference
          [XdString] Visa Cancel Category Description
          [XdString] Visa Control Number ID
          [XdString] Visa Foil Number ID
          [XdString] Visa Number ID
          [XdToken] Document Category Code
          [XdToken] Visa Cancel Category Code
          [XdTemporal] Document Expiration Date
          [XdTemporal] Document Issue Date
          [XdTemporal] Visa Application Date
          [Cluster] Person Citizenship Country (genc)
            [XdLink] Code List: genc Country Alpha3
            [XdString] Code Display Text
            [XdString] Person Citizenship Country Code (genc)
          [Cluster] Person (Demographics) (circular ref)
      [Cluster] Port Fees
        [XdToken] Fee Type
        [XdToken] Payment Status
        [XdQuantity] Port Fee Amount
        [XdTemporal] Fee Date
      [Cluster] Port Visit
        [XdString] Visit Anchorage
        [XdString] Visit Location In Port Reference
        [XdString] Visit Receiving Facility Name
        [XdTemporal] Visit Actual Arrival Date Time
        [XdTemporal] Visit Actual Departure Date Time
        [XdTemporal] Visit Expected Arrival Date Time
        [XdTemporal] Visit Expected Departure Date Time
        [Cluster] Port
          [XdBoolean] Port ISPS Compliant Indicator
          [XdBoolean] Port Strategic Port Of Embarkation Indicator
          [XdString] Port Anchorage Capability
          [XdString] Port BE Number
          [XdString] Port Cargo Capability
          [XdString] Port Code
          [XdString] Port Description
          [XdString] Port Government
          [XdString] Port Name
          [XdString] Port Operational Status
          [XdString] Port Threat Level
          [XdString] Port UNLOCODE
          [XdString] City Name
          [XdString] Region Name
          [XdToken] Country Code ISO 3166
          [XdQuantity] Port Depth
          [XdQuantity] Port Dock Quantity
          [XdQuantity] Port Maximum Vessel Quantity
          [XdQuantity] Port Pilot Boat Quantity
      [Cluster] Vessel
        [XdBoolean] Vessel Cargo On Board Indicator
        [XdBoolean] Vessel CDC Capable Indicator
        [XdBoolean] Vessel CDC Cargo On Board Indicator
        [XdBoolean] Vessel CVSSA On Board Indicator
        [XdBoolean] Vessel Non Tank Vessel Response Plan Indicator
        [XdString] Vessel Activity History Summary
        [XdString] Vessel Call Sign
        [XdString] Vessel Cargo Capability
        [XdString] Vessel Cargo Category
        [XdString] Vessel Charterer Reference
        [XdString] Vessel Class
        [XdString] Vessel Classification Society Name
        [XdString] Vessel Description
        [XdString] Vessel Engine Category Description
        [XdString] Vessel Fuel Category
        [XdString] Vessel Hailing Port Reference
        [XdString] Vessel HIN
        [XdString] Vessel Hull Category
        [XdString] Vessel Hull Number
        [XdString] Vessel Identification
        [XdString] Vessel IMO Number
        [XdString] Vessel Incident History Summary
        [XdString] Vessel IRCS
        [XdString] Vessel ISSC Reference
        [XdString] Vessel Location Reference
        [XdString] Vessel Manager Reference
        [XdString] Vessel MMSI
        [XdString] Vessel Name
        [XdString] Vessel National Flag
        [XdString] Vessel Navigation Status
        [XdString] Vessel Non Tank Vessel Response Plan Identification
        [XdString] Vessel Official Coast Guard Number
        [XdString] Vessel Operator Reference
        [XdString] Vessel Owner Reference
        [XdString] Vessel Safety Management Certificate Reference
        [XdString] Vessel SCONUM
        [XdString] Vessel State Identification
        [XdString] Vessel Sub Category
        [XdToken] Vessel Hull Color Code
        [XdToken] Vessel Operational Condition Of Equipment Code
        [XdFile] Vessel Image
        [XdCount] Vessel Gross Tonnage Value
        [XdQuantity] Vessel Beam
        [XdQuantity] Vessel Crane Quantity
        [XdQuantity] Vessel Cruise Range
        [XdQuantity] Vessel Cruise Speed
        [XdQuantity] Vessel Dead Weight
        [XdQuantity] Vessel Displacement
        [XdQuantity] Vessel Draft
        [XdQuantity] Vessel Draft Unloaded
        [XdQuantity] Vessel Endurance
        [XdQuantity] Vessel Fuel Consumption Rate
        [XdQuantity] Vessel Holds Quantity
        [XdQuantity] Vessel Mast Height
        [XdQuantity] Vessel Maximum Crew Quantity
        [XdQuantity] Vessel Maximum Passenger Quantity
        [XdQuantity] Vessel Maximum Range
        [XdQuantity] Vessel Maximum Speed
        [XdQuantity] Vessel Maximum Static Draft
        [XdQuantity] Vessel Net Tonnage Volume
        [XdQuantity] Vessel Overall Length
        [XdQuantity] Vessel Ramp Quantity
        [XdTemporal] Vessel Build Date
        [XdTemporal] Vessel Keel Date
        [Cluster] Certificate (Maritime)
          [XdString] Certificate Endorsement
          [XdString] Certificate Issuing Agency Reference
          [XdString] Certificate Jurisdiction Reference
          [XdString] Certificate Restriction
          [XdTemporal] Certificate Issue Date
          [Cluster] Document (NIEM)
            [XdBoolean] Document Approved Indicator
            [XdBoolean] Document Copyright Indicator
            [XdBoolean] Document Permanent Record Indicator
            [XdBoolean] Document Privacy Act Indicator
            [XdBoolean] Document Vital Indicator
            [XdString] Document Author Reference
            [XdString] Document Category
            [XdString] Document Contributor Reference
            [XdString] Document Description
            [XdString] Document File Control ID
            [XdString] Document File Extension
            [XdString] Document File Name
            [XdString] Document Group ID
            [XdString] Document Identification
            [XdString] Document Keyword
            [XdString] Document Location URI
            [XdString] Document Recipient Reference
            [XdString] Document Rights
            [XdString] Document Sensitivity
            [XdString] Document Sequence ID
            [XdString] Document Source Reference
            [XdString] Document Status
            [XdString] Document Subject
            [XdString] Document Submitter Reference
            [XdString] Document Summary
            [XdString] Document Supplemental Marking
            [XdString] Document Text
            [XdString] Document Title
            [XdString] Document Title Alternative
            [XdToken] Media Type
            [XdToken] Language Code
            [XdFile] Document Binary
            [XdQuantity] Document Submission Amount
            [XdTemporal] Document Creation Date
            [XdTemporal] Document Effective Date
            [XdTemporal] Document Expiration Date
            [XdTemporal] Document Filed Date
            [XdTemporal] Document Issue Date
            [XdTemporal] Document Last Modified Date
            [XdTemporal] Document Publication Date
            [XdTemporal] Document Received Date
        [Cluster] Contact Information (NIEM) (circular ref)
        [Cluster] Port (circular ref)
        [Cluster] Vessel National Flag ISO3166 Alpha2 (iso_3166)
          [XdLink] Code List: iso_3166 Country Alpha2
          [XdString] Code Display Text
          [XdString] Vessel National Flag ISO3166 Alpha2 Code (iso_3166)
      [Cluster] Voyage
        [XdString] Voyage Category
        [XdString] Voyage Destination Location Reference
        [XdString] Voyage Identification
        [XdString] Voyage Summary
        [XdString] Voyage Vessel Use
        [XdTemporal] Voyage Begin Date Time
        [XdTemporal] Voyage End Date Time
        [Cluster] Location (NIEM)
          [XdString] Location Category
          [XdString] Location Description
          [XdString] Location Directions
          [XdString] Location Identification
          [XdString] Location Landmark Name
          [XdString] Location Name
          [XdString] Location Range Description
          [XdString] Location Surrounding Area Description
          [XdQuantity] Location Altitude
          [XdQuantity] Location Elevation
          [Cluster] Address (NIEM) (circular ref)
          [Cluster] Geolocation
            [XdToken] Geodetic Datum
            [XdQuantity] Altitude
            [XdQuantity] Latitude
            [XdQuantity] Longitude
          [Cluster] Locale
            [XdString] Locale Census Block ID
            [XdString] Locale Census Tract ID
            [XdString] Locale Community Name
            [XdString] Locale Description
            [XdString] Locale District Name
            [XdString] Locale Emergency Services Jurisdiction ID
            [XdString] Locale Emergency Services Name
            [XdString] Locale Fire Jurisdiction ID
            [XdString] Locale Judicial District Name
            [XdString] Locale Neighborhood Name
            [XdString] Locale Police Beat
            [XdString] Locale Police Grid
            [XdString] Locale Police Jurisdiction ID
            [XdString] Locale Region Name
            [XdString] Locale Subdivision Name
            [XdString] Locale Zone Name
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Maritime Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Maritime Governed Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Maritime Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/maritime-governed-record` |
| Maritime Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Maritime Governed Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-haoricee7rjlcybdp70akw9l` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.w3.org/TR/vc-data-model/#credentials` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q210824` |
| Digital Signature Proof | `skos:broadMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| Port Call Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Call Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Port Call Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/port-call-record` |
| Port Call Record | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortVisitType` |
| Port Call Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-i8cjmvihdces5rqvb2snqwmo` |
| Port Call ID | `rdfs:isDefinedBy` | `http://purl.obolibrary.org/obo/BFO_0000009` |
| Port Call ID | `skos:broadMatch` | `https://schema.org/identifier` |
| Crew Count | `rdf:type` | `https://schema.org/Integer` |
| Crew Count | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q2513968` |
| Passenger Count | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q319604` |
| Passenger Count | `rdf:type` | `https://schema.org/Integer` |
| Cargo Manifest | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Manifest | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Cargo Manifest | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/cargo-manifest` |
| Cargo Manifest | `skos:closeMatch` | `https://schema.org/ItemList` |
| Cargo Manifest | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ibb8e7c8equpeqiv5wxrxxll` |
| Business Registry Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q12047291` |
| Business Registry Number | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| Business Registry Number | `skos:broadMatch` | `https://schema.org/identifier` |
| Container Count | `skos:broadMatch` | `https://www.wikidata.org/wiki/Q380340` |
| Container Count | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1366867` |
| Cargo | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo` |
| Cargo | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoType` |
| Cargo | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-aadu9dfogj06xj2eaiz8yoak` |
| Cargo Hazardous Material Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Hazardous Material Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-hazardous-material-indicator` |
| Cargo Hazardous Material Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Hazardous Material Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoHazardousMaterialIndicator` |
| Cargo Hazardous Material Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n7x39orkbwjejdf8r93trlaa` |
| Cargo Packaged Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Packaged Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-packaged-indicator` |
| Cargo Packaged Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Packaged Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoPackagedIndicator` |
| Cargo Residue Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Residue Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-residue-indicator` |
| Cargo Residue Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Residue Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoResidueIndicator` |
| Item Requires Temperature Controlled Storage Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Requires Temperature Controlled Storage Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-item-requires-temperature-controlled-storage-indicator` |
| Item Requires Temperature Controlled Storage Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Item Requires Temperature Controlled Storage Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/ItemRequiresTemperatureControlledStorageIndicator` |
| Cargo Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-category` |
| Cargo Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoCategoryText` |
| Cargo Category | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bfaa3m23ye8q0qphv0x24if6` |
| Cargo Destination Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Destination Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-destination-location-reference` |
| Cargo Destination Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Destination Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoDestinationLocation` |
| Cargo Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-identification` |
| Cargo Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoIdentification` |
| Cargo Origin Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Origin Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-origin-location-reference` |
| Cargo Origin Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Origin Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoOriginLocation` |
| Item Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-description` |
| Item Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemDescriptionText` |
| Item Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qnfg77xtg0phszn46wi3v1lb` |
| Cargo Chargeable Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Chargeable Weight | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-chargeable-weight` |
| Cargo Chargeable Weight | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Chargeable Weight | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoChargeableWeightMeasure` |
| Cargo Customs Value Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Customs Value Amount | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-customs-value-amount` |
| Cargo Customs Value Amount | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Customs Value Amount | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoCustomsValueAmount` |
| Cargo Diameter | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Diameter | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-diameter` |
| Cargo Diameter | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Diameter | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoDiameterMeasure` |
| Cargo Drained Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Drained Weight | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-drained-weight` |
| Cargo Drained Weight | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Drained Weight | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoDrainedWeightMeasure` |
| Cargo Gross Volume | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Gross Volume | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-gross-volume` |
| Cargo Gross Volume | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Gross Volume | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoGrossVolumeMeasure` |
| Cargo Gross Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Gross Weight | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-gross-weight` |
| Cargo Gross Weight | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Gross Weight | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoGrossWeightMeasure` |
| Cargo Gross Weight | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rns47yalhlquoehw0dx1l3g4` |
| Cargo Net Volume | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Net Volume | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-net-volume` |
| Cargo Net Volume | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Net Volume | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoNetVolumeMeasure` |
| Cargo Net Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Net Weight | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-net-weight` |
| Cargo Net Weight | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Net Weight | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoNetWeightMeasure` |
| Cargo Tare Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Cargo Tare Weight | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-cargo-tare-weight` |
| Cargo Tare Weight | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Cargo Tare Weight | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CargoTareWeightMeasure` |
| Item Maximum Acceptable Temperature | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Maximum Acceptable Temperature | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-item-maximum-acceptable-temperature` |
| Item Maximum Acceptable Temperature | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Item Maximum Acceptable Temperature | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/ItemMaximumAcceptableTemperatureMeasure` |
| Item Minimum Acceptable Temperature | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Minimum Acceptable Temperature | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-item-minimum-acceptable-temperature` |
| Item Minimum Acceptable Temperature | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Item Minimum Acceptable Temperature | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/ItemMinimumAcceptableTemperatureMeasure` |
| Hazmat Declaration | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration` |
| Hazmat Declaration | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Hazmat Declaration | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationType` |
| Hazmat Declaration Chemical Common Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration Chemical Common Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration-chemical-common-name` |
| Hazmat Declaration Chemical Common Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Hazmat Declaration Chemical Common Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationChemicalCommonName` |
| Hazmat Declaration Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration-description` |
| Hazmat Declaration Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Hazmat Declaration Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationDescriptionText` |
| Hazmat Declaration Destination Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration Destination Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration-destination-location-reference` |
| Hazmat Declaration Destination Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Hazmat Declaration Destination Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationDestinationLocation` |
| Hazmat Declaration Hazmat Class | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration Hazmat Class | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration-hazmat-class` |
| Hazmat Declaration Hazmat Class | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Hazmat Declaration Hazmat Class | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationHazmatClassText` |
| Hazmat Declaration Hazmat Class | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gqbvto3l0o5e6uorrgjwdig2` |
| Hazmat Declaration Origin Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration Origin Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration-origin-location-reference` |
| Hazmat Declaration Origin Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Hazmat Declaration Origin Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationOriginLocation` |
| Hazmat Declaration UN Hazmat Page | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration UN Hazmat Page | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration-un-hazmat-page` |
| Hazmat Declaration UN Hazmat Page | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Hazmat Declaration UN Hazmat Page | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationUNHazmatPageText` |
| Hazmat Declaration Flash Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration Flash Point | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration-flash-point` |
| Hazmat Declaration Flash Point | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Hazmat Declaration Flash Point | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationFlashPointMeasure` |
| Contact Information (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Information (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-information` |
| Contact Information (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Information (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationType` |
| Contact Information (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vy0xsgoam40pob60gu6mbrqo` |
| Contact Entity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Entity Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-entity-description` |
| Contact Entity Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Entity Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactEntityDescriptionText` |
| Contact Information Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Information Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-information-description` |
| Contact Information Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Information Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationDescriptionText` |
| Contact Information Availability Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Information Availability Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-information-availability-code` |
| Contact Information Availability Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Information Availability Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationAvailabilityCode` |
| Contact Information Availability Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationAvailabilityCodeSimpleType` |
| Address (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address` |
| Address (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressType` |
| Address (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tfg5f0628p7bajmz49u8k7cd` |
| Address Building Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Building Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-building-name` |
| Address Building Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Building Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressBuildingName` |
| Address County Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address County Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-county-name` |
| Address County Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address County Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCountyName` |
| Address Delivery Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Delivery Point | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-delivery-point` |
| Address Delivery Point | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Delivery Point | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressDeliveryPointText` |
| Address Full | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Full | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-full` |
| Address Full | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Full | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressFullText` |
| Address Postal Extension Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Postal Extension Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-postal-extension-code` |
| Address Postal Extension Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Postal Extension Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressPostalExtensionCode` |
| Address Private Mailbox | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Private Mailbox | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-private-mailbox` |
| Address Private Mailbox | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Private Mailbox | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressPrivateMailboxText` |
| Address Recipient Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Recipient Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-recipient-name` |
| Address Recipient Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Recipient Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressRecipientName` |
| Address Secondary Unit | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Secondary Unit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-secondary-unit` |
| Address Secondary Unit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Secondary Unit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressSecondaryUnitText` |
| Address Secondary Unit | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rng9tofh09ezkym5u5d8o6kr` |
| Address Urbanization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Urbanization Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-urbanization-name` |
| Address Urbanization Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Urbanization Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressUrbanizationName` |
| Address Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-category-code` |
| Address Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCategoryCode` |
| Address Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCategoryCodeSimpleType` |
| County (fips) | `dcterms:publisher` | `https://axius-sdc.com` |
| County (fips) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| County (fips) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/fips-county` |
| County (fips) | `skos:closeMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| County (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/CountyCode` |
| Code List: fips US County5 Digit | `dcterms:publisher` | `https://axius-sdc.com` |
| Code List: fips US County5 Digit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| Code List: fips US County5 Digit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/system-fips-us-county5-digit` |
| Code List: fips US County5 Digit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/code-display-text` |
| Code Display Text | `dcterms:source` | `https://www.w3.org/TR/skos-reference/` |
| Code Display Text | `skos:exactMatch` | `http://www.w3.org/2004/02/skos/core#prefLabel` |
| County Code (fips) | `dcterms:publisher` | `https://axius-sdc.com` |
| County Code (fips) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| County Code (fips) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/fips-county-code` |
| County Code (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/CountyCode` |
| County Code (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| International Address | `dcterms:publisher` | `https://axius-sdc.com` |
| International Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/international-address` |
| International Address | `dcterms:source` | `https://schema.org/` |
| International Address | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| International Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-g6qfe9l84vekq97kgvhtu3qw` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| Postal Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Postal Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/postal-code` |
| Postal Code | `dcterms:source` | `https://schema.org/` |
| Postal Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| Postal Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kgbwgi00bhxyyt176bsmulf0` |
| Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/region-name` |
| Region Name | `dcterms:source` | `https://schema.org/` |
| Region Name | `skos:exactMatch` | `https://schema.org/addressRegion` |
| Region Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fvgk640ozbukdci5swd6wytt` |
| Address Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Address Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-use` |
| Address Use | `skos:exactMatch` | `http://hl7.org/fhir/address-use` |
| Address Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-offwpyuzrbirkryvvbzqqg31` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Contact Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Point | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-point` |
| Contact Point | `dcterms:source` | `https://schema.org/` |
| Contact Point | `skos:exactMatch` | `https://schema.org/ContactPoint` |
| Contact Point | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pet65c3gbwhp7j2fyiglwv5q` |
| Website URL | `dcterms:publisher` | `https://axius-sdc.com` |
| Website URL | `dcterms:identifier` | `https://axius-sdc.com/library/default/website-url` |
| Website URL | `dcterms:source` | `https://schema.org/` |
| Website URL | `skos:exactMatch` | `https://schema.org/url` |
| Website URL | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t4fl1c1qbhmgyem3fczjdq16` |
| Email Address | `dcterms:publisher` | `https://axius-sdc.com` |
| Email Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/email-address` |
| Email Address | `dcterms:source` | `https://www.rfc-editor.org/rfc/rfc5321` |
| Email Address | `skos:exactMatch` | `https://schema.org/email` |
| Email Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uvl0tla5aocdzsdrby589b6l` |
| Fax Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Fax Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Fax Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/fax-number` |
| Fax Number | `skos:exactMatch` | `https://schema.org/faxNumber` |
| Fax Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hzpld81b2ddnp5qywombgpls` |
| Phone Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Phone Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Phone Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/phone-number` |
| Phone Number | `skos:exactMatch` | `https://schema.org/telephone` |
| Phone Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ma9dwgbrvprfyypwldni2qfx` |
| Contact Method | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Method | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Method | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-method` |
| Contact Method | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-system` |
| Contact Method | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tf5wlywn6meurn6o1sz8yuaq` |
| Contact Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-use` |
| Contact Use | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-use` |
| Contact Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-klgho4tqvbu5iyt6zzx1ioi9` |
| Hazmat Declaration UN Hazmat (hazmat) | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration UN Hazmat (hazmat) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration-un-hazmat` |
| Hazmat Declaration UN Hazmat (hazmat) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Hazmat Declaration UN Hazmat (hazmat) | `skos:closeMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/hazmat/6.0/HazmatCodeSimpleType` |
| Hazmat Declaration UN Hazmat (hazmat) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationUNHazmatCode` |
| Code List: hazmat Hazmat | `dcterms:publisher` | `https://axius-sdc.com` |
| Code List: hazmat Hazmat | `dcterms:identifier` | `https://axius-sdc.com/library/niem/system-hazmat-hazmat` |
| Code List: hazmat Hazmat | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/hazmat/6.0/HazmatCodeSimpleType` |
| Code List: hazmat Hazmat | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/hazmat.xsd` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/code-display-text` |
| Code Display Text | `dcterms:source` | `https://www.w3.org/TR/skos-reference/` |
| Code Display Text | `skos:exactMatch` | `http://www.w3.org/2004/02/skos/core#prefLabel` |
| Hazmat Declaration UN Hazmat Code (hazmat) | `dcterms:publisher` | `https://axius-sdc.com` |
| Hazmat Declaration UN Hazmat Code (hazmat) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-hazmat-declaration-un-hazmat-code` |
| Hazmat Declaration UN Hazmat Code (hazmat) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/hazmat/6.0/HazmatCodeSimpleType` |
| Hazmat Declaration UN Hazmat Code (hazmat) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/HazmatDeclarationUNHazmatCode` |
| Hazmat Declaration UN Hazmat Code (hazmat) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/hazmat.xsd` |
| Person on Vessel | `dcterms:publisher` | `https://axius-sdc.com` |
| Person on Vessel | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-person-on-vessel` |
| Person on Vessel | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Person on Vessel | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PersonOnVesselType` |
| Person on Vessel | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rymr4hdxwigbfc7hvxqcbiqb` |
| Crew Role | `dcterms:publisher` | `https://axius-sdc.com` |
| Crew Role | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-crew-role` |
| Crew Role | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Crew Role | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CrewRoleText` |
| Person Cabin Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Cabin Number | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-person-cabin-number` |
| Person Cabin Number | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Person Cabin Number | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PersonCabinNumberText` |
| Person Debarkation Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Debarkation Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-person-debarkation-location-reference` |
| Person Debarkation Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Person Debarkation Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PersonDebarkationLocation` |
| Person Embarkation Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Embarkation Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-person-embarkation-location-reference` |
| Person Embarkation Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Person Embarkation Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PersonEmbarkationLocation` |
| Crew Role Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Crew Role Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-crew-role-code` |
| Crew Role Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Crew Role Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CrewRoleCode` |
| Crew Role Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CrewRoleCodeSimpleType` |
| Person Debarkation Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Debarkation Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-person-debarkation-date` |
| Person Debarkation Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Person Debarkation Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PersonDebarkationDate` |
| Person Embarkation Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Embarkation Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-person-embarkation-date` |
| Person Embarkation Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Person Embarkation Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PersonEmbarkationDate` |
| Person Country Of Residence ISO3166 Alpha2 (iso_3166) | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Country Of Residence ISO3166 Alpha2 (iso_3166) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-person-country-of-residence-iso-3166` |
| Person Country Of Residence ISO3166 Alpha2 (iso_3166) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Person Country Of Residence ISO3166 Alpha2 (iso_3166) | `skos:closeMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/iso_3166-1/6.0/CountryAlpha2CodeSimpleType` |
| Person Country Of Residence ISO3166 Alpha2 (iso_3166) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PersonCountryOfResidenceISO3166Alpha2Code` |
| Code List: iso_3166 Country Alpha2 | `dcterms:publisher` | `https://axius-sdc.com` |
| Code List: iso_3166 Country Alpha2 | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/iso_3166.xsd` |
| Code List: iso_3166 Country Alpha2 | `dcterms:identifier` | `https://axius-sdc.com/library/niem/system-iso-3166-country-alpha2` |
| Code List: iso_3166 Country Alpha2 | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/iso_3166-1/6.0/CountryAlpha2CodeSimpleType` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/code-display-text` |
| Code Display Text | `dcterms:source` | `https://www.w3.org/TR/skos-reference/` |
| Code Display Text | `skos:exactMatch` | `http://www.w3.org/2004/02/skos/core#prefLabel` |
| Person Country Of Residence ISO3166 Alpha2 Code (iso_3166) | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Country Of Residence ISO3166 Alpha2 Code (iso_3166) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/iso_3166.xsd` |
| Person Country Of Residence ISO3166 Alpha2 Code (iso_3166) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-person-country-of-residence-iso-3166-code` |
| Person Country Of Residence ISO3166 Alpha2 Code (iso_3166) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/iso_3166-1/6.0/CountryAlpha2CodeSimpleType` |
| Person Country Of Residence ISO3166 Alpha2 Code (iso_3166) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PersonCountryOfResidenceISO3166Alpha2Code` |
| Person (Demographics) | `dcterms:publisher` | `https://axius-sdc.com` |
| Person (Demographics) | `dcterms:identifier` | `https://axius-sdc.com/library/default/person-demographics` |
| Person (Demographics) | `dcterms:source` | `https://schema.org/` |
| Person (Demographics) | `skos:exactMatch` | `https://schema.org/Person` |
| Administrative Gender | `dcterms:publisher` | `https://axius-sdc.com` |
| Administrative Gender | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Administrative Gender | `dcterms:identifier` | `https://axius-sdc.com/library/default/administrative-gender` |
| Administrative Gender | `skos:exactMatch` | `http://hl7.org/fhir/administrative-gender` |
| Administrative Gender | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tnyh2ude3db9smwfin0vai5h` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Language Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Language Code | `dcterms:source` | `https://www.iso.org/iso-639-language-code` |
| Language Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/language-code` |
| Language Code | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C16779` |
| Language Code | `skos:exactMatch` | `https://schema.org/inLanguage` |
| Language Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w7t802u535su9576z02uw71o` |
| Date of Birth | `dcterms:publisher` | `https://axius-sdc.com` |
| Date of Birth | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-of-birth` |
| Date of Birth | `dcterms:source` | `https://schema.org/` |
| Date of Birth | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68615` |
| Date of Birth | `skos:exactMatch` | `https://schema.org/birthDate` |
| Full Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Full Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/full-name-person` |
| Full Name (Person) | `dcterms:source` | `https://schema.org/` |
| Full Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q1071027` |
| Full Name (Person) | `skos:exactMatch` | `https://schema.org/Person` |
| Full Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gwpvlduwrtpog4kpidaenshn` |
| Given Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Given Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/given-name-person` |
| Given Name (Person) | `dcterms:source` | `https://schema.org/` |
| Given Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q202444` |
| Given Name (Person) | `skos:exactMatch` | `https://schema.org/givenName` |
| Given Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kfyzf8u8gdafcpt5kfh2qg3q` |
| Middle Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Middle Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/middle-name-person` |
| Middle Name (Person) | `dcterms:source` | `https://schema.org/` |
| Middle Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q245025` |
| Middle Name (Person) | `skos:exactMatch` | `https://schema.org/additionalName` |
| Middle Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-oit0ueglhjfcyq80z22kl2z3` |
| Name Prefix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Prefix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-prefix` |
| Name Prefix | `dcterms:source` | `https://schema.org/` |
| Name Prefix | `skos:exactMatch` | `https://schema.org/honorificPrefix` |
| Name Prefix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-u9x2b6frfi0rbydeoncijfp1` |
| Name Suffix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Suffix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-suffix` |
| Name Suffix | `dcterms:source` | `https://schema.org/` |
| Name Suffix | `skos:exactMatch` | `https://schema.org/honorificSuffix` |
| Name Suffix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zldtbpvyouzi7t1dorc07rb3` |
| Surname (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Surname (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/surname-person` |
| Surname (Person) | `dcterms:source` | `https://schema.org/` |
| Surname (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q101352` |
| Surname (Person) | `skos:exactMatch` | `https://schema.org/familyName` |
| Surname (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-v8jgjo2sml12jo7zrb8swoxi` |
| Name Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Name Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-use` |
| Name Use | `skos:exactMatch` | `http://hl7.org/fhir/name-use` |
| Name Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zlg3riiu515tsg0mdkx5brkc` |
| Visa | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa | `dcterms:identifier` | `https://axius-sdc.com/library/niem/im-visa` |
| Visa | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaType` |
| Visa | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jnhikeuhrihkirmh02j7kirh` |
| Visa Waiver Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa Waiver Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-visa-waiver-indicator` |
| Visa Waiver Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa Waiver Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaWaiverIndicator` |
| Document Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-identification` |
| Document Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentIdentification` |
| Visa Application Disposition Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa Application Disposition Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-visa-application-disposition-status` |
| Visa Application Disposition Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa Application Disposition Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaApplicationDispositionStatus` |
| Visa Application Disposition Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-czxycboamto4a6ohk14ghtfe` |
| Visa Application Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa Application Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-visa-application-location-reference` |
| Visa Application Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa Application Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaApplicationLocation` |
| Visa Application Location Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jqwukrf0dyc3f4gqrtxhkt0k` |
| Visa Cancel Category Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa Cancel Category Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-visa-cancel-category-description` |
| Visa Cancel Category Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa Cancel Category Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaCancelCategoryDescriptionText` |
| Visa Control Number ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa Control Number ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-visa-control-number-id` |
| Visa Control Number ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa Control Number ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaControlNumberID` |
| Visa Foil Number ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa Foil Number ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-visa-foil-number-id` |
| Visa Foil Number ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa Foil Number ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaFoilNumberID` |
| Visa Number ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa Number ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-visa-number-id` |
| Visa Number ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa Number ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaNumberID` |
| Visa Number ID | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dqnpy9i163wwnlqo4stuivos` |
| Document Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-document-category-code` |
| Document Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Document Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/DocumentCategoryCode` |
| Document Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/DocumentCategoryCodeSimpleType` |
| Document Category Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kxxj8kpa4x5g9ixvj8usfgqk` |
| Visa Cancel Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa Cancel Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-visa-cancel-category-code` |
| Visa Cancel Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa Cancel Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaCancelCategoryCode` |
| Visa Cancel Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaCancelCategoryCodeSimpleType` |
| Visa Cancel Category Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-p8fecuvt0hzcpfd76u3u99b0` |
| Document Expiration Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Expiration Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-expiration-date` |
| Document Expiration Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Expiration Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentExpirationDate` |
| Document Issue Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Issue Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-issue-date` |
| Document Issue Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Issue Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentIssueDate` |
| Visa Application Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Visa Application Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/scr-visa-application-date` |
| Visa Application Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/screening.xsd` |
| Visa Application Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/screening/6.0/VisaApplicationDate` |
| Person Citizenship Country (genc) | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Citizenship Country (genc) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-citizenship-country-genc` |
| Person Citizenship Country (genc) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Person Citizenship Country (genc) | `skos:closeMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/genc/6.0/CountryAlpha3CodeSimpleType` |
| Person Citizenship Country (genc) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonCitizenshipCountry` |
| Code List: genc Country Alpha3 | `dcterms:publisher` | `https://axius-sdc.com` |
| Code List: genc Country Alpha3 | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/genc.xsd` |
| Code List: genc Country Alpha3 | `dcterms:identifier` | `https://axius-sdc.com/library/niem/system-genc-country-alpha3` |
| Code List: genc Country Alpha3 | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/genc/6.0/CountryAlpha3CodeSimpleType` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/code-display-text` |
| Code Display Text | `dcterms:source` | `https://www.w3.org/TR/skos-reference/` |
| Code Display Text | `skos:exactMatch` | `http://www.w3.org/2004/02/skos/core#prefLabel` |
| Person Citizenship Country Code (genc) | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Citizenship Country Code (genc) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/genc.xsd` |
| Person Citizenship Country Code (genc) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-citizenship-country-genc-code` |
| Person Citizenship Country Code (genc) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/genc/6.0/CountryAlpha3CodeSimpleType` |
| Person Citizenship Country Code (genc) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonCitizenshipCountry` |
| Port Fees | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Fees | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Port Fees | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/port-fees` |
| Port Fees | `skos:closeMatch` | `https://schema.org/ItemList` |
| Port Fees | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-emtr91lypy400ttgzz2ti4et` |
| Fee Type | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1912682` |
| Fee Type | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Fee Type | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Payment Status | `rdfs:isDefinedBy` | `http://schema.org/PaymentStatusType` |
| Payment Status | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Payment Status | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Port Fee Amount | `rdfs:isDefinedBy` | `https://schema.org/MonetaryAmount` |
| Port Fee Amount | `skos:broadMatch` | `http://qudt.org/vocab/quantitykind/Currency` |
| Port Fee Amount | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1194642` |
| Fee Date | `rdfs:isDefinedBy` | `http://release.niem.gov/niem/niem-core/6.0/AssessmentDate` |
| Fee Date | `skos:broadMatch` | `https://schema.org/Date` |
| Port Visit | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Visit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-visit` |
| Port Visit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Visit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortVisitType` |
| Port Visit | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qfybgu98m2fzrxqz41arf1da` |
| Visit Anchorage | `dcterms:publisher` | `https://axius-sdc.com` |
| Visit Anchorage | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-visit-anchorage` |
| Visit Anchorage | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Visit Anchorage | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VisitAnchorageText` |
| Visit Anchorage | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-h8l9f0s1823pxyztv29ohbce` |
| Visit Location In Port Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Visit Location In Port Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-visit-location-in-port-reference` |
| Visit Location In Port Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Visit Location In Port Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VisitLocationInPort` |
| Visit Receiving Facility Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Visit Receiving Facility Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-visit-receiving-facility-name` |
| Visit Receiving Facility Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Visit Receiving Facility Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VisitReceivingFacilityName` |
| Visit Actual Arrival Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Visit Actual Arrival Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-visit-actual-arrival-date-time` |
| Visit Actual Arrival Date Time | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Visit Actual Arrival Date Time | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VisitActualArrivalDateTime` |
| Visit Actual Departure Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Visit Actual Departure Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-visit-actual-departure-date-time` |
| Visit Actual Departure Date Time | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Visit Actual Departure Date Time | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VisitActualDepartureDateTime` |
| Visit Expected Arrival Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Visit Expected Arrival Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-visit-expected-arrival-date-time` |
| Visit Expected Arrival Date Time | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Visit Expected Arrival Date Time | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VisitExpectedArrivalDateTime` |
| Visit Expected Departure Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Visit Expected Departure Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-visit-expected-departure-date-time` |
| Visit Expected Departure Date Time | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Visit Expected Departure Date Time | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VisitExpectedDepartureDateTime` |
| Port | `dcterms:publisher` | `https://axius-sdc.com` |
| Port | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port` |
| Port | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortType` |
| Port ISPS Compliant Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Port ISPS Compliant Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-isps-compliant-indicator` |
| Port ISPS Compliant Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port ISPS Compliant Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortISPSCompliantIndicator` |
| Port Strategic Port Of Embarkation Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Strategic Port Of Embarkation Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-strategic-port-of-embarkation-indicator` |
| Port Strategic Port Of Embarkation Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Strategic Port Of Embarkation Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortStrategicPortOfEmbarkationIndicator` |
| Port Anchorage Capability | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Anchorage Capability | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-anchorage-capability` |
| Port Anchorage Capability | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Anchorage Capability | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortAnchorageCapabilityText` |
| Port BE Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Port BE Number | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-be-number` |
| Port BE Number | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port BE Number | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortBENumberText` |
| Port Cargo Capability | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Cargo Capability | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-cargo-capability` |
| Port Cargo Capability | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Cargo Capability | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortCargoCapabilityText` |
| Port Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-code` |
| Port Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortCodeText` |
| Port Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zhr7nivnuy8he30ql749ad9z` |
| Port Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-description` |
| Port Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortDescriptionText` |
| Port Government | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Government | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-government` |
| Port Government | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Government | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortGovernmentText` |
| Port Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-name` |
| Port Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortName` |
| Port Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-r5bgu6yk4epub3l1b3fzngxa` |
| Port Operational Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Operational Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-operational-status` |
| Port Operational Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Operational Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortOperationalStatus` |
| Port Threat Level | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Threat Level | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-threat-level` |
| Port Threat Level | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Threat Level | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortThreatLevelText` |
| Port UNLOCODE | `dcterms:publisher` | `https://axius-sdc.com` |
| Port UNLOCODE | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-unlocode` |
| Port UNLOCODE | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port UNLOCODE | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortUNLOCODEText` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/region-name` |
| Region Name | `dcterms:source` | `https://schema.org/` |
| Region Name | `skos:exactMatch` | `https://schema.org/addressRegion` |
| Region Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fvgk640ozbukdci5swd6wytt` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Port Depth | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Depth | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-depth` |
| Port Depth | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Depth | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortDepthMeasure` |
| Port Dock Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Dock Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-dock-quantity` |
| Port Dock Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Dock Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortDockQuantity` |
| Port Maximum Vessel Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Maximum Vessel Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-maximum-vessel-quantity` |
| Port Maximum Vessel Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Maximum Vessel Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortMaximumVesselQuantity` |
| Port Pilot Boat Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Port Pilot Boat Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-port-pilot-boat-quantity` |
| Port Pilot Boat Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Port Pilot Boat Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/PortPilotBoatQuantity` |
| Vessel | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel` |
| Vessel | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselAugmentationType` |
| Vessel | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xsfd3dvd45kxd3o486m8bf6l` |
| Vessel Cargo On Board Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Cargo On Board Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-cargo-on-board-indicator` |
| Vessel Cargo On Board Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Cargo On Board Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCargoOnBoardIndicator` |
| Vessel Cargo On Board Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-opmet8bwgwu04p6szx3t0g05` |
| Vessel CDC Capable Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel CDC Capable Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-cdc-capable-indicator` |
| Vessel CDC Capable Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel CDC Capable Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCDCCapableIndicator` |
| Vessel CDC Cargo On Board Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel CDC Cargo On Board Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-cdc-cargo-on-board-indicator` |
| Vessel CDC Cargo On Board Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel CDC Cargo On Board Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCDCCargoOnBoardIndicator` |
| Vessel CVSSA On Board Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel CVSSA On Board Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-cvssa-on-board-indicator` |
| Vessel CVSSA On Board Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel CVSSA On Board Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCVSSAOnBoardIndicator` |
| Vessel Non Tank Vessel Response Plan Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Non Tank Vessel Response Plan Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-non-tank-vessel-response-plan-indicator` |
| Vessel Non Tank Vessel Response Plan Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Non Tank Vessel Response Plan Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselNonTankVesselResponsePlanIndicator` |
| Vessel Activity History Summary | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Activity History Summary | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-activity-history-summary` |
| Vessel Activity History Summary | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Activity History Summary | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselActivityHistorySummaryText` |
| Vessel Call Sign | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Call Sign | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-call-sign` |
| Vessel Call Sign | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Call Sign | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCallSignText` |
| Vessel Call Sign | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qlqdwbglcq4v3rg8i8iy7dk0` |
| Vessel Cargo Capability | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Cargo Capability | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-cargo-capability` |
| Vessel Cargo Capability | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Cargo Capability | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCargoCapabilityText` |
| Vessel Cargo Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Cargo Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-cargo-category` |
| Vessel Cargo Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Cargo Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCargoCategoryText` |
| Vessel Charterer Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Charterer Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-charterer-reference` |
| Vessel Charterer Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Charterer Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCharterer` |
| Vessel Class | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Class | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-class` |
| Vessel Class | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Class | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselClassText` |
| Vessel Classification Society Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Classification Society Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-classification-society-name` |
| Vessel Classification Society Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Classification Society Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselClassificationSocietyName` |
| Vessel Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-description` |
| Vessel Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselDescriptionText` |
| Vessel Engine Category Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Engine Category Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-engine-category-description` |
| Vessel Engine Category Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Engine Category Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselEngineCategoryDescriptionText` |
| Vessel Fuel Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Fuel Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-fuel-category` |
| Vessel Fuel Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Fuel Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselFuelCategoryText` |
| Vessel Hailing Port Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Hailing Port Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-hailing-port-reference` |
| Vessel Hailing Port Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Hailing Port Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselHailingPort` |
| Vessel HIN | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel HIN | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-hin` |
| Vessel HIN | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel HIN | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselHINText` |
| Vessel Hull Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Hull Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-hull-category` |
| Vessel Hull Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Hull Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselHullCategoryText` |
| Vessel Hull Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Hull Number | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-hull-number` |
| Vessel Hull Number | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Hull Number | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselHullNumberText` |
| Vessel Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-identification` |
| Vessel Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselIdentification` |
| Vessel IMO Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel IMO Number | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-imo-number` |
| Vessel IMO Number | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel IMO Number | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselIMONumberText` |
| Vessel IMO Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ycy71t767wlyqma97o82r2m9` |
| Vessel Incident History Summary | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Incident History Summary | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-incident-history-summary` |
| Vessel Incident History Summary | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Incident History Summary | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselIncidentHistorySummaryText` |
| Vessel IRCS | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel IRCS | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-ircs` |
| Vessel IRCS | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel IRCS | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselIRCSText` |
| Vessel ISSC Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel ISSC Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-issc-reference` |
| Vessel ISSC Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel ISSC Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselISSC` |
| Vessel Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-location-reference` |
| Vessel Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselLocation` |
| Vessel Manager Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Manager Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-manager-reference` |
| Vessel Manager Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Manager Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselManager` |
| Vessel MMSI | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel MMSI | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-mmsi` |
| Vessel MMSI | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel MMSI | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselMMSIText` |
| Vessel MMSI | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-cl1hiqht7tm42a8lh8c4c1hz` |
| Vessel Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-name` |
| Vessel Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselName` |
| Vessel Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-s5zeapfup3xdj6wbqjjkf1nd` |
| Vessel National Flag | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel National Flag | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-national-flag` |
| Vessel National Flag | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel National Flag | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselNationalFlagText` |
| Vessel Navigation Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Navigation Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-navigation-status` |
| Vessel Navigation Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Navigation Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselNavigationStatus` |
| Vessel Non Tank Vessel Response Plan Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Non Tank Vessel Response Plan Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-non-tank-vessel-response-plan-identification` |
| Vessel Non Tank Vessel Response Plan Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Non Tank Vessel Response Plan Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselNonTankVesselResponsePlanIdentification` |
| Vessel Official Coast Guard Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Official Coast Guard Number | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-official-coast-guard-number` |
| Vessel Official Coast Guard Number | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Official Coast Guard Number | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselOfficialCoastGuardNumberText` |
| Vessel Operator Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Operator Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-operator-reference` |
| Vessel Operator Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Operator Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselOperator` |
| Vessel Owner Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Owner Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-owner-reference` |
| Vessel Owner Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Owner Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselOwner` |
| Vessel Safety Management Certificate Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Safety Management Certificate Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-safety-management-certificate-reference` |
| Vessel Safety Management Certificate Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Safety Management Certificate Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselSafetyManagementCertificate` |
| Vessel SCONUM | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel SCONUM | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-sconum` |
| Vessel SCONUM | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel SCONUM | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselSCONUMText` |
| Vessel State Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel State Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-state-identification` |
| Vessel State Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel State Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselStateIdentification` |
| Vessel Sub Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Sub Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-sub-category` |
| Vessel Sub Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Sub Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselSubCategoryText` |
| Vessel Hull Color Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Hull Color Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-hull-color-code` |
| Vessel Hull Color Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Hull Color Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ncic/6.0/VCOCodeSimpleType` |
| Vessel Hull Color Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselHullColorCode` |
| Vessel Operational Condition Of Equipment Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Operational Condition Of Equipment Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-operational-condition-of-equipment-code` |
| Vessel Operational Condition Of Equipment Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Operational Condition Of Equipment Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselOperationalConditionOfEquipmentCode` |
| Vessel Operational Condition Of Equipment Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselOperationalConditionOfEquipmentCodeSimpleType` |
| Vessel Image | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Image | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-image` |
| Vessel Image | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Image | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselImage` |
| Vessel Gross Tonnage Value | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Gross Tonnage Value | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-gross-tonnage-value` |
| Vessel Gross Tonnage Value | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Gross Tonnage Value | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselGrossTonnageValue` |
| Vessel Gross Tonnage Value | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-a10qprrdjou8vnb0powql2dg` |
| Vessel Beam | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Beam | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-beam` |
| Vessel Beam | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Beam | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselBeamMeasure` |
| Vessel Beam | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-g54kf9p7oexwe7hqezd66rwu` |
| Vessel Crane Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Crane Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-crane-quantity` |
| Vessel Crane Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Crane Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCraneQuantity` |
| Vessel Cruise Range | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Cruise Range | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-cruise-range` |
| Vessel Cruise Range | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Cruise Range | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCruiseRangeMeasure` |
| Vessel Cruise Speed | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Cruise Speed | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-cruise-speed` |
| Vessel Cruise Speed | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Cruise Speed | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselCruiseSpeedMeasure` |
| Vessel Dead Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Dead Weight | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-dead-weight` |
| Vessel Dead Weight | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Dead Weight | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselDeadWeightMeasure` |
| Vessel Displacement | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Displacement | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-displacement` |
| Vessel Displacement | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Displacement | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselDisplacementMeasure` |
| Vessel Draft | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Draft | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-draft` |
| Vessel Draft | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Draft | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselDraftMeasure` |
| Vessel Draft | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fk4w1t4dums1j7lkpl8tcd6e` |
| Vessel Draft Unloaded | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Draft Unloaded | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-draft-unloaded` |
| Vessel Draft Unloaded | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Draft Unloaded | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselDraftUnloadedMeasure` |
| Vessel Endurance | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Endurance | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-endurance` |
| Vessel Endurance | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Endurance | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselEnduranceMeasure` |
| Vessel Fuel Consumption Rate | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Fuel Consumption Rate | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-fuel-consumption-rate` |
| Vessel Fuel Consumption Rate | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Fuel Consumption Rate | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselFuelConsumptionRateMeasure` |
| Vessel Holds Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Holds Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-holds-quantity` |
| Vessel Holds Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Holds Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselHoldsQuantity` |
| Vessel Mast Height | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Mast Height | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-mast-height` |
| Vessel Mast Height | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Mast Height | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselMastHeightMeasure` |
| Vessel Maximum Crew Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Maximum Crew Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-maximum-crew-quantity` |
| Vessel Maximum Crew Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Maximum Crew Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselMaximumCrewQuantity` |
| Vessel Maximum Passenger Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Maximum Passenger Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-maximum-passenger-quantity` |
| Vessel Maximum Passenger Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Maximum Passenger Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselMaximumPassengerQuantity` |
| Vessel Maximum Range | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Maximum Range | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-maximum-range` |
| Vessel Maximum Range | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Maximum Range | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselMaximumRangeMeasure` |
| Vessel Maximum Speed | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Maximum Speed | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-maximum-speed` |
| Vessel Maximum Speed | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Maximum Speed | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselMaximumSpeedMeasure` |
| Vessel Maximum Static Draft | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Maximum Static Draft | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-maximum-static-draft` |
| Vessel Maximum Static Draft | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Maximum Static Draft | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselMaximumStaticDraftMeasure` |
| Vessel Net Tonnage Volume | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Net Tonnage Volume | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-net-tonnage-volume` |
| Vessel Net Tonnage Volume | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Net Tonnage Volume | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselNetTonnageVolumeMeasure` |
| Vessel Net Tonnage Volume | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ekp9r360ica3nb8ky8dbs4sk` |
| Vessel Overall Length | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Overall Length | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-overall-length` |
| Vessel Overall Length | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Overall Length | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselOverallLengthMeasure` |
| Vessel Overall Length | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l85tokp0c6ddmdqq2yeayhht` |
| Vessel Ramp Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Ramp Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-ramp-quantity` |
| Vessel Ramp Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Ramp Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselRampQuantity` |
| Vessel Build Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Build Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-build-date` |
| Vessel Build Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Build Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselBuildDate` |
| Vessel Keel Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel Keel Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-keel-date` |
| Vessel Keel Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel Keel Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselKeelDate` |
| Certificate (Maritime) | `dcterms:publisher` | `https://axius-sdc.com` |
| Certificate (Maritime) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-certificate` |
| Certificate (Maritime) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Certificate (Maritime) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CertificateType` |
| Certificate (Maritime) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-k1a15knx12lfgqu12y7468k0` |
| Certificate Endorsement | `dcterms:publisher` | `https://axius-sdc.com` |
| Certificate Endorsement | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-certificate-endorsement` |
| Certificate Endorsement | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Certificate Endorsement | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CertificateEndorsementText` |
| Certificate Issuing Agency Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Certificate Issuing Agency Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-certificate-issuing-agency-reference` |
| Certificate Issuing Agency Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Certificate Issuing Agency Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CertificateIssuingAgency` |
| Certificate Jurisdiction Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Certificate Jurisdiction Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-certificate-jurisdiction-reference` |
| Certificate Jurisdiction Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Certificate Jurisdiction Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CertificateJurisdiction` |
| Certificate Restriction | `dcterms:publisher` | `https://axius-sdc.com` |
| Certificate Restriction | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-certificate-restriction` |
| Certificate Restriction | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Certificate Restriction | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CertificateRestrictionText` |
| Certificate Issue Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Certificate Issue Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-certificate-issue-date` |
| Certificate Issue Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Certificate Issue Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/CertificateIssueDate` |
| Document (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Document (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document` |
| Document (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentType` |
| Document (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tko8bi13ybw5pdtxiy939hpb` |
| Document Approved Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Approved Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-approved-indicator` |
| Document Approved Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Approved Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentApprovedIndicator` |
| Document Copyright Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Copyright Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-copyright-indicator` |
| Document Copyright Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Copyright Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentCopyrightIndicator` |
| Document Permanent Record Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Permanent Record Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-permanent-record-indicator` |
| Document Permanent Record Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Permanent Record Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentPermanentRecordIndicator` |
| Document Privacy Act Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Privacy Act Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-privacy-act-indicator` |
| Document Privacy Act Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Privacy Act Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentPrivacyActIndicator` |
| Document Vital Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Vital Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-vital-indicator` |
| Document Vital Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Vital Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentVitalIndicator` |
| Document Author Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Author Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-author-reference` |
| Document Author Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Author Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentAuthor` |
| Document Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-category-text` |
| Document Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentCategoryText` |
| Document Contributor Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Contributor Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-contributor-reference` |
| Document Contributor Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Contributor Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentContributor` |
| Document Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-description` |
| Document Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentDescriptionText` |
| Document File Control ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Document File Control ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-file-control-id` |
| Document File Control ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document File Control ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentFileControlID` |
| Document File Extension | `dcterms:publisher` | `https://axius-sdc.com` |
| Document File Extension | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-file-extension` |
| Document File Extension | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document File Extension | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentFileExtensionText` |
| Document File Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Document File Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-file-name` |
| Document File Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document File Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentFileName` |
| Document Group ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Group ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-group-id` |
| Document Group ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Group ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentGroupID` |
| Document Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-identification` |
| Document Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentIdentification` |
| Document Keyword | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Keyword | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-keyword` |
| Document Keyword | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Keyword | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentKeywordText` |
| Document Location URI | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Location URI | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-location-uri` |
| Document Location URI | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Location URI | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentLocationURI` |
| Document Recipient Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Recipient Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-recipient-reference` |
| Document Recipient Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Recipient Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentRecipient` |
| Document Rights | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Rights | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-rights` |
| Document Rights | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Rights | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentRightsText` |
| Document Sensitivity | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Sensitivity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-sensitivity` |
| Document Sensitivity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Sensitivity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentSensitivityText` |
| Document Sequence ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Sequence ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-sequence-id` |
| Document Sequence ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Sequence ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentSequenceID` |
| Document Source Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Source Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-source-reference` |
| Document Source Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Source Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentSource` |
| Document Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-status` |
| Document Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentStatus` |
| Document Subject | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Subject | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-subject` |
| Document Subject | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Subject | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentSubjectText` |
| Document Submitter Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Submitter Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-submitter-reference` |
| Document Submitter Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Submitter Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentSubmitter` |
| Document Summary | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Summary | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-summary` |
| Document Summary | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Summary | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentSummaryText` |
| Document Supplemental Marking | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Supplemental Marking | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-supplemental-marking` |
| Document Supplemental Marking | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Supplemental Marking | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentSupplementalMarkingText` |
| Document Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-text` |
| Document Text | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Text | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentText` |
| Document Title | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Title | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-title` |
| Document Title | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Title | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentTitleText` |
| Document Title Alternative | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Title Alternative | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-title-alternative` |
| Document Title Alternative | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Title Alternative | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentTitleAlternativeText` |
| Media Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Media Type | `dcterms:source` | `https://www.w3.org/TR/vocab-dcat-3/` |
| Media Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/media-type` |
| Media Type | `skos:exactMatch` | `http://www.w3.org/ns/dcat#mediaType` |
| Media Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gui6g8hnwaj1p63gyvx8mahw` |
| Language Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Language Code | `dcterms:source` | `https://www.iso.org/iso-639-language-code` |
| Language Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/language-code` |
| Language Code | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C16779` |
| Language Code | `skos:exactMatch` | `https://schema.org/inLanguage` |
| Language Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w7t802u535su9576z02uw71o` |
| Document Binary | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Binary | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-binary` |
| Document Binary | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Binary | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentBinary` |
| Document Submission Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Submission Amount | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-submission-amount` |
| Document Submission Amount | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Submission Amount | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentSubmissionAmount` |
| Document Creation Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Creation Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-creation-date` |
| Document Creation Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Creation Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentCreationDate` |
| Document Effective Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Effective Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-effective-date` |
| Document Effective Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Effective Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentEffectiveDate` |
| Document Expiration Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Expiration Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-expiration-date` |
| Document Expiration Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Expiration Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentExpirationDate` |
| Document Filed Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Filed Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-filed-date` |
| Document Filed Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Filed Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentFiledDate` |
| Document Filed Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ol1dxg5wdbuh4695sw0td0g6` |
| Document Issue Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Issue Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-issue-date` |
| Document Issue Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Issue Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentIssueDate` |
| Document Last Modified Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Last Modified Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-last-modified-date` |
| Document Last Modified Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Last Modified Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentLastModifiedDate` |
| Document Publication Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Publication Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-publication-date` |
| Document Publication Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Publication Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentPublicationDate` |
| Document Received Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Document Received Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/document-received-date` |
| Document Received Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Document Received Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DocumentReceivedDate` |
| Vessel National Flag ISO3166 Alpha2 (iso_3166) | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel National Flag ISO3166 Alpha2 (iso_3166) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-national-flag-iso-3166` |
| Vessel National Flag ISO3166 Alpha2 (iso_3166) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Vessel National Flag ISO3166 Alpha2 (iso_3166) | `skos:closeMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/iso_3166-1/6.0/CountryAlpha2CodeSimpleType` |
| Vessel National Flag ISO3166 Alpha2 (iso_3166) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselNationalFlagISO3166Alpha2Code` |
| Code List: iso_3166 Country Alpha2 | `dcterms:publisher` | `https://axius-sdc.com` |
| Code List: iso_3166 Country Alpha2 | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/iso_3166.xsd` |
| Code List: iso_3166 Country Alpha2 | `dcterms:identifier` | `https://axius-sdc.com/library/niem/system-iso-3166-country-alpha2` |
| Code List: iso_3166 Country Alpha2 | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/iso_3166-1/6.0/CountryAlpha2CodeSimpleType` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/code-display-text` |
| Code Display Text | `dcterms:source` | `https://www.w3.org/TR/skos-reference/` |
| Code Display Text | `skos:exactMatch` | `http://www.w3.org/2004/02/skos/core#prefLabel` |
| Vessel National Flag ISO3166 Alpha2 Code (iso_3166) | `dcterms:publisher` | `https://axius-sdc.com` |
| Vessel National Flag ISO3166 Alpha2 Code (iso_3166) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/iso_3166.xsd` |
| Vessel National Flag ISO3166 Alpha2 Code (iso_3166) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-vessel-national-flag-iso-3166-code` |
| Vessel National Flag ISO3166 Alpha2 Code (iso_3166) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/iso_3166-1/6.0/CountryAlpha2CodeSimpleType` |
| Vessel National Flag ISO3166 Alpha2 Code (iso_3166) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VesselNationalFlagISO3166Alpha2Code` |
| Voyage | `dcterms:publisher` | `https://axius-sdc.com` |
| Voyage | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-voyage` |
| Voyage | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Voyage | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VoyageType` |
| Voyage | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x86d6fjbzeswre8jtaur0by5` |
| Voyage Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Voyage Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-voyage-category` |
| Voyage Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Voyage Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VoyageCategoryText` |
| Voyage Destination Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Voyage Destination Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-voyage-destination-location-reference` |
| Voyage Destination Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Voyage Destination Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VoyageDestinationLocation` |
| Voyage Destination Location Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rt83ltlf0i2dktzfqbd1oybc` |
| Voyage Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Voyage Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-voyage-identification` |
| Voyage Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Voyage Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VoyageIdentification` |
| Voyage Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bmoixtn8r8pu62gbgd1tl8qn` |
| Voyage Summary | `dcterms:publisher` | `https://axius-sdc.com` |
| Voyage Summary | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-voyage-summary` |
| Voyage Summary | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Voyage Summary | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VoyageSummaryText` |
| Voyage Vessel Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Voyage Vessel Use | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-voyage-vessel-use` |
| Voyage Vessel Use | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Voyage Vessel Use | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VoyageVesselUseText` |
| Voyage Vessel Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lyh7y1in5j9ka5cxk2zw2qdj` |
| Voyage Begin Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Voyage Begin Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-voyage-begin-date-time` |
| Voyage Begin Date Time | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Voyage Begin Date Time | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VoyageBeginDateTime` |
| Voyage End Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Voyage End Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/niem/m-voyage-end-date-time` |
| Voyage End Date Time | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/maritime.xsd` |
| Voyage End Date Time | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/maritime/6.0/VoyageEndDateTime` |
| Location (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Location (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location` |
| Location (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationType` |
| Location (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-k2gzmlxjixdm6l1moo5rhwrn` |
| Location Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-category` |
| Location Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationCategoryText` |
| Location Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-description` |
| Location Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationDescriptionText` |
| Location Directions | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Directions | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-directions` |
| Location Directions | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Directions | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationDirectionsText` |
| Location Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-identification` |
| Location Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationIdentification` |
| Location Landmark Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Landmark Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-landmark-name` |
| Location Landmark Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Landmark Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationLandmarkName` |
| Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-name` |
| Location Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationName` |
| Location Range Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Range Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-range-description` |
| Location Range Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Range Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationRangeDescriptionText` |
| Location Surrounding Area Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Surrounding Area Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-surrounding-area-description` |
| Location Surrounding Area Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Surrounding Area Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationSurroundingAreaDescriptionText` |
| Location Altitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Altitude | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-altitude` |
| Location Altitude | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Altitude | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationAltitude` |
| Location Elevation | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Elevation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-elevation` |
| Location Elevation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Elevation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationElevation` |
| Geolocation | `dcterms:publisher` | `https://axius-sdc.com` |
| Geolocation | `dcterms:identifier` | `https://axius-sdc.com/library/default/geolocation` |
| Geolocation | `dcterms:source` | `https://schema.org/` |
| Geolocation | `skos:exactMatch` | `https://schema.org/GeoCoordinates` |
| Geodetic Datum | `dcterms:publisher` | `https://axius-sdc.com` |
| Geodetic Datum | `dcterms:source` | `https://epsg.org/` |
| Geodetic Datum | `dcterms:identifier` | `https://axius-sdc.com/library/default/geodetic-datum` |
| Geodetic Datum | `skos:closeMatch` | `http://www.wikidata.org/entity/Q182643` |
| Altitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Altitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/altitude` |
| Altitude | `dcterms:source` | `http://qudt.org/` |
| Altitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Altitude` |
| Altitude | `skos:exactMatch` | `https://schema.org/elevation` |
| Latitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Latitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/latitude` |
| Latitude | `dcterms:source` | `http://qudt.org/` |
| Latitude | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68642` |
| Latitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Angle` |
| Latitude | `skos:exactMatch` | `https://schema.org/latitude` |
| Latitude | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sws9fskrdla5e99x7cn4trwo` |
| Longitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Longitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/longitude` |
| Longitude | `dcterms:source` | `http://qudt.org/` |
| Longitude | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68643` |
| Longitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Angle` |
| Longitude | `skos:exactMatch` | `https://schema.org/longitude` |
| Longitude | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ecyu6tt7kkjq4rzhthe74ed6` |
| Locale | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale` |
| Locale | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleType` |
| Locale Census Block ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Census Block ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-census-block-id` |
| Locale Census Block ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Census Block ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCensusBlockID` |
| Locale Census Tract ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Census Tract ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-census-tract-id` |
| Locale Census Tract ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Census Tract ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCensusTractID` |
| Locale Community Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Community Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-community-name` |
| Locale Community Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Community Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCommunityName` |
| Locale Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-description` |
| Locale Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleDescriptionText` |
| Locale District Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale District Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-district-name` |
| Locale District Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale District Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleDistrictName` |
| Locale Emergency Services Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Emergency Services Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-emergency-services-jurisdiction-id` |
| Locale Emergency Services Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Emergency Services Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleEmergencyServicesJurisdictionID` |
| Locale Emergency Services Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Emergency Services Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-emergency-services-name` |
| Locale Emergency Services Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Emergency Services Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleEmergencyServicesName` |
| Locale Fire Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Fire Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-fire-jurisdiction-id` |
| Locale Fire Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Fire Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleFireJurisdictionID` |
| Locale Judicial District Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Judicial District Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-judicial-district-name` |
| Locale Judicial District Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Judicial District Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleJudicialDistrictName` |
| Locale Neighborhood Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Neighborhood Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-neighborhood-name` |
| Locale Neighborhood Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Neighborhood Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleNeighborhoodName` |
| Locale Police Beat | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Beat | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-beat` |
| Locale Police Beat | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Beat | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceBeatText` |
| Locale Police Grid | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Grid | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-grid` |
| Locale Police Grid | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Grid | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceGridText` |
| Locale Police Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-jurisdiction-id` |
| Locale Police Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceJurisdictionID` |
| Locale Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-region-name` |
| Locale Region Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Region Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleRegionName` |
| Locale Subdivision Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Subdivision Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-subdivision-name` |
| Locale Subdivision Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Subdivision Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleSubdivisionName` |
| Locale Zone Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Zone Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-zone-name` |
| Locale Zone Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Zone Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleZoneName` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "Maritime Port Authority 4.4.0" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-v42afzhs22bvschuo56rdpzi.xsd)
- Example instance (dm-v42afzhs22bvschuo56rdpzi.xml)
- HTML documentation (dm-v42afzhs22bvschuo56rdpzi.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"Maritime Port Authority 4.4.0" SDC4 schema (dm-v42afzhs22bvschuo56rdpzi.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"Maritime Port Authority 4.4.0" schema (dm-v42afzhs22bvschuo56rdpzi.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "Maritime Port Authority 4.4.0" SDC4 schema (dm-v42afzhs22bvschuo56rdpzi.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "Maritime Port Authority 4.4.0" data model (dm-v42afzhs22bvschuo56rdpzi.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-v42afzhs22bvschuo56rdpzi.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-v42afzhs22bvschuo56rdpzi.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-v42afzhs22bvschuo56rdpzi.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-v42afzhs22bvschuo56rdpzi.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-v42afzhs22bvschuo56rdpzi.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
