# Law Enforcement Record 4.4.0

**Model ID**: `dm-zdhuex1xwf8s5niriw878e0o`
**Project**: Cordova
**Description**: Record public safety incidents, charges, and dispositions in Cordova.

### Dublin Core Metadata
- **Subject**: Law Enforcement
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal
- **Publisher**: Axius SDC, Inc.

## Package Contents

- `dm-zdhuex1xwf8s5niriw878e0o.xsd` -- XML Schema Definition (data model structure)
- `dm-zdhuex1xwf8s5niriw878e0o.xml` -- XML instance example with sample data
- `dm-zdhuex1xwf8s5niriw878e0o-instance.json` -- JSON instance example (same structure as XML)
- `dm-zdhuex1xwf8s5niriw878e0o.jsonld` -- JSON-LD semantic schema description
- `dm-zdhuex1xwf8s5niriw878e0o.html` -- Human-readable model documentation
- `dm-zdhuex1xwf8s5niriw878e0o_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-zdhuex1xwf8s5niriw878e0o.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-zdhuex1xwf8s5niriw878e0o.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-zdhuex1xwf8s5niriw878e0o.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-zdhuex1xwf8s5niriw878e0o.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **Law Enforcement Governed Record** | Cluster | `bpo0qpdsr1pj7j9kphbiigg0` | 1 components; 4 sub-cluster(s) |
|   Digital Signature Proof | XdFile | `gug5dhtqfv7exbgmm2raxpkq` | -- |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **Incident Report** | Cluster | `sjym80rxfdn9lm66ebe6s4tj` | 4 components; 3 sub-cluster(s) |
|     National ID (CID) | XdString | `nj7s1gk45tfgyooxpz0qaha3` | exactLen=16; pattern=`COR-(AL|BR|CE)0[1-3]-[0-9]{6}` |
|     City | XdToken | `atdtdfzruh7tya0iv5cz365l` | 9 enum(s) |
|     Incident Status | XdToken | `e83h36jqgi59dhy1dttp22qm` | 3 enum(s) |
|     Province | XdToken | `kv5qqs3o4jwcwz9javgw1pzh` | 3 enum(s) |
|     **Charge Details (Cordova)** | Cluster | `ubibbfdz9n4erd93ud955i91` | 2 components |
|       Fine or Bail Amount | XdQuantity | `yahksk4xc5to981ows7bpp6z` | min=0.00000; units=Cordova Córdoba (COR) |
|       Disposition Date | XdTemporal | `qse1jwofk5lm2wnsrn3f06l0` | -- |
|     **Incident** | Cluster | `rf6fgthipruopc68iyyntrwq` | 53 components; 4 sub-cluster(s) |
|       Amber Alert Issued Indicator | XdBoolean | `my0j51q0uv6gqcmnn9eogs3j` | -- |
|       Incident Arrest Made Indicator | XdBoolean | `utme5aw5dmbhpkza104y97ez` | -- |
|       Incident Criminal Indicator | XdBoolean | `rqhz9link6i1z7y5j4hgh25u` | -- |
|       Incident Crisis Response Team Activated Indicator | XdBoolean | `jrfffk73mqc8s51fagm6zzo5` | -- |
|       Incident Emergency Service Required Indicator | XdBoolean | `iouat1m1p92w6brtgnew78ct` | -- |
|       Incident Evidence Held Indicator | XdBoolean | `nnmz7i5p79ox7i10uq58j23l` | -- |
|       Incident Force Involved Indicator | XdBoolean | `juefph9u0szxgnbdofjsxev8` | -- |
|       Incident Law Enforcement Summoned Indicator | XdBoolean | `st5wkvrrezh7ebpcm66wzucm` | -- |
|       Incident Minor Involved Indicator | XdBoolean | `kh5yg8z64f4z2lm4cskxmyxt` | -- |
|       Incident Official Present Indicator | XdBoolean | `c4neua3ror7ax351chk85rxs` | -- |
|       Incident Prints Requested Indicator | XdBoolean | `lnz214ylxutpxpl6y18yvuai` | -- |
|       Incident Traffic Accident Involved Indicator | XdBoolean | `llps3bgkou8fij8j6hck2hz2` | -- |
|       Incident Weapon Involved Indicator | XdBoolean | `ky56sqir1rncy9vz62s9cygs` | -- |
|       Activity Description | XdString | `ne1qtonwtz9mvujgchp46nfz` | maxLen=4000 |
|       Activity Identification | XdString | `g7bzqfrt27ftx37ptypizu23` | maxLen=64 |
|       Incident Assisting Official Reference | XdString | `h45w24ukeh17fq7th09kl9b0` | maxLen=2000; pattern=`\S+` |
|       Incident Damaged Item Reference | XdString | `gawucui4jkgqb6qxmfexhmzt` | maxLen=2000; pattern=`\S+` |
|       Incident Day Period | XdString | `r46c05vgs1s7yw046br88k83` | maxLen=4000 |
|       Incident Drug Reference | XdString | `b9cqv6ubficy3wkcgdbohutl` | maxLen=2000; pattern=`\S+` |
|       Incident Facility Reference | XdString | `ftntx87ts81n2ng1bqdvtyjx` | maxLen=2000; pattern=`\S+` |
|       Incident General Category | XdString | `ottbl669n5krfuw5sdjlr9b5` | maxLen=4000 |
|       Incident Injury Level | XdString | `xa8onobj151m5ibmiio5ivb6` | maxLen=4000 |
|       Incident Issues | XdString | `ybltn8sqdcl6gsbjw1fp6vzt` | maxLen=4000 |
|       Incident Jurisdictional Organization Reference | XdString | `iff9tuanfxqqv5vcswh3qhgd` | maxLen=2000; pattern=`\S+` |
|       Incident Level | XdString | `e5eh16u67vwr3toy93wnsouv` | maxLen=4000 |
|       Incident Log Identification | XdString | `o6q9bp5f4viknhfqdr0ripr1` | maxLen=64 |
|       Incident Method Description | XdString | `wxvsqzyk4fry3nv28lylwtba` | maxLen=4000 |
|       Incident Observation | XdString | `e4wj8nbtea9d8h50odhdxs3y` | maxLen=4000 |
|       Incident Recovered Item Reference | XdString | `b1avbeh3jzuu42vy0prwfwor` | maxLen=2000; pattern=`\S+` |
|       Incident Reported Narrative | XdString | `hhv07mnlmhmg5yclbwu4kml7` | maxLen=4000 |
|       Incident Reporting Official Reference | XdString | `wqk6wdikperrndanl0m0udcf` | maxLen=2000; pattern=`\S+` |
|       Incident Response Official Reference | XdString | `t5ymfuz4c0luwvqmfv45qmb1` | maxLen=2000; pattern=`\S+` |
|       Incident Response Organization Reference | XdString | `hrvcuvulm4kiyigiyjnj4av4` | maxLen=2000; pattern=`\S+` |
|       Incident Seized Item Reference | XdString | `qlvedsfwxi2l4lszvidafkm4` | maxLen=2000; pattern=`\S+` |
|       Incident Stolen Item Reference | XdString | `pan3c4oualcmf5m50971me1m` | maxLen=2000; pattern=`\S+` |
|       Incident Subject Reference | XdString | `m7mirsxi8b4nu0efks502js0` | maxLen=2000; pattern=`\S+` |
|       Incident Subject Weapon Reference | XdString | `q6ywagwzgjtzatns233r9peh` | maxLen=2000; pattern=`\S+` |
|       Incident Supervising Official Reference | XdString | `fsie2igsgxenn7xyr40qrwi8` | maxLen=2000; pattern=`\S+` |
|       Incident Victim Reference | XdString | `ve6k9wno60x1m0huuggv03as` | maxLen=2000; pattern=`\S+` |
|       Incident Weather | XdString | `d1jp3ai68fmbplordc2ahc9p` | maxLen=4000 |
|       Incident Witness Reference | XdString | `pyq4dllla648cvx55ww8mdxj` | maxLen=2000; pattern=`\S+` |
|       Incident Category Code | XdToken | `h86aekmlc0ldsbrxbainx1c4` | 33 enum(s) |
|       Incident Category UCR Code | XdToken | `ghwcp9dwzfccb7kyzmklr9tp` | 85 enum(s) |
|       Incident Dissemination Level Code | XdToken | `q1jgqzps6ztmfoa4kcmf43j9` | 3 enum(s) |
|       Incident Exceptional Clearance Code | XdToken | `s7xofidz4jdgz00zeiag569c` | 6 enum(s) |
|       Incident Lighting Code | XdToken | `qczajugx58asslomuv1z3wrk` | 9 enum(s) |
|       Incident Status Code | XdToken | `tf41ya4l903iz36guuf7mem2` | 11 enum(s) |
|       Incident Arrest Count Quantity | XdCount | `flh3fpatkvun9gonqxoawego` | units=Items |
|       Incident Recovered Vehicle Quantity | XdQuantity | `vojtk7iws7o1btueg8km5n3s` | units=Unitless |
|       Incident Stolen Vehicle Quantity | XdQuantity | `rl3ozy9jy3qrhvvun8zb316s` | units=Unitless |
|       Incident Structures Entered Quantity | XdQuantity | `xo36avt4ywlhmkskmrpwax70` | units=Unitless |
|       Activity Date | XdTemporal | `qprm8z9y4rzid9hiwojslia6` | -- |
|       Incident Exceptional Clearance Date | XdTemporal | `p1mb88fpb3x3rvluhxaok7q1` | -- |
|       **Arrest** | Cluster | `vp5luggwup102zy7vt7uqso4` | 24 components; 6 sub-cluster(s) |
|         Arrest Community Supervision Indicator | XdBoolean | `wp2p68ravvj5gratjxv53k8r` | -- |
|         Arrest Intoxicant Involved Indicator | XdBoolean | `r9e7yk5lnisrmf9y23s567at` | -- |
|         Arrest Resisted Indicator | XdBoolean | `sqtm0u0fsz58lbrr0wdzpmwp` | -- |
|         Arrest Subject Rights Read Indicator | XdBoolean | `ee7ycrzdfvg46sltoaa2jyna` | -- |
|         Arrest Summons Indicator | XdBoolean | `ou0vme4fko0kq43m064m5tjy` | -- |
|         Arrest Under Influence Indicator | XdBoolean | `hfbppqeghm4l9ytbu4vcx1df` | -- |
|         Activity Description | XdString | `ne1qtonwtz9mvujgchp46nfz` | maxLen=4000 |
|         Activity Identification | XdString | `g7bzqfrt27ftx37ptypizu23` | maxLen=64 |
|         Arrest Agency Record Identification | XdString | `cslp8hx6cfwdnbbh6d2juo8f` | maxLen=64 |
|         Arrest Agency Reference | XdString | `obsk6dae4z5hvph87j4fzgun` | maxLen=2000; pattern=`\S+` |
|         Arrest Apprehension Detention Order Reference | XdString | `ianu5epsae6iie8k45kqyzcz` | maxLen=2000; pattern=`\S+` |
|         Arrest Bail Recommendation | XdString | `l37wmdsuf6t3em6fms7n5huz` | maxLen=4000 |
|         Arrest Involved Item Reference | XdString | `ezv5bj0o3unftiag2s2sw6w1` | maxLen=2000; pattern=`\S+` |
|         Arrest Involved Organization Reference | XdString | `nfrivmnhx7nua3c4ug49ci2z` | maxLen=2000; pattern=`\S+` |
|         Arrest Involved Weapon Reference | XdString | `ub8hnbs87scgq6aaw3dw2vxu` | maxLen=2000; pattern=`\S+` |
|         Arrest Probable Cause | XdString | `je0x9toj1n1i425grim19xag` | maxLen=4000 |
|         Arrest Sequence ID | XdString | `w7dg5q06me8obl2gh1uq3w0v` | maxLen=255 |
|         Arrest Subject Reference | XdString | `gdyvs8qur1bamcpqsh1pyzbm` | maxLen=2000; pattern=`\S+` |
|         Arrest Subject Rights Read Response | XdString | `hw0ejjqqroaroxislc3u09pc` | maxLen=4000 |
|         Arrest Category Code | XdToken | `kfi4p26upd1gzvmgt40ameou` | 3 enum(s) |
|         Arrest Category JABS Code | XdToken | `d2x6nslfs65b2c4tdt0w6j7h` | 3 enum(s) |
|         Arrest Subject Count Code | XdToken | `jbfrsvba9amputwsgrmajo2k` | 3 enum(s) |
|         Activity Date | XdTemporal | `qprm8z9y4rzid9hiwojslia6` | -- |
|         Arrest Arraignment Date | XdTemporal | `dqg7putw1hyet5lsjhkd2mcp` | -- |
|         **Charge** | Cluster | `jlv47tzdmj9vcvpffb3v09iv` | 33 components; 5 sub-cluster(s) |
|           Charge Accident Related Indicator | XdBoolean | `pstcj2pd5hz3cl9z7t8yd8ez` | -- |
|           Charge Arrest Reason Indicator | XdBoolean | `nmkmwkgv8uooboi5p8px9pa9` | -- |
|           Charge Employment Related Indicator | XdBoolean | `zdoqx7ugqbebmdss4z3ya5n9` | -- |
|           Charge Felony Indicator | XdBoolean | `s3mf2eg6wh6qyh3dadl86tmv` | -- |
|           Charge Highest Indicator | XdBoolean | `oylyo9tkuv0sku7fhwolbup6` | -- |
|           Charge Serious Violent Indicator | XdBoolean | `hhha7zlmgomwyatwjcrjha27` | -- |
|           Charge Applicability | XdString | `ox316o6zmzkqx6g1lxdazrgq` | maxLen=4000 |
|           Charge Category Description | XdString | `q6hzw3a1hhucgh8ut8kdedxa` | maxLen=4000 |
|           Charge Degree | XdString | `f5dxve59u3oxfpna6dtn7gae` | maxLen=4000 |
|           Charge Description | XdString | `ptczxhjabwi5dibss2kbnykq` | maxLen=4000 |
|           Charge Disposition Other | XdString | `fmsewsd7w2rnia16xb0vdi27` | maxLen=4000 |
|           Charge Filer Entity Reference | XdString | `odxgsye54oyiesmt15opbkdj` | maxLen=2000; pattern=`\S+` |
|           Charge Identification | XdString | `y0l9v7z65vs4cnw6urbl6vvv` | maxLen=64 |
|           Charge Legal Description | XdString | `lk48u5opm7u5n31ereji9pyb` | maxLen=4000 |
|           Charge NCIC | XdString | `l8y97qfew8xc5ocwslvoega3` | maxLen=4000 |
|           Charge Originator Entity Reference | XdString | `xlc1yztej392eouk1c29o9dg` | maxLen=2000; pattern=`\S+` |
|           Charge Qualifier | XdString | `xa4gs9cqrkgrhjfqwuas8019` | maxLen=4000 |
|           Charge Reducing Factor | XdString | `lx91v2e4tcge56pnodz04b08` | maxLen=4000 |
|           Charge Sentence Range | XdString | `nhlomd7xjfczjw1c8lulef2x` | maxLen=4000 |
|           Charge Sequence ID | XdString | `colisx4a4r7vdxg6aynuig00` | maxLen=255 |
|           Charge Severity | XdString | `f7ts2r68h34oveflio2gpweh` | maxLen=4000 |
|           Charge Severity Description | XdString | `r501gis08fwj79lraiak1809` | maxLen=4000 |
|           Charge Special Allegation | XdString | `lq4eb12aez3w206oix7vvhww` | maxLen=4000 |
|           Charge Status | XdString | `m2jbhv431q1p5ip9ex8ik5gw` | maxLen=255 |
|           Charge Subject Reference | XdString | `qf9jvgjzn6jlheusoape6ctu` | maxLen=2000; pattern=`\S+` |
|           Charge Text | XdString | `gw3a5rekp70nf2wa0yq229kz` | maxLen=4000 |
|           Charge Tracking Identification | XdString | `scb4k1nyqhxwkv55zcqrgfag` | maxLen=64 |
|           Charge UCR Crime Category | XdString | `ttu0up25lq4yck4uv7xsninj` | maxLen=4000 |
|           Charge Victim Reference | XdString | `ipzudwe3bp4bzbrfofoce6vn` | maxLen=2000; pattern=`\S+` |
|           Charge UCR Code | XdToken | `rlbv0u98wyn2er8ryck88191` | 85 enum(s) |
|           Charge Count Quantity | XdCount | `nfe127d3r87lx1wvfnhibhh0` | units=Items |
|           Charge Recommended Bail Amount | XdQuantity | `lerncxh2ohe87vfb1vd18zof` | units=Currency |
|           Charge Filing Date | XdTemporal | `vmvhef2pgotartphdawcccq3` | -- |
|           **Disposition** | Cluster | `qmse9krfg12m98edekacd2w5` | 7 components |
|             Disposition Category Code | XdString | `y5ngvqrejc2546h3pe00f897` | maxLen=4000 |
|             Disposition Description | XdString | `cy4xirp3mjwc8zdi2lmtypjl` | maxLen=4000 |
|             Disposition Entity Reference | XdString | `ua58wna23zgm6gzrxkaiubk2` | maxLen=2000; pattern=`\S+` |
|             Disposition Reason | XdString | `yjw9y3uujlsf5jgxexvik49f` | maxLen=4000 |
|             Disposition Reported Authority | XdString | `kyo7yhvdlvvlije10r063dop` | maxLen=4000 |
|             Disposition Text | XdString | `prflv8w278ea1tiiwmoxzj7b` | maxLen=4000 |
|             Disposition Date | XdTemporal | `jin81y29qpwtmt80w2w1qs6c` | -- |
|           **Plea** | Cluster | `ulhiw7s5c1dxb4n0biu780lu` | 5 components |
|             Plea Guilty Indicator | XdBoolean | `s7x5z81vfn9ya4c04i3f5suq` | -- |
|             Plea Negotiated Indicator | XdBoolean | `oj80et0u3g60b4ml4iingtqg` | -- |
|             Plea No Contest Indicator | XdBoolean | `cgj2hcgmjcvq96n5oumm2axv` | -- |
|             Plea Description | XdString | `whjq7gkg25nmzm7q0135v4ja` | maxLen=4000 |
|             Plea Recommendation | XdString | `z3pm5lq9j4ng7xavwcl51mac` | maxLen=4000 |
|           **Sentence** | Cluster | `hif2zo7br6uzupa3j1i9x4zp` | 15 components; 2 sub-cluster(s) |
|             Sentence Aggravated Indicator | XdBoolean | `igu83lq5o56irxc4004niqlz` | -- |
|             Sentence Confinement Credit Indicator | XdBoolean | `q8i0okrw9uog6i2fgb996i8n` | -- |
|             Sentence Deferred Indicator | XdBoolean | `dcn4xev2hmq4tl7z8j28sy0a` | -- |
|             Sentence Register Sex Offender Indicator | XdBoolean | `t98iv0m7hjbi678lg1f9n5eh` | -- |
|             Sentence Suspended Indicator | XdBoolean | `m58j4hxcdnqe3p9jdbrp3ayb` | -- |
|             Sentence Charge Reference | XdString | `ktjljh5fuybfhytqkpnks4wn` | maxLen=2000; pattern=`\S+` |
|             Sentence Description | XdString | `p7s1t57n8j2w71vv8grolap7` | maxLen=4000 |
|             Sentence Grouping | XdString | `w4fj0e574eeb4b2azthpm6wh` | maxLen=4000 |
|             Sentence Imposed | XdString | `jfws31a67cjwo1y5hut0w1ef` | maxLen=4000 |
|             Sentence Issuer Entity Reference | XdString | `vmjllz95ukv3n6g0uky2aaj0` | maxLen=2000; pattern=`\S+` |
|             Sentence Subject Reference | XdString | `bp1ua68phj9p7lxpgk09xwpd` | maxLen=2000; pattern=`\S+` |
|             Sentence Confinement Credit Day Quantity | XdQuantity | `oc84nan586qktl1x5iqpu37y` | units=Unitless |
|             Sentence Court Fee Amount | XdQuantity | `b1jbxaolcbod284up7o7jcga` | units=Currency |
|             Sentence Fine Amount | XdQuantity | `nhffoww3bekct5i1gpq9k15c` | units=Currency |
|             Sentence Expiration Date | XdTemporal | `e5zjxzi072zrwtlkl3i4jopk` | -- |
|             **Condition (Requirement)** | Cluster | `emereei48db0rylomuxqty11` | 6 components |
|               Condition Mandatory Indicator | XdBoolean | `n8uvz9z7633yqsuwcnni6jzt` | -- |
|               Condition Violated Indicator | XdBoolean | `i9j8ow7l7qnijqoicqekyipp` | -- |
|               Condition Group ID | XdString | `dbi8ta398dzr9by1j9h3ldwv` | maxLen=255 |
|               Condition Violation | XdString | `psjym76pwhqyiscoikwc6b7y` | maxLen=4000 |
|               Condition Set Date | XdTemporal | `o0d1kxxtj6g098b2lf4yqhf7` | -- |
|               Condition Violation Date | XdTemporal | `m9z6a3t2900w9yds543iqkzg` | -- |
|             **Term** | Cluster | `jd2ap62wyou5h9447vhc2fql` | 4 components |
|               Term Life Indicator | XdBoolean | `i46uydllxseoxcbq4lxmnz4l` | -- |
|               Term Duration | XdTemporal | `xsprzlmh43ofgszbjjvyxmjz` | -- |
|               Term Maximum Duration | XdTemporal | `gg3m8xzfrj430ulo0wrlykv2` | -- |
|               Term Minimum Duration | XdTemporal | `csgkjkppb2415o22f00pmgud` | -- |
|           **Statute** | Cluster | `egdruy7qynizku0zoe56tcyp` | 14 components |
|             Statute Offense Enhanceable Indicator | XdBoolean | `mti395y9tyk9lf30yi3f7umd` | -- |
|             Statute Category | XdString | `pos2dd149o8n4sj0gp4q147z` | maxLen=4000 |
|             Statute Code Identification | XdString | `ibmnz3yuj0ve86034a47sf1k` | maxLen=64 |
|             Statute Code Section Identification | XdString | `i9qex136r5vc1d4urx7yfeig` | maxLen=64 |
|             Statute Description | XdString | `obgfugzwtfonieqpflazficd` | maxLen=4000 |
|             Statute Jurisdiction Reference | XdString | `byz89fn9v0a6w6ndb3gwxwl8` | maxLen=2000; pattern=`\S+` |
|             Statute Keyword | XdString | `km66mn841zdvpdpdib8p4ryj` | maxLen=4000 |
|             Statute Level | XdString | `zfetcmuufk7cx2aqsbxt33xh` | maxLen=4000 |
|             Statute Offense Identification | XdString | `hxbejtzsvo12kra41in0g0pg` | maxLen=64 |
|             Statute Offense State Code | XdString | `u95ynad5vxwpwrter6zaezzc` | maxLen=4000 |
|             Statute Status | XdString | `urpwj8y2a34rs3yu6nog87zr` | maxLen=255 |
|             Statute Text | XdString | `gkrsxglme5jv618o155xkdan` | maxLen=4000 |
|             Statute Enactment Date | XdTemporal | `q48eh3iqbrgk7eyr4b3wfa0n` | -- |
|             Statute Repeal Date | XdTemporal | `asic4mc40a5xfwpppvmt3mhl` | -- |
|           **Verdict** | Cluster | `wsbba34jpz5c0jzs3zl45s6a` | 8 components |
|             Verdict Issuing Judge Indicator | XdBoolean | `wo4j54nc8bwwvc1lcj3zu9r7` | -- |
|             Verdict Description | XdString | `zgzg0y5yp3hnxyinto4urn7w` | maxLen=4000 |
|             Verdict Disposition Name | XdString | `i70l6l3jhivzrlwo65drvtv3` | maxLen=255 |
|             Verdict Issuing Court Reference | XdString | `lsmwiwpvpo8ql4rbradfrfit` | maxLen=2000; pattern=`\S+` |
|             Verdict Issuing Judge Reference | XdString | `drifmqgdqn7amy9j6ukwv91s` | maxLen=2000; pattern=`\S+` |
|             Verdict Subject Reference | XdString | `h9tzt1xk48j982hpyzydsy5f` | maxLen=2000; pattern=`\S+` |
|             Verdict Date | XdTemporal | `p6vywly4kwh7wxbw2y8jscbn` | -- |
|             Verdict Disposition Date | XdTemporal | `irelqamaurkngcsihhvz1z5s` | -- |
|         **Custody Transfer** | Cluster | `hqg8tnvrbcl9f5dpngutqj1g` | 9 components |
|           Custody Transfer Action | XdString | `ubeu0vj89399vxlq7pxb5rru` | maxLen=4000 |
|           Custody Transfer Item Reference | XdString | `xgvn2cix8t9lg39wbv9siwms` | maxLen=2000; pattern=`\S+` |
|           Custody Transfer Receiving Enforcement Agency Reference | XdString | `sjt7xysegajjp9n34h5g2dxi` | maxLen=2000; pattern=`\S+` |
|           Custody Transfer Receiving Enforcement Facility Reference | XdString | `hbsjlbofv6abpdfch6kx4i8x` | maxLen=2000; pattern=`\S+` |
|           Custody Transfer Receiving Enforcement Official Reference | XdString | `lv8mqcuj9r7ka41aa9rhgagt` | maxLen=2000; pattern=`\S+` |
|           Custody Transfer Releasing Enforcement Agency Reference | XdString | `g2f15ffxhecfsv06duf61jgq` | maxLen=2000; pattern=`\S+` |
|           Custody Transfer Releasing Enforcement Facility Reference | XdString | `dosu6l721apmnu77i9mcutm9` | maxLen=2000; pattern=`\S+` |
|           Custody Transfer Releasing Enforcement Official Reference | XdString | `cq8pgejgs9ifxts49bna36gb` | maxLen=2000; pattern=`\S+` |
|           Custody Transfer Subject Reference | XdString | `eeixguttkdg3243qq63p0x0d` | maxLen=2000; pattern=`\S+` |
|         **Enforcement Official** | Cluster | `nxlr84b3a8omb8q86970ksmf` | 8 components; 2 sub-cluster(s) |
|           Employee Rank | XdString | `exwd705vvkcsavizr7yw73r3` | maxLen=4000 |
|           Enforcement Official Badge Identification | XdString | `reynmh9qrulyzi7atwr6oryy` | maxLen=64 |
|           Enforcement Official Category | XdString | `cxayu9qn0cftc4ktdzdgqo37` | maxLen=4000 |
|           Enforcement Official POST License Identification | XdString | `x9qn47cxk8ze4r7dytwxp0s8` | maxLen=64 |
|           Enforcement Unit Identification | XdString | `aqzezcxpiszo53vdpio7olsq` | maxLen=64 |
|           Enforcement Unit Name | XdString | `g8i5b468s2zjrku9gd3z92jy` | maxLen=255 |
|           Enforcement Official Activity Category Code | XdToken | `wj13ubhx0qd93k1oxy2zkfah` | 11 enum(s) |
|           Enforcement Official Assignment Category Code | XdToken | `vu1kvb52qqpsuucwgfjptulj` | 7 enum(s) |
|           **Full Name (Person)** | Cluster | `ytw6qjtq5gilrvkfsohsrlkh` | 6 components |
|             Given Name (Person) | XdString | `l9l169co9r23e6fftpvdz4e3` | minLen=1; maxLen=100 |
|             Middle Name (Person) | XdString | `zcf4f5kjjo497jeb9vtt9rmr` | minLen=1; maxLen=100 |
|             Name Prefix | XdString | `yahxccv0l1z6ykjxayzkdlkq` | maxLen=20 |
|             Name Suffix | XdString | `l509t0zajfl5atns64d5kl97` | maxLen=20 |
|             Surname (Person) | XdString | `jc1lfk3ovt6l8frhxvx8b669` | minLen=1; maxLen=100 |
|             Name Use | XdToken | `bfqinvm7qrgi9jjw1i637moh` | 7 enum(s) |
|           **Organization (NIEM)** | Cluster | `bv2nl062e7l4wgumkv2ng2em` | 22 components; 2 sub-cluster(s) |
|             Organization Active Indicator | XdBoolean | `e5t0xgdy46hfguuwycvwc6dd` | -- |
|             Organization Incorporated Indicator | XdBoolean | `ncop04mgrb74q0oh7g0q6t48` | -- |
|             Organization Abbreviation | XdString | `t70xkidrjlfp0vqdtvlqsbtl` | maxLen=4000 |
|             Organization Branch Name | XdString | `w48pqrn60rdk8g8mj2uoyk2c` | maxLen=255 |
|             Organization Category | XdString | `vbukxb85z1kxdbsng4oni88d` | maxLen=4000 |
|             Organization Description | XdString | `se9bkamsp62q9j5xsjyce9pw` | maxLen=4000 |
|             Organization Doing Business As Name | XdString | `h39s8p16hzlwqlgtlwugchgt` | maxLen=255 |
|             Organization Identification | XdString | `gs7w0xkgwczep8oa2qzcn8rg` | maxLen=64 |
|             Organization Jurisdiction Reference | XdString | `ngkknoglkay9pz4tajcr1kkn` | maxLen=2000; pattern=`\S+` |
|             Organization LEI Identification | XdString | `ts9y9tay6win35ackli12kz6` | maxLen=64 |
|             Organization ORI Identification | XdString | `y4xmf28q5mhb60noq2tt2wif` | maxLen=64 |
|             Organization Parent Organization Reference | XdString | `ayhhnde5u8fw23pr2hq7frzg` | maxLen=2000; pattern=`\S+` |
|             Organization Principal Official Reference | XdString | `hy4elrb7s7djv09luhqytvn1` | maxLen=2000; pattern=`\S+` |
|             Organization Status | XdString | `zmz00hasm7857nienhjc90sg` | maxLen=255 |
|             Organization Sub Unit Name | XdString | `g05gyxydr8ybzxlrk9ly74rr` | maxLen=255 |
|             Organization Tax Identification | XdString | `artqk9ji97lmqvkzmro5tn6g` | maxLen=64 |
|             Organization Unit Name | XdString | `xeqdfbd43aks5bd0ixo09tot` | maxLen=255 |
|             Organization Name | XdString | `xcn8r67fg7soty17homzok44` | minLen=1; maxLen=200 |
|             Organization Category ND Ex Code | XdToken | `wj2nhg5v1hl2d3wa7uo3myz8` | 23 enum(s) |
|             Organization Established Date | XdTemporal | `tvlwdetrfqnlm27nu7x95j39` | -- |
|             Organization Incorporation Date | XdTemporal | `b2iocf5x4d9635bdz9p096md` | -- |
|             Organization Termination Date | XdTemporal | `joxtepir8lkpxw71l64nk03o` | -- |
|             **Contact Information (NIEM)** | Cluster | `v40dwrznm5fwko7b4n6ryrzi` | 3 components; 2 sub-cluster(s) |
|               Contact Entity Description | XdString | `b3yv6tmx5q9tq61zrrbrl8v3` | maxLen=4000 |
|               Contact Information Description | XdString | `m6hyj5gbbwiaepgiioklhtg3` | maxLen=4000 |
|               Contact Information Availability Code | XdToken | `wyevwvpluw19t8wge0psgpjs` | 6 enum(s) |
|               **Address (NIEM)** | Cluster | `doa46sdyoadezgc0tpj379th` | 10 components; 2 sub-cluster(s) |
|                 Address Building Name | XdString | `bgn0jx6ubvcjtwa17hxvini2` | maxLen=255 |
|                 Address County Name | XdString | `vkbg8z0vmi1a4u99xp1mbsal` | maxLen=255 |
|                 Address Delivery Point | XdString | `ep615o1qzzlhz9f2g2quf6sp` | maxLen=4000 |
|                 Address Full | XdString | `dwy0u03b1iidzxi4ega2iy5r` | maxLen=4000 |
|                 Address Postal Extension Code | XdString | `lckcihuej9hiyqfjhekk6nid` | maxLen=255 |
|                 Address Private Mailbox | XdString | `jx13ihzux8cd382oenzlkn05` | maxLen=4000 |
|                 Address Recipient Name | XdString | `qcngrwgzzjxvcbxbm9oxonei` | maxLen=255 |
|                 Address Secondary Unit | XdString | `fvznldoks6w41g7a4pwvd2ub` | maxLen=4000 |
|                 Address Urbanization Name | XdString | `fzjp1m1u66usm20aamjygmun` | maxLen=255 |
|                 Address Category Code | XdToken | `k0ixe4ybmx5vp11f7de4k204` | 5 enum(s) |
|                 **County (fips)** | Cluster | `bahj0gy7mbmyobqhfy70x190` | 3 components |
|                   Code List: fips US County5 Digit | XdLink | `s5u98t1ah8l5069q0x704tdt` | -- |
|                   Code Display Text | XdString | `kr8fmao4yji8vr46kiw150me` | maxLen=500 |
|                   County Code (fips) | XdString | `dy9dwf3fhe3y6hyf1ka5fbfz` | maxLen=5; pattern=`[0-9]{5,5}` |
|                 **International Address** | Cluster | `upawqojmcfg3qsf4ffzi47ho` | 7 components |
|                   Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|                   Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|                   City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|                   Postal Code | XdString | `gf841eedvv6cjiegs934srai` | maxLen=15 |
|                   Region Name | XdString | `jw1b9q6ulyte599sdsqp2mvp` | maxLen=100 |
|                   Address Use | XdToken | `b25dj42zxhm19pih328ga8pl` | 5 enum(s) |
|                   Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|               **Contact Point** | Cluster | `d2xwhnb2vqzxw70jcizj9csx` | 6 components |
|                 Website URL | XdLink | `wriny2gz8aqcvffmfpwbompk` | -- |
|                 Email Address | XdString | `q922mqaon3yn5zlwf2bszf28` | maxLen=254; pattern=`.+@.+\..+` |
|                 Fax Number | XdString | `ll6ltsnvakomixuitxkbkxfz` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|                 Phone Number | XdString | `zpfwg52r88j6jdypj7rg71ke` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|                 Contact Method | XdToken | `miqo30r5b554nyj7ubryw43x` | 7 enum(s) |
|                 Contact Use | XdToken | `vmruk4j9y1orvvz8cwafrax5` | 5 enum(s) |
|             **Location (NIEM)** | Cluster | `o01gifxohfe46jfdyh62noig` | 10 components; 3 sub-cluster(s) |
|               Location Category | XdString | `fenldej2l73b84w956gawyqd` | maxLen=4000 |
|               Location Description | XdString | `zlqtx5yr8wdxavl2hc4y9uq4` | maxLen=4000 |
|               Location Directions | XdString | `fwusqzhkfgeh7gwrsgihp0rx` | maxLen=4000 |
|               Location Identification | XdString | `c9n7299dj2fdzlmqe8ixvb2z` | maxLen=64 |
|               Location Landmark Name | XdString | `vw3tuujru1u95k6kavnc946v` | maxLen=255 |
|               Location Name | XdString | `ouramzsx8f7nis27vjj265l9` | maxLen=255 |
|               Location Range Description | XdString | `ces753kz92cp4zdyva7qw530` | maxLen=4000 |
|               Location Surrounding Area Description | XdString | `enu405jym8hdu571utuznru3` | maxLen=4000 |
|               Location Altitude | XdQuantity | `qjl8rgtsnazid1rvxqof65yy` | units=Length Units (SI and customary) |
|               Location Elevation | XdQuantity | `n3luxpr7zt9z2ylpmp2wioy4` | units=Length Units (SI and customary) |
|               **Geolocation** | Cluster | `jwfl94g8mj8aevupivyfsnwj` | 4 components |
|                 Geodetic Datum | XdToken | `i3qpmie9hle8ma5kt6ogxqnp` | 3 enum(s) |
|                 Altitude | XdQuantity | `scdlxu6vex8iwbfc8sijmjff` | units=Length/Distance (SI - Metric) |
|                 Latitude | XdQuantity | `c5e0wv21cmlouukx6ga2o5uz` | units=Degrees (Angle) |
|                 Longitude | XdQuantity | `qh625ukiiju3ak4x45tehcnr` | units=Degrees (Angle) |
|               **Locale** | Cluster | `ru0fwf4ubdvcizzaau0mpftg` | 16 components |
|                 Locale Census Block ID | XdString | `ji7mja9le7x3k2fnstyflgd9` | maxLen=255 |
|                 Locale Census Tract ID | XdString | `b1qnngc94yrhnzw0a0qylc8m` | maxLen=255 |
|                 Locale Community Name | XdString | `d62un867sx8pfuoiw9vmyvhc` | maxLen=255 |
|                 Locale Description | XdString | `qhmp2uf6xmb86vdwzt9pz0z4` | maxLen=4000 |
|                 Locale District Name | XdString | `xrx13kgg5bxgodid3gojzc4u` | maxLen=255 |
|                 Locale Emergency Services Jurisdiction ID | XdString | `nmhyp4tz6uzhm9rcbxksrkad` | maxLen=255 |
|                 Locale Emergency Services Name | XdString | `zza5jn63yvlxhjgkajypacqi` | maxLen=255 |
|                 Locale Fire Jurisdiction ID | XdString | `nvonmskk57e6buoa4bjo4yq5` | maxLen=255 |
|                 Locale Judicial District Name | XdString | `ep6d634smvqdn890vnjs8umh` | maxLen=255 |
|                 Locale Neighborhood Name | XdString | `hs4ke1zgmxvea6nd41ivepg5` | maxLen=255 |
|                 Locale Police Beat | XdString | `dt27rd2aw6bfydiru5ti7gyh` | maxLen=4000 |
|                 Locale Police Grid | XdString | `rdk1jsosk7dgsbn7hkq3k10i` | maxLen=4000 |
|                 Locale Police Jurisdiction ID | XdString | `end6e085n8tw4850taf7jjl2` | maxLen=255 |
|                 Locale Region Name | XdString | `xswwghxc0mdmucw58sa5axse` | maxLen=255 |
|                 Locale Subdivision Name | XdString | `f0j0mvmsjdjfccynvpynntd8` | maxLen=255 |
|                 Locale Zone Name | XdString | `fypmwmyh1gcv597iesiyxdzd` | maxLen=255 |
|         **Release** | Cluster | `l5gntwbub02e0kr9hpkqe5n6` | 11 components |
|           Release Residence Indicator | XdBoolean | `jfkbtcrvm90r2njs58nzdm8s` | -- |
|           Release Date Category | XdString | `em4rxfrf02zpu9fx0ib1mxrc` | maxLen=4000 |
|           Release From Location Reference | XdString | `kjw5o7nn1c9nywmpp93b26ai` | maxLen=2000; pattern=`\S+` |
|           Release Issuer Reference | XdString | `yb34trjcrb2skfmn1ob1f8am` | maxLen=2000; pattern=`\S+` |
|           Release Person Reference | XdString | `ojhpgaokkrszcdx8mudes2sk` | maxLen=2000; pattern=`\S+` |
|           Release Recipient Reference | XdString | `bpzmdud38yv85b02tidsdncd` | maxLen=2000; pattern=`\S+` |
|           Release Supervisor Reference | XdString | `t7ag3blac2nqca3uaolez265` | maxLen=2000; pattern=`\S+` |
|           Release To Facility Reference | XdString | `dhtfp2ig883jxwwqb6qgjsu7` | maxLen=2000; pattern=`\S+` |
|           Release To Location Reference | XdString | `mrynj0hqvykgfkni0zity6gp` | maxLen=2000; pattern=`\S+` |
|           Release Funds Amount | XdQuantity | `lzi428te5jea51vnjeo2mcum` | units=Currency |
|           Release Date | XdTemporal | `sklyosmrk98xgyny6pq5nqs6` | -- |
|         **Warrant** | Cluster | `fk2tdepegogdgt2is8g4t6v2` | 24 components |
|           Court Order Designated Subject Reference | XdString | `q5o8zfs0zxr1x94t4r5d78r2` | maxLen=2000; pattern=`\S+` |
|           Court Order Enforcement Agency Reference | XdString | `e1xs007153a0mojx8p0dr5gq` | maxLen=2000; pattern=`\S+` |
|           Court Order Issuing Court Reference | XdString | `ox4ezu1x0l6uslw009o5o3ep` | maxLen=2000; pattern=`\S+` |
|           Court Order Issuing Judicial Official Reference | XdString | `e1ou1pt787adx1znpthus3es` | maxLen=2000; pattern=`\S+` |
|           Court Order Jurisdiction Reference | XdString | `bysd5zlwmjae93onee9qow3q` | maxLen=2000; pattern=`\S+` |
|           Court Order Recall Reason | XdString | `cuaprdadnz523w1nccvh9f85` | maxLen=4000 |
|           Court Order Service Caution | XdString | `abu0757ze11y2tsrse9vraw0` | maxLen=4000 |
|           Court Order Service Description | XdString | `zw8vmrnz3yv5sftdfumjsw8j` | maxLen=4000 |
|           Court Order Service Restriction | XdString | `hnswfui7gnozkpkdzthkv63k` | maxLen=4000 |
|           Court Order Special Instruction | XdString | `rx3aa299g7few8n0lwta3d5k` | maxLen=4000 |
|           Court Order Status | XdString | `ns3ozgncazaww32pt21xwlsx` | maxLen=255 |
|           Investigator Narrative | XdString | `yflt75jeej9zi0ggpk7a40vh` | maxLen=4000 |
|           Warrant Appearance Bail Forfeit | XdString | `gla0va2ai0y6h5app3hjuy7z` | maxLen=4000 |
|           Warrant Category | XdString | `q1ucym0sdb50ul0dh4an7uiu` | maxLen=4000 |
|           Warrant Extradition Limitation | XdString | `xa3a1l7n8x6s4glz6ljturmi` | maxLen=4000 |
|           Warrant Extradition State Name | XdString | `fsuvrxire02uwrjn7o86h67v` | maxLen=255 |
|           Warrant Further Processing | XdString | `p1u72psulfec4t84c1h6r9py` | maxLen=4000 |
|           Warrant Level | XdString | `esrjz9mbl7i6mxmlpz9x8gfo` | maxLen=4000 |
|           Warrant Probable Cause | XdString | `clowg6s3h8bka9pz62m4w19g` | maxLen=4000 |
|           Warrant Category Code | XdToken | `nybx5g6ieupsxch5d3142xk2` | 12 enum(s) |
|           Warrant Extradition Limitation Code (ncic) | XdToken | `nrj8o3fruv4pqcqux7x1uqut` | 12 enum(s) |
|           Court Order Issuing Date | XdTemporal | `b9kf6j37tgsufo27lldk4j35` | -- |
|           Court Order Recall Date | XdTemporal | `l2uwnj8sj9c5gu4p900qpftr` | -- |
|           Court Order Service Date | XdTemporal | `mrhq3k775y5xvhsr91dzwrow` | -- |
|       **Evidence** | Cluster | `ik7jsjn14b33e2e17vpyjy0s` | 14 components; 1 sub-cluster(s) |
|         Evidence Returned Indicator | XdBoolean | `nl0nc7he5y0vomcri2lm94pg` | -- |
|         Evidence Collector Reference | XdString | `ggng05qcvhwqf0zffszuuwt0` | maxLen=2000; pattern=`\S+` |
|         Evidence Item Text | XdString | `uohztmc00ujlrtdt7w8i3204` | maxLen=4000 |
|         Evidence Number Identification | XdString | `c6l164cv8rfri00jf82aklvk` | maxLen=64 |
|         Evidence Other Identification | XdString | `s72psyxgu6xmklo6fe3ueb63` | maxLen=64 |
|         Evidence Previous Location Reference | XdString | `et08zgorkjfpuglpbn14cebr` | maxLen=2000; pattern=`\S+` |
|         Evidence Quantity | XdString | `pws0sqdo2e71jn7t3w17mbn5` | maxLen=4000 |
|         Evidence Receipt Identification | XdString | `ei96kghkgp7n9voc2j3pakjm` | maxLen=64 |
|         Evidence Return Recipient Entity Reference | XdString | `m412ypvtw4s2asyayk6iwk8z` | maxLen=2000; pattern=`\S+` |
|         Evidence Taken From Entity Reference | XdString | `yfw996wgh473ynrmt8pg77ow` | maxLen=2000; pattern=`\S+` |
|         Evidence Taken Location Reference | XdString | `i84pm24tttinpgn4a3dg5o34` | maxLen=2000; pattern=`\S+` |
|         IBIS Number | XdString | `kwnh9aoww5n6b050zgpb5h0j` | maxLen=4000 |
|         Evidence Documentation Binary | XdFile | `cqharj73hcqlltgqwunn6brc` | -- |
|         Evidence Amount | XdQuantity | `us0wiv5ggcv7sk3cnd2k95n3` | units=Currency |
|         **Item** | Cluster | `lg5428xoix73dbvzmmv2rp4n` | 26 components |
|           Item Lease Indicator | XdBoolean | `yuh5h9tkikwhy3yz18q8bto3` | -- |
|           Item Rental Indicator | XdBoolean | `xjgbqfiem2s9ps0ovzqfird9` | -- |
|           Conveyance Color Primary | XdString | `vihtgt1np7at3irc2sdiowpt` | maxLen=4000 |
|           Item Action | XdString | `zwrul3zsk63mt7f1sct83liy` | maxLen=4000 |
|           Item Brand Name | XdString | `k5gokizy3d4m7i8tkzcaoh1m` | maxLen=255 |
|           Item Category | XdString | `c8kch7br7p84sh49eiy2x43u` | maxLen=4000 |
|           Item Color Description | XdString | `lpnc8nbxebzjochs2t2i7cnz` | maxLen=4000 |
|           Item Condition | XdString | `y2hid2beohloizavjcoshwag` | maxLen=4000 |
|           Item Description | XdString | `nthc5cxvqgbwptwn3rc9oyh9` | maxLen=4000 |
|           Item Make Name | XdString | `v4ulyzmy50rg6ncccy9d12zj` | maxLen=255 |
|           Item Model Name | XdString | `m141vleve8v29a0i3gjrhnq7` | maxLen=255 |
|           Item Name | XdString | `fdsyyzm08w7kjpxbfe8jnouv` | maxLen=255 |
|           Item Owner Applied ID | XdString | `g9cl1tvwpf4hn6icnwqb47x5` | maxLen=255 |
|           Item Owner Reference | XdString | `i3e4ud3iu8wbacbn1srtvp9q` | maxLen=2000; pattern=`\S+` |
|           Item Serial Identification | XdString | `qxrmjp75s3cmew1a2u42srx0` | maxLen=64 |
|           Item Status | XdString | `k004xjvdu15bhtglwnocmzbr` | maxLen=255 |
|           Item Usage | XdString | `ydnl1ukix2werqkzvp2ru97o` | maxLen=4000 |
|           Item Visible ID | XdString | `vadaqehru7eydimabpn0a5ui` | maxLen=255 |
|           Item Image | XdFile | `n6kiv2yxuq2an0dnafw3wndy` | -- |
|           Item Height | XdQuantity | `cuuxn4u0nidn6yqjmwd1dsak` | units=Length Units (SI and customary) |
|           Item Length | XdQuantity | `lqx9jgmwzhx1ch6y0hnb9rgq` | units=Length Units (SI and customary) |
|           Item Quantity | XdQuantity | `aps42faaohh0qzshboyouvrn` | units=Unitless |
|           Item Value Amount | XdQuantity | `ipyid2z04f702k38cwfia470` | units=Currency |
|           Item Weight | XdQuantity | `fnbrrjymmjiyikqptqhcv07k` | units=Mass Units (SI and customary) |
|           Item Width | XdQuantity | `bvu8m21jqs1jp0ehcbp64ozd` | units=Length Units (SI and customary) |
|           Item Model Year Date | XdTemporal | `yukyc20wc5gvq4m64gdhdq7i` | -- |
|       **Service Call** | Cluster | `q4rofla68qmuc4nujqf0rhy9` | 18 components |
|         Service Call Assigned Unit Reference | XdString | `f6b83ulwated8ixsrsifgjxm` | maxLen=2000; pattern=`\S+` |
|         Service Call Assisting Unit Reference | XdString | `bt5eylcl4wabfiys0uya0bz1` | maxLen=2000; pattern=`\S+` |
|         Service Call Category | XdString | `xxm70kp21jagul1assb1fz6a` | maxLen=4000 |
|         Service Call Clearance | XdString | `klh8unsq1foyx0cnqz9m510r` | maxLen=4000 |
|         Service Call Dispatched Official Reference | XdString | `zs0v49gnmawtsbs093ul86aa` | maxLen=2000; pattern=`\S+` |
|         Service Call Dispatcher Reference | XdString | `yxv9hvoii1qjyhfhm843qn62` | maxLen=2000; pattern=`\S+` |
|         Service Call Mechanism | XdString | `ttztdutcjfvpcbzhhazwitf4` | maxLen=4000 |
|         Service Call Operator Reference | XdString | `th054p79t4l2v5cbsb5wznlz` | maxLen=2000; pattern=`\S+` |
|         Service Call Originator Reference | XdString | `hqy2n4tpo3ohy6d9x6tfxxcs` | maxLen=2000; pattern=`\S+` |
|         Service Call Placed Location Reference | XdString | `hm9dspz5fzy8wtk9g3c8urrm` | maxLen=2000; pattern=`\S+` |
|         Service Call Response Location Reference | XdString | `oyyxzuby0fx9qpdeadh1k521` | maxLen=2000; pattern=`\S+` |
|         Service Call Response Person Reference | XdString | `cag7rjq4gdnvt04fus3t8cnp` | maxLen=2000; pattern=`\S+` |
|         Service Call Category Code | XdToken | `niwbptlcq66sqjhjqtdle4dk` | 77 enum(s) |
|         Service Call Clearance Category Code | XdToken | `qgte5wrursjvdn5pll6ofxdp` | 77 enum(s) |
|         Service Call Mechanism Code | XdToken | `uktdjkmqkghk05eajw0v8ijy` | 10 enum(s) |
|         Service Call Arrived Date | XdTemporal | `tx8eqhctmdj03hrjaaauxtou` | -- |
|         Service Call Cleared Date | XdTemporal | `r5pqk41hv4072qexg1j6hjfg` | -- |
|         Service Call Dispatched Date | XdTemporal | `gikptovk9x9i4bsv3oqy59e3` | -- |
|     **Quarantine Enforcement** | Cluster | `trsld3qzyd50w2ami9zqo1ro` | 5 components; 1 sub-cluster(s) |
|       Issuing Authority | XdString | `ixmedhicidzpi7g6g2huqzvv` | minLen=1; maxLen=200 |
|       Quarantine Zone | XdString | `r34gm210y9jifbyxa0fcxy96` | minLen=1; maxLen=200 |
|       Compliance Status | XdToken | `ihoatduhb7fckjw0ezq5u7g1` | 3 enum(s) |
|       Quarantine End Date | XdTemporal | `lohvu07ok3c3xvesa16htf2m` | -- |
|       Quarantine Start Date | XdTemporal | `vq30hd0dl6v59d3ttyyvg6rp` | -- |
|       **Court Order** | Cluster | `fg5heqb4g4c64t3cg424qmbr` | 31 components; 1 sub-cluster(s) |
|         Court Order For Escape Subject Indicator | XdBoolean | `y1czfi1tuwkfwr0hxkmn80t8` | -- |
|         Court Order From Other Agency Indicator | XdBoolean | `s4mealak3lkbcz4d36c36yel` | -- |
|         Court Order Out Of State Indicator | XdBoolean | `u3azkagzlnlpih2u2d2zl9a6` | -- |
|         Court Order Reviewed Indicator | XdBoolean | `ulgiutnvl2zt7q1wflsfegd3` | -- |
|         Activity Identification | XdString | `g7bzqfrt27ftx37ptypizu23` | maxLen=64 |
|         Court Order Designated Item Reference | XdString | `gdde6xvazk9dpk3pw1u9ld2m` | maxLen=2000; pattern=`\S+` |
|         Court Order Designated Location Reference | XdString | `jdusjy3g6dzdk3okjayoikqx` | maxLen=2000; pattern=`\S+` |
|         Court Order Designated Organization Reference | XdString | `p5z649b3d5uo3pf2uhicb7pf` | maxLen=2000; pattern=`\S+` |
|         Court Order Designated Subject Reference | XdString | `q5o8zfs0zxr1x94t4r5d78r2` | maxLen=2000; pattern=`\S+` |
|         Court Order Enforcement Agency Reference | XdString | `e1xs007153a0mojx8p0dr5gq` | maxLen=2000; pattern=`\S+` |
|         Court Order Issuing Court Reference | XdString | `ox4ezu1x0l6uslw009o5o3ep` | maxLen=2000; pattern=`\S+` |
|         Court Order Issuing Judicial Official Reference | XdString | `e1ou1pt787adx1znpthus3es` | maxLen=2000; pattern=`\S+` |
|         Court Order Jurisdiction Reference | XdString | `bysd5zlwmjae93onee9qow3q` | maxLen=2000; pattern=`\S+` |
|         Court Order Recall Reason | XdString | `cuaprdadnz523w1nccvh9f85` | maxLen=4000 |
|         Court Order Receiver Reference | XdString | `t8bz2v2cuhlfku8mhjjju4ny` | maxLen=2000; pattern=`\S+` |
|         Court Order Request Entity Reference | XdString | `tv3j7ugjmkbwod1z7qni92qd` | maxLen=2000; pattern=`\S+` |
|         Court Order Request Reason | XdString | `npvkounrc4jfu0alfrlahtjp` | maxLen=4000 |
|         Court Order Service Caution | XdString | `abu0757ze11y2tsrse9vraw0` | maxLen=4000 |
|         Court Order Service Description | XdString | `zw8vmrnz3yv5sftdfumjsw8j` | maxLen=4000 |
|         Court Order Service Restriction | XdString | `hnswfui7gnozkpkdzthkv63k` | maxLen=4000 |
|         Court Order Signature Method | XdString | `nhg3r6tmojbcekb3p65f6yok` | maxLen=4000 |
|         Court Order Special Instruction | XdString | `rx3aa299g7few8n0lwta3d5k` | maxLen=4000 |
|         Court Order Status | XdString | `ns3ozgncazaww32pt21xwlsx` | maxLen=255 |
|         Court Order Supervising Agency Reference | XdString | `mlh4i1yawch40voxq3ob7aiv` | maxLen=2000; pattern=`\S+` |
|         Activity Date | XdTemporal | `qprm8z9y4rzid9hiwojslia6` | -- |
|         Court Order Issuing Date | XdTemporal | `b9kf6j37tgsufo27lldk4j35` | -- |
|         Court Order Recall Date | XdTemporal | `l2uwnj8sj9c5gu4p900qpftr` | -- |
|         Court Order Request Date | XdTemporal | `pto24zuxg99lzcq16jttxpjj` | -- |
|         Court Order Service Attempted Date | XdTemporal | `vne53evrmub29q8qbewrpd6c` | -- |
|         Court Order Service Date | XdTemporal | `mrhq3k775y5xvhsr91dzwrow` | -- |
|         Court Order Service Received Date | XdTemporal | `oupniefl4w056si34xn2cj43` | -- |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: Law Enforcement Record 4.4.0
  [Cluster] Law Enforcement Governed Record
    [XdFile] Digital Signature Proof
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] Incident Report
      [XdString] National ID (CID)
      [XdToken] City
      [XdToken] Incident Status
      [XdToken] Province
      [Cluster] Charge Details (Cordova)
        [XdQuantity] Fine or Bail Amount
        [XdTemporal] Disposition Date
      [Cluster] Incident
        [XdBoolean] Amber Alert Issued Indicator
        [XdBoolean] Incident Arrest Made Indicator
        [XdBoolean] Incident Criminal Indicator
        [XdBoolean] Incident Crisis Response Team Activated Indicator
        [XdBoolean] Incident Emergency Service Required Indicator
        [XdBoolean] Incident Evidence Held Indicator
        [XdBoolean] Incident Force Involved Indicator
        [XdBoolean] Incident Law Enforcement Summoned Indicator
        [XdBoolean] Incident Minor Involved Indicator
        [XdBoolean] Incident Official Present Indicator
        [XdBoolean] Incident Prints Requested Indicator
        [XdBoolean] Incident Traffic Accident Involved Indicator
        [XdBoolean] Incident Weapon Involved Indicator
        [XdString] Activity Description
        [XdString] Activity Identification
        [XdString] Incident Assisting Official Reference
        [XdString] Incident Damaged Item Reference
        [XdString] Incident Day Period
        [XdString] Incident Drug Reference
        [XdString] Incident Facility Reference
        [XdString] Incident General Category
        [XdString] Incident Injury Level
        [XdString] Incident Issues
        [XdString] Incident Jurisdictional Organization Reference
        [XdString] Incident Level
        [XdString] Incident Log Identification
        [XdString] Incident Method Description
        [XdString] Incident Observation
        [XdString] Incident Recovered Item Reference
        [XdString] Incident Reported Narrative
        [XdString] Incident Reporting Official Reference
        [XdString] Incident Response Official Reference
        [XdString] Incident Response Organization Reference
        [XdString] Incident Seized Item Reference
        [XdString] Incident Stolen Item Reference
        [XdString] Incident Subject Reference
        [XdString] Incident Subject Weapon Reference
        [XdString] Incident Supervising Official Reference
        [XdString] Incident Victim Reference
        [XdString] Incident Weather
        [XdString] Incident Witness Reference
        [XdToken] Incident Category Code
        [XdToken] Incident Category UCR Code
        [XdToken] Incident Dissemination Level Code
        [XdToken] Incident Exceptional Clearance Code
        [XdToken] Incident Lighting Code
        [XdToken] Incident Status Code
        [XdCount] Incident Arrest Count Quantity
        [XdQuantity] Incident Recovered Vehicle Quantity
        [XdQuantity] Incident Stolen Vehicle Quantity
        [XdQuantity] Incident Structures Entered Quantity
        [XdTemporal] Activity Date
        [XdTemporal] Incident Exceptional Clearance Date
        [Cluster] Arrest
          [XdBoolean] Arrest Community Supervision Indicator
          [XdBoolean] Arrest Intoxicant Involved Indicator
          [XdBoolean] Arrest Resisted Indicator
          [XdBoolean] Arrest Subject Rights Read Indicator
          [XdBoolean] Arrest Summons Indicator
          [XdBoolean] Arrest Under Influence Indicator
          [XdString] Activity Description
          [XdString] Activity Identification
          [XdString] Arrest Agency Record Identification
          [XdString] Arrest Agency Reference
          [XdString] Arrest Apprehension Detention Order Reference
          [XdString] Arrest Bail Recommendation
          [XdString] Arrest Involved Item Reference
          [XdString] Arrest Involved Organization Reference
          [XdString] Arrest Involved Weapon Reference
          [XdString] Arrest Probable Cause
          [XdString] Arrest Sequence ID
          [XdString] Arrest Subject Reference
          [XdString] Arrest Subject Rights Read Response
          [XdToken] Arrest Category Code
          [XdToken] Arrest Category JABS Code
          [XdToken] Arrest Subject Count Code
          [XdTemporal] Activity Date
          [XdTemporal] Arrest Arraignment Date
          [Cluster] Charge
            [XdBoolean] Charge Accident Related Indicator
            [XdBoolean] Charge Arrest Reason Indicator
            [XdBoolean] Charge Employment Related Indicator
            [XdBoolean] Charge Felony Indicator
            [XdBoolean] Charge Highest Indicator
            [XdBoolean] Charge Serious Violent Indicator
            [XdString] Charge Applicability
            [XdString] Charge Category Description
            [XdString] Charge Degree
            [XdString] Charge Description
            [XdString] Charge Disposition Other
            [XdString] Charge Filer Entity Reference
            [XdString] Charge Identification
            [XdString] Charge Legal Description
            [XdString] Charge NCIC
            [XdString] Charge Originator Entity Reference
            [XdString] Charge Qualifier
            [XdString] Charge Reducing Factor
            [XdString] Charge Sentence Range
            [XdString] Charge Sequence ID
            [XdString] Charge Severity
            [XdString] Charge Severity Description
            [XdString] Charge Special Allegation
            [XdString] Charge Status
            [XdString] Charge Subject Reference
            [XdString] Charge Text
            [XdString] Charge Tracking Identification
            [XdString] Charge UCR Crime Category
            [XdString] Charge Victim Reference
            [XdToken] Charge UCR Code
            [XdCount] Charge Count Quantity
            [XdQuantity] Charge Recommended Bail Amount
            [XdTemporal] Charge Filing Date
            [Cluster] Disposition
              [XdString] Disposition Category Code
              [XdString] Disposition Description
              [XdString] Disposition Entity Reference
              [XdString] Disposition Reason
              [XdString] Disposition Reported Authority
              [XdString] Disposition Text
              [XdTemporal] Disposition Date
            [Cluster] Plea
              [XdBoolean] Plea Guilty Indicator
              [XdBoolean] Plea Negotiated Indicator
              [XdBoolean] Plea No Contest Indicator
              [XdString] Plea Description
              [XdString] Plea Recommendation
            [Cluster] Sentence
              [XdBoolean] Sentence Aggravated Indicator
              [XdBoolean] Sentence Confinement Credit Indicator
              [XdBoolean] Sentence Deferred Indicator
              [XdBoolean] Sentence Register Sex Offender Indicator
              [XdBoolean] Sentence Suspended Indicator
              [XdString] Sentence Charge Reference
              [XdString] Sentence Description
              [XdString] Sentence Grouping
              [XdString] Sentence Imposed
              [XdString] Sentence Issuer Entity Reference
              [XdString] Sentence Subject Reference
              [XdQuantity] Sentence Confinement Credit Day Quantity
              [XdQuantity] Sentence Court Fee Amount
              [XdQuantity] Sentence Fine Amount
              [XdTemporal] Sentence Expiration Date
              [Cluster] Condition (Requirement)
                [XdBoolean] Condition Mandatory Indicator
                [XdBoolean] Condition Violated Indicator
                [XdString] Condition Group ID
                [XdString] Condition Violation
                [XdTemporal] Condition Set Date
                [XdTemporal] Condition Violation Date
              [Cluster] Term
                [XdBoolean] Term Life Indicator
                [XdTemporal] Term Duration
                [XdTemporal] Term Maximum Duration
                [XdTemporal] Term Minimum Duration
            [Cluster] Statute
              [XdBoolean] Statute Offense Enhanceable Indicator
              [XdString] Statute Category
              [XdString] Statute Code Identification
              [XdString] Statute Code Section Identification
              [XdString] Statute Description
              [XdString] Statute Jurisdiction Reference
              [XdString] Statute Keyword
              [XdString] Statute Level
              [XdString] Statute Offense Identification
              [XdString] Statute Offense State Code
              [XdString] Statute Status
              [XdString] Statute Text
              [XdTemporal] Statute Enactment Date
              [XdTemporal] Statute Repeal Date
            [Cluster] Verdict
              [XdBoolean] Verdict Issuing Judge Indicator
              [XdString] Verdict Description
              [XdString] Verdict Disposition Name
              [XdString] Verdict Issuing Court Reference
              [XdString] Verdict Issuing Judge Reference
              [XdString] Verdict Subject Reference
              [XdTemporal] Verdict Date
              [XdTemporal] Verdict Disposition Date
          [Cluster] Custody Transfer
            [XdString] Custody Transfer Action
            [XdString] Custody Transfer Item Reference
            [XdString] Custody Transfer Receiving Enforcement Agency Reference
            [XdString] Custody Transfer Receiving Enforcement Facility Reference
            [XdString] Custody Transfer Receiving Enforcement Official Reference
            [XdString] Custody Transfer Releasing Enforcement Agency Reference
            [XdString] Custody Transfer Releasing Enforcement Facility Reference
            [XdString] Custody Transfer Releasing Enforcement Official Reference
            [XdString] Custody Transfer Subject Reference
          [Cluster] Enforcement Official
            [XdString] Employee Rank
            [XdString] Enforcement Official Badge Identification
            [XdString] Enforcement Official Category
            [XdString] Enforcement Official POST License Identification
            [XdString] Enforcement Unit Identification
            [XdString] Enforcement Unit Name
            [XdToken] Enforcement Official Activity Category Code
            [XdToken] Enforcement Official Assignment Category Code
            [Cluster] Full Name (Person)
              [XdString] Given Name (Person)
              [XdString] Middle Name (Person)
              [XdString] Name Prefix
              [XdString] Name Suffix
              [XdString] Surname (Person)
              [XdToken] Name Use
            [Cluster] Organization (NIEM)
              [XdBoolean] Organization Active Indicator
              [XdBoolean] Organization Incorporated Indicator
              [XdString] Organization Abbreviation
              [XdString] Organization Branch Name
              [XdString] Organization Category
              [XdString] Organization Description
              [XdString] Organization Doing Business As Name
              [XdString] Organization Identification
              [XdString] Organization Jurisdiction Reference
              [XdString] Organization LEI Identification
              [XdString] Organization ORI Identification
              [XdString] Organization Parent Organization Reference
              [XdString] Organization Principal Official Reference
              [XdString] Organization Status
              [XdString] Organization Sub Unit Name
              [XdString] Organization Tax Identification
              [XdString] Organization Unit Name
              [XdString] Organization Name
              [XdToken] Organization Category ND Ex Code
              [XdTemporal] Organization Established Date
              [XdTemporal] Organization Incorporation Date
              [XdTemporal] Organization Termination Date
              [Cluster] Contact Information (NIEM)
                [XdString] Contact Entity Description
                [XdString] Contact Information Description
                [XdToken] Contact Information Availability Code
                [Cluster] Address (NIEM)
                  [XdString] Address Building Name
                  [XdString] Address County Name
                  [XdString] Address Delivery Point
                  [XdString] Address Full
                  [XdString] Address Postal Extension Code
                  [XdString] Address Private Mailbox
                  [XdString] Address Recipient Name
                  [XdString] Address Secondary Unit
                  [XdString] Address Urbanization Name
                  [XdToken] Address Category Code
                  [Cluster] County (fips)
                    [XdLink] Code List: fips US County5 Digit
                    [XdString] Code Display Text
                    [XdString] County Code (fips)
                  [Cluster] International Address
                    [XdString] Address (Line 1)
                    [XdString] Address (Line 2)
                    [XdString] City Name
                    [XdString] Postal Code
                    [XdString] Region Name
                    [XdToken] Address Use
                    [XdToken] Country Code ISO 3166
                [Cluster] Contact Point
                  [XdLink] Website URL
                  [XdString] Email Address
                  [XdString] Fax Number
                  [XdString] Phone Number
                  [XdToken] Contact Method
                  [XdToken] Contact Use
              [Cluster] Location (NIEM)
                [XdString] Location Category
                [XdString] Location Description
                [XdString] Location Directions
                [XdString] Location Identification
                [XdString] Location Landmark Name
                [XdString] Location Name
                [XdString] Location Range Description
                [XdString] Location Surrounding Area Description
                [XdQuantity] Location Altitude
                [XdQuantity] Location Elevation
                [Cluster] Address (NIEM) (circular ref)
                [Cluster] Geolocation
                  [XdToken] Geodetic Datum
                  [XdQuantity] Altitude
                  [XdQuantity] Latitude
                  [XdQuantity] Longitude
                [Cluster] Locale
                  [XdString] Locale Census Block ID
                  [XdString] Locale Census Tract ID
                  [XdString] Locale Community Name
                  [XdString] Locale Description
                  [XdString] Locale District Name
                  [XdString] Locale Emergency Services Jurisdiction ID
                  [XdString] Locale Emergency Services Name
                  [XdString] Locale Fire Jurisdiction ID
                  [XdString] Locale Judicial District Name
                  [XdString] Locale Neighborhood Name
                  [XdString] Locale Police Beat
                  [XdString] Locale Police Grid
                  [XdString] Locale Police Jurisdiction ID
                  [XdString] Locale Region Name
                  [XdString] Locale Subdivision Name
                  [XdString] Locale Zone Name
          [Cluster] Location (NIEM) (circular ref)
          [Cluster] Release
            [XdBoolean] Release Residence Indicator
            [XdString] Release Date Category
            [XdString] Release From Location Reference
            [XdString] Release Issuer Reference
            [XdString] Release Person Reference
            [XdString] Release Recipient Reference
            [XdString] Release Supervisor Reference
            [XdString] Release To Facility Reference
            [XdString] Release To Location Reference
            [XdQuantity] Release Funds Amount
            [XdTemporal] Release Date
          [Cluster] Warrant
            [XdString] Court Order Designated Subject Reference
            [XdString] Court Order Enforcement Agency Reference
            [XdString] Court Order Issuing Court Reference
            [XdString] Court Order Issuing Judicial Official Reference
            [XdString] Court Order Jurisdiction Reference
            [XdString] Court Order Recall Reason
            [XdString] Court Order Service Caution
            [XdString] Court Order Service Description
            [XdString] Court Order Service Restriction
            [XdString] Court Order Special Instruction
            [XdString] Court Order Status
            [XdString] Investigator Narrative
            [XdString] Warrant Appearance Bail Forfeit
            [XdString] Warrant Category
            [XdString] Warrant Extradition Limitation
            [XdString] Warrant Extradition State Name
            [XdString] Warrant Further Processing
            [XdString] Warrant Level
            [XdString] Warrant Probable Cause
            [XdToken] Warrant Category Code
            [XdToken] Warrant Extradition Limitation Code (ncic)
            [XdTemporal] Court Order Issuing Date
            [XdTemporal] Court Order Recall Date
            [XdTemporal] Court Order Service Date
        [Cluster] Evidence
          [XdBoolean] Evidence Returned Indicator
          [XdString] Evidence Collector Reference
          [XdString] Evidence Item Text
          [XdString] Evidence Number Identification
          [XdString] Evidence Other Identification
          [XdString] Evidence Previous Location Reference
          [XdString] Evidence Quantity
          [XdString] Evidence Receipt Identification
          [XdString] Evidence Return Recipient Entity Reference
          [XdString] Evidence Taken From Entity Reference
          [XdString] Evidence Taken Location Reference
          [XdString] IBIS Number
          [XdFile] Evidence Documentation Binary
          [XdQuantity] Evidence Amount
          [Cluster] Item
            [XdBoolean] Item Lease Indicator
            [XdBoolean] Item Rental Indicator
            [XdString] Conveyance Color Primary
            [XdString] Item Action
            [XdString] Item Brand Name
            [XdString] Item Category
            [XdString] Item Color Description
            [XdString] Item Condition
            [XdString] Item Description
            [XdString] Item Make Name
            [XdString] Item Model Name
            [XdString] Item Name
            [XdString] Item Owner Applied ID
            [XdString] Item Owner Reference
            [XdString] Item Serial Identification
            [XdString] Item Status
            [XdString] Item Usage
            [XdString] Item Visible ID
            [XdFile] Item Image
            [XdQuantity] Item Height
            [XdQuantity] Item Length
            [XdQuantity] Item Quantity
            [XdQuantity] Item Value Amount
            [XdQuantity] Item Weight
            [XdQuantity] Item Width
            [XdTemporal] Item Model Year Date
        [Cluster] Location (NIEM) (circular ref)
        [Cluster] Service Call
          [XdString] Service Call Assigned Unit Reference
          [XdString] Service Call Assisting Unit Reference
          [XdString] Service Call Category
          [XdString] Service Call Clearance
          [XdString] Service Call Dispatched Official Reference
          [XdString] Service Call Dispatcher Reference
          [XdString] Service Call Mechanism
          [XdString] Service Call Operator Reference
          [XdString] Service Call Originator Reference
          [XdString] Service Call Placed Location Reference
          [XdString] Service Call Response Location Reference
          [XdString] Service Call Response Person Reference
          [XdToken] Service Call Category Code
          [XdToken] Service Call Clearance Category Code
          [XdToken] Service Call Mechanism Code
          [XdTemporal] Service Call Arrived Date
          [XdTemporal] Service Call Cleared Date
          [XdTemporal] Service Call Dispatched Date
      [Cluster] Quarantine Enforcement
        [XdString] Issuing Authority
        [XdString] Quarantine Zone
        [XdToken] Compliance Status
        [XdTemporal] Quarantine End Date
        [XdTemporal] Quarantine Start Date
        [Cluster] Court Order
          [XdBoolean] Court Order For Escape Subject Indicator
          [XdBoolean] Court Order From Other Agency Indicator
          [XdBoolean] Court Order Out Of State Indicator
          [XdBoolean] Court Order Reviewed Indicator
          [XdString] Activity Identification
          [XdString] Court Order Designated Item Reference
          [XdString] Court Order Designated Location Reference
          [XdString] Court Order Designated Organization Reference
          [XdString] Court Order Designated Subject Reference
          [XdString] Court Order Enforcement Agency Reference
          [XdString] Court Order Issuing Court Reference
          [XdString] Court Order Issuing Judicial Official Reference
          [XdString] Court Order Jurisdiction Reference
          [XdString] Court Order Recall Reason
          [XdString] Court Order Receiver Reference
          [XdString] Court Order Request Entity Reference
          [XdString] Court Order Request Reason
          [XdString] Court Order Service Caution
          [XdString] Court Order Service Description
          [XdString] Court Order Service Restriction
          [XdString] Court Order Signature Method
          [XdString] Court Order Special Instruction
          [XdString] Court Order Status
          [XdString] Court Order Supervising Agency Reference
          [XdTemporal] Activity Date
          [XdTemporal] Court Order Issuing Date
          [XdTemporal] Court Order Recall Date
          [XdTemporal] Court Order Request Date
          [XdTemporal] Court Order Service Attempted Date
          [XdTemporal] Court Order Service Date
          [XdTemporal] Court Order Service Received Date
          [Cluster] Condition (Requirement) (circular ref)
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Law Enforcement Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Law Enforcement Governed Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Law Enforcement Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/law-enforcement-governed-record` |
| Law Enforcement Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Law Enforcement Governed Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kcam9lm7091vqtvb253ixjxr` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.w3.org/TR/vc-data-model/#credentials` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q210824` |
| Digital Signature Proof | `skos:broadMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| Incident Report | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Report | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Incident Report | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/incident-report` |
| Incident Report | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/IncidentType` |
| Incident Report | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-songhwxr1fp8niqba4fd0yd9` |
| National ID (CID) | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| National ID (CID) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1140371` |
| National ID (CID) | `skos:broadMatch` | `https://schema.org/identifier` |
| City | `rdfs:isDefinedBy` | `http://schema.org/City` |
| City | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| City | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Incident Status | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Incident Status | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Incident Status | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q2443992` |
| Province | `rdfs:isDefinedBy` | `http://schema.org/AdministrativeArea` |
| Province | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Province | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Province | `rdfs:isDefinedBy` | `https://schema.org/State` |
| Charge Details (Cordova) | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Details (Cordova) | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Charge Details (Cordova) | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/charge-details-cordova` |
| Charge Details (Cordova) | `skos:closeMatch` | `https://schema.org/ItemList` |
| Charge Details (Cordova) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-c3eoo0vfid9c8riruf7uoyz2` |
| Fine or Bail Amount | `skos:broadMatch` | `https://www.wikidata.org/wiki/Q313614` |
| Fine or Bail Amount | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q186361` |
| Fine or Bail Amount | `rdfs:isDefinedBy` | `https://schema.org/MonetaryAmount` |
| Disposition Date | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q117195543` |
| Disposition Date | `skos:broadMatch` | `https://schema.org/Date` |
| Incident | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident` |
| Incident | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Incident | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/IncidentType` |
| Incident | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rn7wro9h803b4q3d2ozs6uai` |
| Amber Alert Issued Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Amber Alert Issued Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-amber-alert-issued-indicator` |
| Amber Alert Issued Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Amber Alert Issued Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/AmberAlertIssuedIndicator` |
| Incident Arrest Made Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Arrest Made Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-arrest-made-indicator` |
| Incident Arrest Made Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Arrest Made Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentArrestMadeIndicator` |
| Incident Criminal Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Criminal Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-criminal-indicator` |
| Incident Criminal Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Criminal Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentCriminalIndicator` |
| Incident Crisis Response Team Activated Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Crisis Response Team Activated Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-crisis-response-team-activated-indicator` |
| Incident Crisis Response Team Activated Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Crisis Response Team Activated Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentCrisisResponseTeamActivatedIndicator` |
| Incident Emergency Service Required Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Emergency Service Required Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-emergency-service-required-indicator` |
| Incident Emergency Service Required Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Emergency Service Required Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentEmergencyServiceRequiredIndicator` |
| Incident Emergency Service Required Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ptc8dfx1oxeycopfjof6vjab` |
| Incident Evidence Held Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Evidence Held Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-evidence-held-indicator` |
| Incident Evidence Held Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Evidence Held Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentEvidenceHeldIndicator` |
| Incident Evidence Held Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ig5k46e5wzczsbgqk25ykfn9` |
| Incident Force Involved Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Force Involved Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-force-involved-indicator` |
| Incident Force Involved Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Force Involved Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentForceInvolvedIndicator` |
| Incident Force Involved Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tj7jciq1rv4ya5mr5m2c1zs0` |
| Incident Law Enforcement Summoned Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Law Enforcement Summoned Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-law-enforcement-summoned-indicator` |
| Incident Law Enforcement Summoned Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Law Enforcement Summoned Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentLawEnforcementSummonedIndicator` |
| Incident Minor Involved Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Minor Involved Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-minor-involved-indicator` |
| Incident Minor Involved Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Minor Involved Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentMinorInvolvedIndicator` |
| Incident Official Present Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Official Present Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-official-present-indicator` |
| Incident Official Present Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Official Present Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentOfficialPresentIndicator` |
| Incident Prints Requested Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Prints Requested Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-prints-requested-indicator` |
| Incident Prints Requested Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Prints Requested Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentPrintsRequestedIndicator` |
| Incident Traffic Accident Involved Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Traffic Accident Involved Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-traffic-accident-involved-indicator` |
| Incident Traffic Accident Involved Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Traffic Accident Involved Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentTrafficAccidentInvolvedIndicator` |
| Incident Traffic Accident Involved Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lr0uobalchgtucjdu68gxt8o` |
| Incident Weapon Involved Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Weapon Involved Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-weapon-involved-indicator` |
| Incident Weapon Involved Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Weapon Involved Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentWeaponInvolvedIndicator` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/activity-description` |
| Activity Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Activity Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ActivityDescriptionText` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rguhpkd7s2d9a51392aon7ir` |
| Activity Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/activity-identification` |
| Activity Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Activity Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ActivityIdentification` |
| Incident Assisting Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Assisting Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-assisting-official-reference` |
| Incident Assisting Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Assisting Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentAssistingOfficial` |
| Incident Damaged Item Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Damaged Item Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-damaged-item-reference` |
| Incident Damaged Item Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Damaged Item Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentDamagedItem` |
| Incident Day Period | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Day Period | `dcterms:identifier` | `https://axius-sdc.com/library/niem/incident-day-period` |
| Incident Day Period | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Incident Day Period | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/IncidentDayPeriodText` |
| Incident Drug Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Drug Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-drug-reference` |
| Incident Drug Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Drug Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentDrug` |
| Incident Facility Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Facility Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-facility-reference` |
| Incident Facility Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Facility Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentFacility` |
| Incident General Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident General Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-general-category` |
| Incident General Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident General Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentGeneralCategoryText` |
| Incident Injury Level | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Injury Level | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-injury-level` |
| Incident Injury Level | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Injury Level | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentInjuryLevelText` |
| Incident Issues | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Issues | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-issues` |
| Incident Issues | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Issues | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentIssuesText` |
| Incident Jurisdictional Organization Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Jurisdictional Organization Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/incident-jurisdictional-organization-reference` |
| Incident Jurisdictional Organization Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Incident Jurisdictional Organization Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/IncidentJurisdictionalOrganization` |
| Incident Level | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Level | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-level` |
| Incident Level | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Level | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentLevelText` |
| Incident Log Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Log Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-log-identification` |
| Incident Log Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Log Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentLogIdentification` |
| Incident Log Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yi2189u4pinqitlmm5t6ccrd` |
| Incident Method Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Method Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-method-description` |
| Incident Method Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Method Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentMethodDescriptionText` |
| Incident Observation | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Observation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/incident-observation` |
| Incident Observation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Incident Observation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/IncidentObservationText` |
| Incident Recovered Item Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Recovered Item Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-recovered-item-reference` |
| Incident Recovered Item Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Recovered Item Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentRecoveredItem` |
| Incident Reported Narrative | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Reported Narrative | `dcterms:identifier` | `https://axius-sdc.com/library/niem/incident-reported-narrative` |
| Incident Reported Narrative | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Incident Reported Narrative | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/IncidentReportedNarrative` |
| Incident Reported Narrative | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ih4ten5i3ctsb479pcugkud0` |
| Incident Reporting Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Reporting Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-reporting-official-reference` |
| Incident Reporting Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Reporting Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentReportingOfficial` |
| Incident Response Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Response Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-response-official-reference` |
| Incident Response Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Response Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentResponseOfficial` |
| Incident Response Organization Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Response Organization Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-response-organization-reference` |
| Incident Response Organization Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Response Organization Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentResponseOrganization` |
| Incident Seized Item Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Seized Item Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-seized-item-reference` |
| Incident Seized Item Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Seized Item Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentSeizedItem` |
| Incident Seized Item Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-b3iej0gps0z6fse0rswq5x7q` |
| Incident Stolen Item Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Stolen Item Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-stolen-item-reference` |
| Incident Stolen Item Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Stolen Item Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentStolenItem` |
| Incident Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-subject-reference` |
| Incident Subject Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Subject Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentSubject` |
| Incident Subject Weapon Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Subject Weapon Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-subject-weapon-reference` |
| Incident Subject Weapon Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Subject Weapon Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentSubjectWeapon` |
| Incident Supervising Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Supervising Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-supervising-official-reference` |
| Incident Supervising Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Supervising Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentSupervisingOfficial` |
| Incident Supervising Official Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lfnbhd6mwoq8do27yekwaib1` |
| Incident Victim Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Victim Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-victim-reference` |
| Incident Victim Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Victim Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentVictim` |
| Incident Weather | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Weather | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-weather` |
| Incident Weather | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Weather | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentWeatherText` |
| Incident Witness Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Witness Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-witness-reference` |
| Incident Witness Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Witness Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentWitness` |
| Incident Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-category-code` |
| Incident Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CriminalActivityCategoryCodeSimpleType` |
| Incident Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentCategoryCode` |
| Incident Category Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nc7aq6ofnccavkmczsb2dudy` |
| Incident Category UCR Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Category UCR Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-category-ucr-code` |
| Incident Category UCR Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Category UCR Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ucr/6.0/OffenseCodeSimpleType` |
| Incident Category UCR Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentCategoryUCRCode` |
| Incident Dissemination Level Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Dissemination Level Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-dissemination-level-code` |
| Incident Dissemination Level Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Dissemination Level Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentDisseminationLevelCode` |
| Incident Dissemination Level Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentLevelDisseminationCodeSimpleType` |
| Incident Exceptional Clearance Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Exceptional Clearance Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-exceptional-clearance-code` |
| Incident Exceptional Clearance Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Exceptional Clearance Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ucr/6.0/IncidentExceptionalClearanceCodeSimpleType` |
| Incident Exceptional Clearance Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentExceptionalClearanceCode` |
| Incident Lighting Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Lighting Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-lighting-code` |
| Incident Lighting Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Lighting Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ndex/6.0/LightingCodeSimpleType` |
| Incident Lighting Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentLightingCode` |
| Incident Status Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Status Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-status-code` |
| Incident Status Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Status Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ndex/6.0/IncidentStatusCodeSimpleType` |
| Incident Status Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentStatusCode` |
| Incident Arrest Count Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Arrest Count Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-arrest-count-quantity` |
| Incident Arrest Count Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Arrest Count Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentArrestCountQuantity` |
| Incident Recovered Vehicle Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Recovered Vehicle Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-recovered-vehicle-quantity` |
| Incident Recovered Vehicle Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Recovered Vehicle Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentRecoveredVehicleQuantity` |
| Incident Stolen Vehicle Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Stolen Vehicle Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-stolen-vehicle-quantity` |
| Incident Stolen Vehicle Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Stolen Vehicle Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentStolenVehicleQuantity` |
| Incident Structures Entered Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Structures Entered Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-structures-entered-quantity` |
| Incident Structures Entered Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Structures Entered Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentStructuresEnteredQuantity` |
| Activity Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/activity-date` |
| Activity Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Activity Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ActivityDate` |
| Activity Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ihqd7ez63f7ty3zlz1288ldr` |
| Incident Exceptional Clearance Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Incident Exceptional Clearance Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-incident-exceptional-clearance-date` |
| Incident Exceptional Clearance Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Incident Exceptional Clearance Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IncidentExceptionalClearanceDate` |
| Arrest | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest` |
| Arrest | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestType` |
| Arrest | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-juvjxi56s1gptx7sw288xvu1` |
| Arrest Community Supervision Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Community Supervision Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-community-supervision-indicator` |
| Arrest Community Supervision Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Community Supervision Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestCommunitySupervisionIndicator` |
| Arrest Intoxicant Involved Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Intoxicant Involved Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-intoxicant-involved-indicator` |
| Arrest Intoxicant Involved Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Intoxicant Involved Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestIntoxicantInvolvedIndicator` |
| Arrest Resisted Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Resisted Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-resisted-indicator` |
| Arrest Resisted Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Resisted Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestResistedIndicator` |
| Arrest Subject Rights Read Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Subject Rights Read Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-subject-rights-read-indicator` |
| Arrest Subject Rights Read Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Subject Rights Read Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestSubjectRightsReadIndicator` |
| Arrest Subject Rights Read Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l7w37w6pst2w3wyqg6nd8kff` |
| Arrest Summons Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Summons Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-summons-indicator` |
| Arrest Summons Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Summons Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestSummonsIndicator` |
| Arrest Under Influence Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Under Influence Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-under-influence-indicator` |
| Arrest Under Influence Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Under Influence Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestUnderInfluenceIndicator` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/activity-description` |
| Activity Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Activity Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ActivityDescriptionText` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rguhpkd7s2d9a51392aon7ir` |
| Activity Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/activity-identification` |
| Activity Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Activity Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ActivityIdentification` |
| Arrest Agency Record Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Agency Record Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-agency-record-identification` |
| Arrest Agency Record Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Agency Record Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestAgencyRecordIdentification` |
| Arrest Agency Record Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lr8tc0c9t1o42np60os2m0eh` |
| Arrest Agency Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Agency Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-agency-reference` |
| Arrest Agency Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Agency Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestAgency` |
| Arrest Agency Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n3qzeqknnrzc9gdwk9iffhxh` |
| Arrest Apprehension Detention Order Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Apprehension Detention Order Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-apprehension-detention-order-reference` |
| Arrest Apprehension Detention Order Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Apprehension Detention Order Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestApprehensionDetentionOrder` |
| Arrest Bail Recommendation | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Bail Recommendation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-bail-recommendation` |
| Arrest Bail Recommendation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Bail Recommendation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestBailRecommendationText` |
| Arrest Involved Item Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Involved Item Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-involved-item-reference` |
| Arrest Involved Item Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Involved Item Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestInvolvedItem` |
| Arrest Involved Organization Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Involved Organization Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-involved-organization-reference` |
| Arrest Involved Organization Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Involved Organization Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestInvolvedOrganization` |
| Arrest Involved Weapon Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Involved Weapon Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-involved-weapon-reference` |
| Arrest Involved Weapon Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Involved Weapon Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestInvolvedWeapon` |
| Arrest Probable Cause | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Probable Cause | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-probable-cause` |
| Arrest Probable Cause | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Probable Cause | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestProbableCauseText` |
| Arrest Sequence ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Sequence ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-sequence-id` |
| Arrest Sequence ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Sequence ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestSequenceID` |
| Arrest Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-subject-reference` |
| Arrest Subject Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Subject Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestSubject` |
| Arrest Subject Rights Read Response | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Subject Rights Read Response | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-subject-rights-read-response` |
| Arrest Subject Rights Read Response | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Subject Rights Read Response | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestSubjectRightsReadResponseText` |
| Arrest Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-category-code` |
| Arrest Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ucr/6.0/ArrestCategoryCodeSimpleType` |
| Arrest Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestCategoryCode` |
| Arrest Category Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eq1m9006ypjigy6c8swabzis` |
| Arrest Category JABS Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Category JABS Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-category-jabs-code` |
| Arrest Category JABS Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Category JABS Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ndex/6.0/ArrestCategoryJABSCodeSimpleType` |
| Arrest Category JABS Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestCategoryJABSCode` |
| Arrest Subject Count Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Subject Count Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-subject-count-code` |
| Arrest Subject Count Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Subject Count Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ucr/6.0/MultipleArresteeSegmentsCodeSimpleType` |
| Arrest Subject Count Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestSubjectCountCode` |
| Activity Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/activity-date` |
| Activity Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Activity Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ActivityDate` |
| Activity Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ihqd7ez63f7ty3zlz1288ldr` |
| Arrest Arraignment Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Arrest Arraignment Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-arrest-arraignment-date` |
| Arrest Arraignment Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Arrest Arraignment Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ArrestArraignmentDate` |
| Charge | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge` |
| Charge | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeType` |
| Charge | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-inpgenpg2vb2uuir944ihskn` |
| Charge Accident Related Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Accident Related Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-accident-related-indicator` |
| Charge Accident Related Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Accident Related Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeAccidentRelatedIndicator` |
| Charge Arrest Reason Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Arrest Reason Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-arrest-reason-indicator` |
| Charge Arrest Reason Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Arrest Reason Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeArrestReasonIndicator` |
| Charge Employment Related Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Employment Related Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-employment-related-indicator` |
| Charge Employment Related Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Employment Related Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeEmploymentRelatedIndicator` |
| Charge Felony Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Felony Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-felony-indicator` |
| Charge Felony Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Felony Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeFelonyIndicator` |
| Charge Highest Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Highest Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-highest-indicator` |
| Charge Highest Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Highest Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeHighestIndicator` |
| Charge Serious Violent Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Serious Violent Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-serious-violent-indicator` |
| Charge Serious Violent Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Serious Violent Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeSeriousViolentIndicator` |
| Charge Applicability | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Applicability | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-applicability` |
| Charge Applicability | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Applicability | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeApplicabilityText` |
| Charge Category Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Category Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-category-description` |
| Charge Category Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Category Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeCategoryDescriptionText` |
| Charge Degree | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Degree | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-degree` |
| Charge Degree | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Degree | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeDegreeText` |
| Charge Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-description` |
| Charge Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeDescriptionText` |
| Charge Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eoqim4xj9gsxtxrqko1hh55o` |
| Charge Disposition Other | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Disposition Other | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-disposition-other` |
| Charge Disposition Other | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Disposition Other | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeDispositionOtherText` |
| Charge Filer Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Filer Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-filer-entity-reference` |
| Charge Filer Entity Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Filer Entity Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeFilerEntity` |
| Charge Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-identification` |
| Charge Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeIdentification` |
| Charge Legal Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Legal Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-legal-description` |
| Charge Legal Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Legal Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeLegalDescriptionText` |
| Charge NCIC | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge NCIC | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-ncic` |
| Charge NCIC | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge NCIC | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeNCICText` |
| Charge Originator Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Originator Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-originator-entity-reference` |
| Charge Originator Entity Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Originator Entity Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeOriginatorEntity` |
| Charge Qualifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Qualifier | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-qualifier` |
| Charge Qualifier | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Qualifier | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeQualifierText` |
| Charge Reducing Factor | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Reducing Factor | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-reducing-factor` |
| Charge Reducing Factor | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Reducing Factor | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeReducingFactorText` |
| Charge Sentence Range | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Sentence Range | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-sentence-range` |
| Charge Sentence Range | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Sentence Range | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeSentenceRangeText` |
| Charge Sequence ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Sequence ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-sequence-id` |
| Charge Sequence ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Sequence ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeSequenceID` |
| Charge Severity | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Severity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-severity` |
| Charge Severity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Severity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeSeverityText` |
| Charge Severity | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-9ezz3l6dqg0imkg0y4tjw3pmc` |
| Charge Severity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Severity Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-severity-description` |
| Charge Severity Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Severity Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeSeverityDescriptionText` |
| Charge Special Allegation | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Special Allegation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-special-allegation` |
| Charge Special Allegation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Special Allegation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeSpecialAllegationText` |
| Charge Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-status` |
| Charge Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeStatus` |
| Charge Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-subject-reference` |
| Charge Subject Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Subject Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeSubject` |
| Charge Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-text` |
| Charge Text | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Text | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeText` |
| Charge Tracking Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Tracking Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-tracking-identification` |
| Charge Tracking Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Tracking Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeTrackingIdentification` |
| Charge UCR Crime Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge UCR Crime Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-ucr-crime-category` |
| Charge UCR Crime Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge UCR Crime Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeUCRCrimeCategoryText` |
| Charge Victim Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Victim Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-victim-reference` |
| Charge Victim Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Victim Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeVictim` |
| Charge UCR Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge UCR Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-ucr-code` |
| Charge UCR Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge UCR Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ucr/6.0/OffenseCodeSimpleType` |
| Charge UCR Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeUCRCode` |
| Charge Count Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Count Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-count-quantity` |
| Charge Count Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Count Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeCountQuantity` |
| Charge Recommended Bail Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Recommended Bail Amount | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-recommended-bail-amount` |
| Charge Recommended Bail Amount | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Recommended Bail Amount | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeRecommendedBailAmount` |
| Charge Filing Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Charge Filing Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-charge-filing-date` |
| Charge Filing Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Charge Filing Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ChargeFilingDate` |
| Charge Filing Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l0esdclu01pg7qw429oe7kjk` |
| Disposition | `dcterms:publisher` | `https://axius-sdc.com` |
| Disposition | `dcterms:identifier` | `https://axius-sdc.com/library/niem/disposition` |
| Disposition | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Disposition | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DispositionType` |
| Disposition Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Disposition Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-disposition-category-code` |
| Disposition Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Disposition Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/DispositionCategoryCodeText` |
| Disposition Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Disposition Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/disposition-description` |
| Disposition Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Disposition Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DispositionDescriptionText` |
| Disposition Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Disposition Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/disposition-entity-reference` |
| Disposition Entity Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Disposition Entity Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DispositionEntity` |
| Disposition Reason | `dcterms:publisher` | `https://axius-sdc.com` |
| Disposition Reason | `dcterms:identifier` | `https://axius-sdc.com/library/niem/disposition-reason` |
| Disposition Reason | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Disposition Reason | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DispositionReasonText` |
| Disposition Reported Authority | `dcterms:publisher` | `https://axius-sdc.com` |
| Disposition Reported Authority | `dcterms:identifier` | `https://axius-sdc.com/library/niem/disposition-reported-authority` |
| Disposition Reported Authority | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Disposition Reported Authority | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DispositionReportedAuthorityText` |
| Disposition Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Disposition Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/disposition-text` |
| Disposition Text | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Disposition Text | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DispositionText` |
| Disposition Text | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-cwwu5c2mj7binz64czmdh2hd` |
| Disposition Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Disposition Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/disposition-date` |
| Disposition Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Disposition Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/DispositionDate` |
| Plea | `dcterms:publisher` | `https://axius-sdc.com` |
| Plea | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-plea` |
| Plea | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Plea | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/PleaType` |
| Plea Guilty Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Plea Guilty Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-plea-guilty-indicator` |
| Plea Guilty Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Plea Guilty Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/PleaGuiltyIndicator` |
| Plea Negotiated Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Plea Negotiated Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-plea-negotiated-indicator` |
| Plea Negotiated Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Plea Negotiated Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/PleaNegotiatedIndicator` |
| Plea No Contest Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Plea No Contest Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-plea-no-contest-indicator` |
| Plea No Contest Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Plea No Contest Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/PleaNoContestIndicator` |
| Plea Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Plea Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-plea-description` |
| Plea Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Plea Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/PleaDescriptionText` |
| Plea Recommendation | `dcterms:publisher` | `https://axius-sdc.com` |
| Plea Recommendation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-plea-recommendation` |
| Plea Recommendation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Plea Recommendation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/PleaRecommendationText` |
| Sentence | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence` |
| Sentence | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceType` |
| Sentence Aggravated Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Aggravated Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-aggravated-indicator` |
| Sentence Aggravated Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Aggravated Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceAggravatedIndicator` |
| Sentence Confinement Credit Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Confinement Credit Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-confinement-credit-indicator` |
| Sentence Confinement Credit Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Confinement Credit Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceConfinementCreditIndicator` |
| Sentence Deferred Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Deferred Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-deferred-indicator` |
| Sentence Deferred Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Deferred Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceDeferredIndicator` |
| Sentence Register Sex Offender Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Register Sex Offender Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-register-sex-offender-indicator` |
| Sentence Register Sex Offender Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Register Sex Offender Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceRegisterSexOffenderIndicator` |
| Sentence Suspended Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Suspended Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-suspended-indicator` |
| Sentence Suspended Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Suspended Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceSuspendedIndicator` |
| Sentence Charge Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Charge Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-charge-reference` |
| Sentence Charge Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Charge Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceCharge` |
| Sentence Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-description` |
| Sentence Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceDescriptionText` |
| Sentence Grouping | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Grouping | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-grouping` |
| Sentence Grouping | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Grouping | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceGroupingText` |
| Sentence Imposed | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Imposed | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-imposed` |
| Sentence Imposed | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Imposed | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceImposedText` |
| Sentence Issuer Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Issuer Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-issuer-entity-reference` |
| Sentence Issuer Entity Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Issuer Entity Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceIssuerEntity` |
| Sentence Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-subject-reference` |
| Sentence Subject Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Subject Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceSubject` |
| Sentence Confinement Credit Day Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Confinement Credit Day Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-confinement-credit-day-quantity` |
| Sentence Confinement Credit Day Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Confinement Credit Day Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceConfinementCreditDayQuantity` |
| Sentence Court Fee Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Court Fee Amount | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-court-fee-amount` |
| Sentence Court Fee Amount | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Court Fee Amount | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceCourtFeeAmount` |
| Sentence Fine Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Fine Amount | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-fine-amount` |
| Sentence Fine Amount | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Fine Amount | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceFineAmount` |
| Sentence Expiration Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Sentence Expiration Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-sentence-expiration-date` |
| Sentence Expiration Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Sentence Expiration Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/SentenceExpirationDate` |
| Condition (Requirement) | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition (Requirement) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/condition-niem` |
| Condition (Requirement) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Condition (Requirement) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ConditionType` |
| Condition Mandatory Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Mandatory Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/condition-mandatory-indicator` |
| Condition Mandatory Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Condition Mandatory Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ConditionMandatoryIndicator` |
| Condition Violated Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Violated Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/condition-violated-indicator` |
| Condition Violated Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Condition Violated Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ConditionViolatedIndicator` |
| Condition Group ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Group ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/condition-group-id` |
| Condition Group ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Condition Group ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ConditionGroupID` |
| Condition Violation | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Violation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/condition-violation` |
| Condition Violation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Condition Violation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ConditionViolationText` |
| Condition Set Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Set Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/condition-set-date` |
| Condition Set Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Condition Set Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ConditionSetDate` |
| Condition Violation Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Violation Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/condition-violation-date` |
| Condition Violation Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Condition Violation Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ConditionViolationDate` |
| Term | `dcterms:publisher` | `https://axius-sdc.com` |
| Term | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-term` |
| Term | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Term | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/TermType` |
| Term Life Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Term Life Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-term-life-indicator` |
| Term Life Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Term Life Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/TermLifeIndicator` |
| Term Duration | `dcterms:publisher` | `https://axius-sdc.com` |
| Term Duration | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-term-duration` |
| Term Duration | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Term Duration | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/TermDuration` |
| Term Maximum Duration | `dcterms:publisher` | `https://axius-sdc.com` |
| Term Maximum Duration | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-term-maximum-duration` |
| Term Maximum Duration | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Term Maximum Duration | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/TermMaximumDuration` |
| Term Minimum Duration | `dcterms:publisher` | `https://axius-sdc.com` |
| Term Minimum Duration | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-term-minimum-duration` |
| Term Minimum Duration | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Term Minimum Duration | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/TermMinimumDuration` |
| Statute | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute` |
| Statute | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteType` |
| Statute Offense Enhanceable Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Offense Enhanceable Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-offense-enhanceable-indicator` |
| Statute Offense Enhanceable Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Offense Enhanceable Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteOffenseEnhanceableIndicator` |
| Statute Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-category` |
| Statute Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteCategoryText` |
| Statute Code Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Code Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-code-identification` |
| Statute Code Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Code Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteCodeIdentification` |
| Statute Code Section Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Code Section Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-code-section-identification` |
| Statute Code Section Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Code Section Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteCodeSectionIdentification` |
| Statute Code Section Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-da4mgjvlj8s4zy24un9mq8sr` |
| Statute Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-description` |
| Statute Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteDescriptionText` |
| Statute Jurisdiction Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Jurisdiction Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-jurisdiction-reference` |
| Statute Jurisdiction Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Jurisdiction Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteJurisdiction` |
| Statute Keyword | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Keyword | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-keyword` |
| Statute Keyword | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Keyword | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteKeywordText` |
| Statute Level | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Level | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-level` |
| Statute Level | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Level | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteLevelText` |
| Statute Offense Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Offense Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-offense-identification` |
| Statute Offense Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Offense Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteOffenseIdentification` |
| Statute Offense State Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Offense State Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-offense-state-code` |
| Statute Offense State Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Offense State Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteOffenseStateCodeText` |
| Statute Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-status` |
| Statute Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteStatus` |
| Statute Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-text` |
| Statute Text | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Text | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteText` |
| Statute Enactment Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Enactment Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-enactment-date` |
| Statute Enactment Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Enactment Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteEnactmentDate` |
| Statute Repeal Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Statute Repeal Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-statute-repeal-date` |
| Statute Repeal Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Statute Repeal Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/StatuteRepealDate` |
| Verdict | `dcterms:publisher` | `https://axius-sdc.com` |
| Verdict | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-verdict` |
| Verdict | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Verdict | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/VerdictType` |
| Verdict Issuing Judge Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Verdict Issuing Judge Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-verdict-issuing-judge-indicator` |
| Verdict Issuing Judge Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Verdict Issuing Judge Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/VerdictIssuingJudgeIndicator` |
| Verdict Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Verdict Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-verdict-description` |
| Verdict Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Verdict Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/VerdictDescriptionText` |
| Verdict Disposition Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Verdict Disposition Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-verdict-disposition-name` |
| Verdict Disposition Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Verdict Disposition Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/VerdictDispositionName` |
| Verdict Issuing Court Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Verdict Issuing Court Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-verdict-issuing-court-reference` |
| Verdict Issuing Court Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Verdict Issuing Court Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/VerdictIssuingCourt` |
| Verdict Issuing Judge Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Verdict Issuing Judge Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-verdict-issuing-judge-reference` |
| Verdict Issuing Judge Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Verdict Issuing Judge Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/VerdictIssuingJudge` |
| Verdict Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Verdict Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-verdict-subject-reference` |
| Verdict Subject Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Verdict Subject Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/VerdictSubject` |
| Verdict Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Verdict Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-verdict-date` |
| Verdict Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Verdict Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/VerdictDate` |
| Verdict Disposition Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Verdict Disposition Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-verdict-disposition-date` |
| Verdict Disposition Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Verdict Disposition Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/VerdictDispositionDate` |
| Custody Transfer | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer` |
| Custody Transfer | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferType` |
| Custody Transfer Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer Action | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer-action` |
| Custody Transfer Action | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer Action | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferActionText` |
| Custody Transfer Item Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer Item Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer-item-reference` |
| Custody Transfer Item Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer Item Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferItem` |
| Custody Transfer Receiving Enforcement Agency Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer Receiving Enforcement Agency Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer-receiving-enforcement-agency-reference` |
| Custody Transfer Receiving Enforcement Agency Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer Receiving Enforcement Agency Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferReceivingEnforcementAgency` |
| Custody Transfer Receiving Enforcement Facility Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer Receiving Enforcement Facility Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer-receiving-enforcement-facility-reference` |
| Custody Transfer Receiving Enforcement Facility Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer Receiving Enforcement Facility Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferReceivingEnforcementFacility` |
| Custody Transfer Receiving Enforcement Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer Receiving Enforcement Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer-receiving-enforcement-official-reference` |
| Custody Transfer Receiving Enforcement Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer Receiving Enforcement Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferReceivingEnforcementOfficial` |
| Custody Transfer Releasing Enforcement Agency Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer Releasing Enforcement Agency Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer-releasing-enforcement-agency-reference` |
| Custody Transfer Releasing Enforcement Agency Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer Releasing Enforcement Agency Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferReleasingEnforcementAgency` |
| Custody Transfer Releasing Enforcement Facility Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer Releasing Enforcement Facility Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer-releasing-enforcement-facility-reference` |
| Custody Transfer Releasing Enforcement Facility Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer Releasing Enforcement Facility Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferReleasingEnforcementFacility` |
| Custody Transfer Releasing Enforcement Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer Releasing Enforcement Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer-releasing-enforcement-official-reference` |
| Custody Transfer Releasing Enforcement Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer Releasing Enforcement Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferReleasingEnforcementOfficial` |
| Custody Transfer Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Custody Transfer Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-custody-transfer-subject-reference` |
| Custody Transfer Subject Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Custody Transfer Subject Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CustodyTransferSubject` |
| Enforcement Official | `dcterms:publisher` | `https://axius-sdc.com` |
| Enforcement Official | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-enforcement-official` |
| Enforcement Official | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Enforcement Official | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EnforcementOfficialType` |
| Enforcement Official | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hufmgmyknc7i27m1vaqc8vu2` |
| Employee Rank | `dcterms:publisher` | `https://axius-sdc.com` |
| Employee Rank | `dcterms:identifier` | `https://axius-sdc.com/library/niem/employee-rank` |
| Employee Rank | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Employee Rank | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/EmployeeRankText` |
| Enforcement Official Badge Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Enforcement Official Badge Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-enforcement-official-badge-identification` |
| Enforcement Official Badge Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Enforcement Official Badge Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EnforcementOfficialBadgeIdentification` |
| Enforcement Official Badge Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-io7omc1wuwgqqsuola11r6ju` |
| Enforcement Official Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Enforcement Official Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-enforcement-official-category` |
| Enforcement Official Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Enforcement Official Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EnforcementOfficialCategoryText` |
| Enforcement Official POST License Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Enforcement Official POST License Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-enforcement-official-post-license-identification` |
| Enforcement Official POST License Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Enforcement Official POST License Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EnforcementOfficialPOSTLicenseIdentification` |
| Enforcement Unit Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Enforcement Unit Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-enforcement-unit-identification` |
| Enforcement Unit Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Enforcement Unit Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EnforcementUnitIdentification` |
| Enforcement Unit Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Enforcement Unit Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-enforcement-unit-name` |
| Enforcement Unit Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Enforcement Unit Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EnforcementUnitName` |
| Enforcement Unit Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lh6bbya5nisprb93xaoqxzrf` |
| Enforcement Official Activity Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Enforcement Official Activity Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-enforcement-official-activity-category-code` |
| Enforcement Official Activity Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Enforcement Official Activity Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ucr/6.0/LEOKAActivityCategoryCodeSimpleType` |
| Enforcement Official Activity Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EnforcementOfficialActivityCategoryCode` |
| Enforcement Official Assignment Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Enforcement Official Assignment Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-enforcement-official-assignment-category-code` |
| Enforcement Official Assignment Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Enforcement Official Assignment Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ucr/6.0/LEOKAOfficerAssignmentCategoryCodeSimpleType` |
| Enforcement Official Assignment Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EnforcementOfficialAssignmentCategoryCode` |
| Full Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Full Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/full-name-person` |
| Full Name (Person) | `dcterms:source` | `https://schema.org/` |
| Full Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q1071027` |
| Full Name (Person) | `skos:exactMatch` | `https://schema.org/Person` |
| Full Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gwpvlduwrtpog4kpidaenshn` |
| Given Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Given Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/given-name-person` |
| Given Name (Person) | `dcterms:source` | `https://schema.org/` |
| Given Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q202444` |
| Given Name (Person) | `skos:exactMatch` | `https://schema.org/givenName` |
| Given Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kfyzf8u8gdafcpt5kfh2qg3q` |
| Middle Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Middle Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/middle-name-person` |
| Middle Name (Person) | `dcterms:source` | `https://schema.org/` |
| Middle Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q245025` |
| Middle Name (Person) | `skos:exactMatch` | `https://schema.org/additionalName` |
| Middle Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-oit0ueglhjfcyq80z22kl2z3` |
| Name Prefix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Prefix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-prefix` |
| Name Prefix | `dcterms:source` | `https://schema.org/` |
| Name Prefix | `skos:exactMatch` | `https://schema.org/honorificPrefix` |
| Name Prefix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-u9x2b6frfi0rbydeoncijfp1` |
| Name Suffix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Suffix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-suffix` |
| Name Suffix | `dcterms:source` | `https://schema.org/` |
| Name Suffix | `skos:exactMatch` | `https://schema.org/honorificSuffix` |
| Name Suffix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zldtbpvyouzi7t1dorc07rb3` |
| Surname (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Surname (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/surname-person` |
| Surname (Person) | `dcterms:source` | `https://schema.org/` |
| Surname (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q101352` |
| Surname (Person) | `skos:exactMatch` | `https://schema.org/familyName` |
| Surname (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-v8jgjo2sml12jo7zrb8swoxi` |
| Name Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Name Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-use` |
| Name Use | `skos:exactMatch` | `http://hl7.org/fhir/name-use` |
| Name Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zlg3riiu515tsg0mdkx5brkc` |
| Organization (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization` |
| Organization (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationType` |
| Organization (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vxyrz6k5ufpohy32eo1zdmcc` |
| Organization Active Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Active Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-active-indicator` |
| Organization Active Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Active Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationActiveIndicator` |
| Organization Incorporated Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Incorporated Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-incorporated-indicator` |
| Organization Incorporated Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Incorporated Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationIncorporatedIndicator` |
| Organization Abbreviation | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Abbreviation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-abbreviation` |
| Organization Abbreviation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Abbreviation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationAbbreviationText` |
| Organization Abbreviation | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tloiuyexqfe3bidf7ffzpslz` |
| Organization Branch Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Branch Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-branch-name` |
| Organization Branch Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Branch Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationBranchName` |
| Organization Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-category` |
| Organization Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationCategoryText` |
| Organization Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-description` |
| Organization Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationDescriptionText` |
| Organization Doing Business As Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Doing Business As Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-doing-business-as-name` |
| Organization Doing Business As Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Doing Business As Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationDoingBusinessAsName` |
| Organization Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-identification` |
| Organization Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationIdentification` |
| Organization Jurisdiction Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Jurisdiction Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-jurisdiction-reference` |
| Organization Jurisdiction Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Jurisdiction Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationJurisdiction` |
| Organization LEI Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization LEI Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-lei-identification` |
| Organization LEI Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization LEI Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationLEIIdentification` |
| Organization ORI Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization ORI Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-organization-ori-identification` |
| Organization ORI Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Organization ORI Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/OrganizationORIIdentification` |
| Organization ORI Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-oz5pfkqt10y1acemrmnxfzvw` |
| Organization Parent Organization Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Parent Organization Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-parent-organization-reference` |
| Organization Parent Organization Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Parent Organization Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationParentOrganization` |
| Organization Principal Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Principal Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-principal-official-reference` |
| Organization Principal Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Principal Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationPrincipalOfficial` |
| Organization Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-status` |
| Organization Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationStatus` |
| Organization Sub Unit Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Sub Unit Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-sub-unit-name` |
| Organization Sub Unit Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Sub Unit Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationSubUnitName` |
| Organization Tax Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Tax Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-tax-identification` |
| Organization Tax Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Tax Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationTaxIdentification` |
| Organization Tax Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gu15c6jojx09jy9at1px0ufh` |
| Organization Unit Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Unit Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-unit-name` |
| Organization Unit Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Unit Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationUnitName` |
| Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/organization-name` |
| Organization Name | `dcterms:source` | `https://schema.org/` |
| Organization Name | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C93874` |
| Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Organization Category ND Ex Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Category ND Ex Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-organization-category-nd-ex-code` |
| Organization Category ND Ex Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Organization Category ND Ex Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ndex/6.0/OrganizationCategoryCodeSimpleType` |
| Organization Category ND Ex Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/OrganizationCategoryNDExCode` |
| Organization Established Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Established Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-established-date` |
| Organization Established Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Established Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationEstablishedDate` |
| Organization Incorporation Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Incorporation Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-incorporation-date` |
| Organization Incorporation Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Incorporation Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationIncorporationDate` |
| Organization Termination Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Termination Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-termination-date` |
| Organization Termination Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Termination Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationTerminationDate` |
| Contact Information (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Information (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-information` |
| Contact Information (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Information (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationType` |
| Contact Information (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vy0xsgoam40pob60gu6mbrqo` |
| Contact Entity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Entity Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-entity-description` |
| Contact Entity Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Entity Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactEntityDescriptionText` |
| Contact Information Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Information Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-information-description` |
| Contact Information Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Information Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationDescriptionText` |
| Contact Information Availability Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Information Availability Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-information-availability-code` |
| Contact Information Availability Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Information Availability Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationAvailabilityCode` |
| Contact Information Availability Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationAvailabilityCodeSimpleType` |
| Address (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address` |
| Address (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressType` |
| Address (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tfg5f0628p7bajmz49u8k7cd` |
| Address Building Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Building Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-building-name` |
| Address Building Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Building Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressBuildingName` |
| Address County Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address County Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-county-name` |
| Address County Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address County Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCountyName` |
| Address Delivery Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Delivery Point | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-delivery-point` |
| Address Delivery Point | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Delivery Point | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressDeliveryPointText` |
| Address Full | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Full | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-full` |
| Address Full | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Full | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressFullText` |
| Address Postal Extension Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Postal Extension Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-postal-extension-code` |
| Address Postal Extension Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Postal Extension Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressPostalExtensionCode` |
| Address Private Mailbox | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Private Mailbox | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-private-mailbox` |
| Address Private Mailbox | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Private Mailbox | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressPrivateMailboxText` |
| Address Recipient Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Recipient Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-recipient-name` |
| Address Recipient Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Recipient Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressRecipientName` |
| Address Secondary Unit | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Secondary Unit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-secondary-unit` |
| Address Secondary Unit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Secondary Unit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressSecondaryUnitText` |
| Address Secondary Unit | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rng9tofh09ezkym5u5d8o6kr` |
| Address Urbanization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Urbanization Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-urbanization-name` |
| Address Urbanization Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Urbanization Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressUrbanizationName` |
| Address Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-category-code` |
| Address Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCategoryCode` |
| Address Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCategoryCodeSimpleType` |
| County (fips) | `dcterms:publisher` | `https://axius-sdc.com` |
| County (fips) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| County (fips) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/fips-county` |
| County (fips) | `skos:closeMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| County (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/CountyCode` |
| Code List: fips US County5 Digit | `dcterms:publisher` | `https://axius-sdc.com` |
| Code List: fips US County5 Digit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| Code List: fips US County5 Digit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/system-fips-us-county5-digit` |
| Code List: fips US County5 Digit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/code-display-text` |
| Code Display Text | `dcterms:source` | `https://www.w3.org/TR/skos-reference/` |
| Code Display Text | `skos:exactMatch` | `http://www.w3.org/2004/02/skos/core#prefLabel` |
| County Code (fips) | `dcterms:publisher` | `https://axius-sdc.com` |
| County Code (fips) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| County Code (fips) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/fips-county-code` |
| County Code (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/CountyCode` |
| County Code (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| International Address | `dcterms:publisher` | `https://axius-sdc.com` |
| International Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/international-address` |
| International Address | `dcterms:source` | `https://schema.org/` |
| International Address | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| International Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-g6qfe9l84vekq97kgvhtu3qw` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| Postal Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Postal Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/postal-code` |
| Postal Code | `dcterms:source` | `https://schema.org/` |
| Postal Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| Postal Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kgbwgi00bhxyyt176bsmulf0` |
| Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/region-name` |
| Region Name | `dcterms:source` | `https://schema.org/` |
| Region Name | `skos:exactMatch` | `https://schema.org/addressRegion` |
| Region Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fvgk640ozbukdci5swd6wytt` |
| Address Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Address Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-use` |
| Address Use | `skos:exactMatch` | `http://hl7.org/fhir/address-use` |
| Address Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-offwpyuzrbirkryvvbzqqg31` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Contact Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Point | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-point` |
| Contact Point | `dcterms:source` | `https://schema.org/` |
| Contact Point | `skos:exactMatch` | `https://schema.org/ContactPoint` |
| Contact Point | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pet65c3gbwhp7j2fyiglwv5q` |
| Website URL | `dcterms:publisher` | `https://axius-sdc.com` |
| Website URL | `dcterms:identifier` | `https://axius-sdc.com/library/default/website-url` |
| Website URL | `dcterms:source` | `https://schema.org/` |
| Website URL | `skos:exactMatch` | `https://schema.org/url` |
| Website URL | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t4fl1c1qbhmgyem3fczjdq16` |
| Email Address | `dcterms:publisher` | `https://axius-sdc.com` |
| Email Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/email-address` |
| Email Address | `dcterms:source` | `https://www.rfc-editor.org/rfc/rfc5321` |
| Email Address | `skos:exactMatch` | `https://schema.org/email` |
| Email Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uvl0tla5aocdzsdrby589b6l` |
| Fax Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Fax Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Fax Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/fax-number` |
| Fax Number | `skos:exactMatch` | `https://schema.org/faxNumber` |
| Fax Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hzpld81b2ddnp5qywombgpls` |
| Phone Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Phone Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Phone Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/phone-number` |
| Phone Number | `skos:exactMatch` | `https://schema.org/telephone` |
| Phone Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ma9dwgbrvprfyypwldni2qfx` |
| Contact Method | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Method | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Method | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-method` |
| Contact Method | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-system` |
| Contact Method | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tf5wlywn6meurn6o1sz8yuaq` |
| Contact Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-use` |
| Contact Use | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-use` |
| Contact Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-klgho4tqvbu5iyt6zzx1ioi9` |
| Location (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Location (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location` |
| Location (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationType` |
| Location (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-k2gzmlxjixdm6l1moo5rhwrn` |
| Location Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-category` |
| Location Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationCategoryText` |
| Location Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-description` |
| Location Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationDescriptionText` |
| Location Directions | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Directions | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-directions` |
| Location Directions | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Directions | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationDirectionsText` |
| Location Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-identification` |
| Location Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationIdentification` |
| Location Landmark Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Landmark Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-landmark-name` |
| Location Landmark Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Landmark Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationLandmarkName` |
| Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-name` |
| Location Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationName` |
| Location Range Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Range Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-range-description` |
| Location Range Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Range Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationRangeDescriptionText` |
| Location Surrounding Area Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Surrounding Area Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-surrounding-area-description` |
| Location Surrounding Area Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Surrounding Area Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationSurroundingAreaDescriptionText` |
| Location Altitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Altitude | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-altitude` |
| Location Altitude | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Altitude | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationAltitude` |
| Location Elevation | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Elevation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-elevation` |
| Location Elevation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Elevation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationElevation` |
| Geolocation | `dcterms:publisher` | `https://axius-sdc.com` |
| Geolocation | `dcterms:identifier` | `https://axius-sdc.com/library/default/geolocation` |
| Geolocation | `dcterms:source` | `https://schema.org/` |
| Geolocation | `skos:exactMatch` | `https://schema.org/GeoCoordinates` |
| Geodetic Datum | `dcterms:publisher` | `https://axius-sdc.com` |
| Geodetic Datum | `dcterms:source` | `https://epsg.org/` |
| Geodetic Datum | `dcterms:identifier` | `https://axius-sdc.com/library/default/geodetic-datum` |
| Geodetic Datum | `skos:closeMatch` | `http://www.wikidata.org/entity/Q182643` |
| Altitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Altitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/altitude` |
| Altitude | `dcterms:source` | `http://qudt.org/` |
| Altitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Altitude` |
| Altitude | `skos:exactMatch` | `https://schema.org/elevation` |
| Latitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Latitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/latitude` |
| Latitude | `dcterms:source` | `http://qudt.org/` |
| Latitude | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68642` |
| Latitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Angle` |
| Latitude | `skos:exactMatch` | `https://schema.org/latitude` |
| Latitude | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sws9fskrdla5e99x7cn4trwo` |
| Longitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Longitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/longitude` |
| Longitude | `dcterms:source` | `http://qudt.org/` |
| Longitude | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68643` |
| Longitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Angle` |
| Longitude | `skos:exactMatch` | `https://schema.org/longitude` |
| Longitude | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ecyu6tt7kkjq4rzhthe74ed6` |
| Locale | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale` |
| Locale | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleType` |
| Locale Census Block ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Census Block ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-census-block-id` |
| Locale Census Block ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Census Block ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCensusBlockID` |
| Locale Census Tract ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Census Tract ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-census-tract-id` |
| Locale Census Tract ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Census Tract ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCensusTractID` |
| Locale Community Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Community Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-community-name` |
| Locale Community Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Community Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCommunityName` |
| Locale Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-description` |
| Locale Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleDescriptionText` |
| Locale District Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale District Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-district-name` |
| Locale District Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale District Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleDistrictName` |
| Locale Emergency Services Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Emergency Services Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-emergency-services-jurisdiction-id` |
| Locale Emergency Services Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Emergency Services Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleEmergencyServicesJurisdictionID` |
| Locale Emergency Services Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Emergency Services Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-emergency-services-name` |
| Locale Emergency Services Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Emergency Services Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleEmergencyServicesName` |
| Locale Fire Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Fire Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-fire-jurisdiction-id` |
| Locale Fire Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Fire Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleFireJurisdictionID` |
| Locale Judicial District Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Judicial District Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-judicial-district-name` |
| Locale Judicial District Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Judicial District Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleJudicialDistrictName` |
| Locale Neighborhood Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Neighborhood Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-neighborhood-name` |
| Locale Neighborhood Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Neighborhood Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleNeighborhoodName` |
| Locale Police Beat | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Beat | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-beat` |
| Locale Police Beat | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Beat | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceBeatText` |
| Locale Police Grid | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Grid | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-grid` |
| Locale Police Grid | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Grid | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceGridText` |
| Locale Police Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-jurisdiction-id` |
| Locale Police Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceJurisdictionID` |
| Locale Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-region-name` |
| Locale Region Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Region Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleRegionName` |
| Locale Subdivision Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Subdivision Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-subdivision-name` |
| Locale Subdivision Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Subdivision Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleSubdivisionName` |
| Locale Zone Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Zone Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-zone-name` |
| Locale Zone Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Zone Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleZoneName` |
| Release | `dcterms:publisher` | `https://axius-sdc.com` |
| Release | `dcterms:identifier` | `https://axius-sdc.com/library/niem/release` |
| Release | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Release | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ReleaseType` |
| Release Residence Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Release Residence Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-release-residence-indicator` |
| Release Residence Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Release Residence Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ReleaseResidenceIndicator` |
| Release Date Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Release Date Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-release-date-category` |
| Release Date Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Release Date Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ReleaseDateCategoryText` |
| Release Date Category | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qco2ytk4b4z70euvkjauupnm` |
| Release From Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Release From Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/release-from-location-reference` |
| Release From Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Release From Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ReleaseFromLocation` |
| Release Issuer Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Release Issuer Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/release-issuer-reference` |
| Release Issuer Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Release Issuer Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ReleaseIssuer` |
| Release Person Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Release Person Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/release-person-reference` |
| Release Person Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Release Person Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ReleasePerson` |
| Release Recipient Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Release Recipient Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/release-recipient-reference` |
| Release Recipient Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Release Recipient Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ReleaseRecipient` |
| Release Supervisor Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Release Supervisor Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/release-supervisor-reference` |
| Release Supervisor Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Release Supervisor Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ReleaseSupervisor` |
| Release To Facility Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Release To Facility Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-release-to-facility-reference` |
| Release To Facility Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Release To Facility Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ReleaseToFacility` |
| Release To Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Release To Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/release-to-location-reference` |
| Release To Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Release To Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ReleaseToLocation` |
| Release Funds Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Release Funds Amount | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-release-funds-amount` |
| Release Funds Amount | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Release Funds Amount | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ReleaseFundsAmount` |
| Release Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Release Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/release-date` |
| Release Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Release Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ReleaseDate` |
| Warrant | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-warrant` |
| Warrant | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Warrant | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/WarrantType` |
| Court Order Designated Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Designated Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-designated-subject-reference` |
| Court Order Designated Subject Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Designated Subject Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderDesignatedSubject` |
| Court Order Enforcement Agency Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Enforcement Agency Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-enforcement-agency-reference` |
| Court Order Enforcement Agency Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Enforcement Agency Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderEnforcementAgency` |
| Court Order Issuing Court Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Issuing Court Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-issuing-court-reference` |
| Court Order Issuing Court Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Issuing Court Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderIssuingCourt` |
| Court Order Issuing Judicial Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Issuing Judicial Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-issuing-judicial-official-reference` |
| Court Order Issuing Judicial Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Issuing Judicial Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderIssuingJudicialOfficial` |
| Court Order Jurisdiction Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Jurisdiction Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-jurisdiction-reference` |
| Court Order Jurisdiction Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Jurisdiction Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderJurisdiction` |
| Court Order Recall Reason | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Recall Reason | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-recall-reason` |
| Court Order Recall Reason | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Recall Reason | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderRecallReasonText` |
| Court Order Service Caution | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Caution | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-caution` |
| Court Order Service Caution | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Caution | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceCautionText` |
| Court Order Service Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-description` |
| Court Order Service Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceDescriptionText` |
| Court Order Service Restriction | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Restriction | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-restriction` |
| Court Order Service Restriction | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Restriction | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceRestrictionText` |
| Court Order Special Instruction | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Special Instruction | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-special-instruction` |
| Court Order Special Instruction | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Special Instruction | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderSpecialInstructionText` |
| Court Order Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-status` |
| Court Order Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderStatus` |
| Investigator Narrative | `dcterms:publisher` | `https://axius-sdc.com` |
| Investigator Narrative | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-investigator-narrative` |
| Investigator Narrative | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Investigator Narrative | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/InvestigatorNarrative` |
| Warrant Appearance Bail Forfeit | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant Appearance Bail Forfeit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-warrant-appearance-bail-forfeit` |
| Warrant Appearance Bail Forfeit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Warrant Appearance Bail Forfeit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/WarrantAppearanceBailForfeitText` |
| Warrant Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-warrant-category` |
| Warrant Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Warrant Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/WarrantCategoryText` |
| Warrant Extradition Limitation | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant Extradition Limitation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-warrant-extradition-limitation` |
| Warrant Extradition Limitation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Warrant Extradition Limitation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/WarrantExtraditionLimitationText` |
| Warrant Extradition State Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant Extradition State Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-warrant-extradition-state-name` |
| Warrant Extradition State Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Warrant Extradition State Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/WarrantExtraditionStateName` |
| Warrant Further Processing | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant Further Processing | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-warrant-further-processing` |
| Warrant Further Processing | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Warrant Further Processing | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/WarrantFurtherProcessingText` |
| Warrant Level | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant Level | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-warrant-level` |
| Warrant Level | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Warrant Level | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/WarrantLevelText` |
| Warrant Probable Cause | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant Probable Cause | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-warrant-probable-cause` |
| Warrant Probable Cause | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Warrant Probable Cause | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/WarrantProbableCauseText` |
| Warrant Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-warrant-category-code` |
| Warrant Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Warrant Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ndex/6.0/WarrantCategoryCodeSimpleType` |
| Warrant Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/WarrantCategoryCode` |
| Warrant Extradition Limitation Code (ncic) | `dcterms:publisher` | `https://axius-sdc.com` |
| Warrant Extradition Limitation Code (ncic) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/ncic-warrant-extradition-limitation-code-(ncic)` |
| Warrant Extradition Limitation Code (ncic) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/ncic.xsd` |
| Warrant Extradition Limitation Code (ncic) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ncic/6.0/EXLCodeSimpleType` |
| Warrant Extradition Limitation Code (ncic) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ncic/6.0/WarrantExtraditionLimitationCode` |
| Court Order Issuing Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Issuing Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-issuing-date` |
| Court Order Issuing Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Issuing Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderIssuingDate` |
| Court Order Recall Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Recall Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-recall-date` |
| Court Order Recall Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Recall Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderRecallDate` |
| Court Order Service Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-date` |
| Court Order Service Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceDate` |
| Evidence | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence` |
| Evidence | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceType` |
| Evidence Returned Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Returned Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-returned-indicator` |
| Evidence Returned Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Returned Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceReturnedIndicator` |
| Evidence Collector Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Collector Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-collector-reference` |
| Evidence Collector Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Collector Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceCollector` |
| Evidence Item Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Item Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-item-text` |
| Evidence Item Text | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Item Text | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceItemText` |
| Evidence Item Text | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-wrswfr4j0tkggfc81m82yqkx` |
| Evidence Number Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Number Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-number-identification` |
| Evidence Number Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Number Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceNumberIdentification` |
| Evidence Other Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Other Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-other-identification` |
| Evidence Other Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Other Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceOtherIdentification` |
| Evidence Previous Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Previous Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-previous-location-reference` |
| Evidence Previous Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Previous Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidencePreviousLocation` |
| Evidence Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-quantity` |
| Evidence Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceQuantityText` |
| Evidence Receipt Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Receipt Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-receipt-identification` |
| Evidence Receipt Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Receipt Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceReceiptIdentification` |
| Evidence Return Recipient Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Return Recipient Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-return-recipient-entity-reference` |
| Evidence Return Recipient Entity Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Return Recipient Entity Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceReturnRecipientEntity` |
| Evidence Taken From Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Taken From Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-taken-from-entity-reference` |
| Evidence Taken From Entity Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Taken From Entity Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceTakenFromEntity` |
| Evidence Taken Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Taken Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-taken-location-reference` |
| Evidence Taken Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Taken Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceTakenLocation` |
| IBIS Number | `dcterms:publisher` | `https://axius-sdc.com` |
| IBIS Number | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-ibis-number` |
| IBIS Number | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| IBIS Number | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/IBISNumberText` |
| Evidence Documentation Binary | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Documentation Binary | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-documentation-binary` |
| Evidence Documentation Binary | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Documentation Binary | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceDocumentationBinary` |
| Evidence Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Evidence Amount | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-evidence-amount` |
| Evidence Amount | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Evidence Amount | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/EvidenceAmount` |
| Item | `dcterms:publisher` | `https://axius-sdc.com` |
| Item | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item` |
| Item | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemType` |
| Item Lease Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Lease Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-lease-indicator` |
| Item Lease Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Lease Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemLeaseIndicator` |
| Item Rental Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Rental Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-rental-indicator` |
| Item Rental Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Rental Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemRentalIndicator` |
| Conveyance Color Primary | `dcterms:publisher` | `https://axius-sdc.com` |
| Conveyance Color Primary | `dcterms:identifier` | `https://axius-sdc.com/library/niem/conveyance-color-primary` |
| Conveyance Color Primary | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Conveyance Color Primary | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ConveyanceColorPrimaryText` |
| Item Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Action | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-action` |
| Item Action | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Action | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemActionText` |
| Item Brand Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Brand Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-brand-name` |
| Item Brand Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Brand Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemBrandName` |
| Item Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-category-text` |
| Item Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemCategoryText` |
| Item Category | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hvi1gkyp907c575c2rxzetxp` |
| Item Color Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Color Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-color-description` |
| Item Color Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Color Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemColorDescriptionText` |
| Item Condition | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Condition | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-condition` |
| Item Condition | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Condition | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemConditionText` |
| Item Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-description` |
| Item Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemDescriptionText` |
| Item Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qnfg77xtg0phszn46wi3v1lb` |
| Item Make Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Make Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-make-name` |
| Item Make Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Make Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemMakeName` |
| Item Model Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Model Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-model-name` |
| Item Model Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Model Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemModelName` |
| Item Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-name` |
| Item Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemName` |
| Item Owner Applied ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Owner Applied ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-owner-applied-id` |
| Item Owner Applied ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Owner Applied ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemOwnerAppliedID` |
| Item Owner Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Owner Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-owner-reference` |
| Item Owner Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Owner Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemOwner` |
| Item Serial Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Serial Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-serial-identification` |
| Item Serial Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Serial Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemSerialIdentification` |
| Item Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-status` |
| Item Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemStatus` |
| Item Usage | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Usage | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-usage` |
| Item Usage | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Usage | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemUsageText` |
| Item Visible ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Visible ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-visible-id` |
| Item Visible ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Visible ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemVisibleID` |
| Item Image | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Image | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-image` |
| Item Image | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Image | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemImage` |
| Item Height | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Height | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-height` |
| Item Height | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Height | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemHeightMeasure` |
| Item Length | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Length | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-length` |
| Item Length | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Length | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemLengthMeasure` |
| Item Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-quantity` |
| Item Quantity | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Quantity | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemQuantity` |
| Item Value Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Value Amount | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-value-amount` |
| Item Value Amount | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Value Amount | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemValueAmount` |
| Item Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Weight | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-weight` |
| Item Weight | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Weight | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemWeightMeasure` |
| Item Width | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Width | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-width` |
| Item Width | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Width | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemWidthMeasure` |
| Item Model Year Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Item Model Year Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/item-model-year-date` |
| Item Model Year Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Item Model Year Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ItemModelYearDate` |
| Service Call | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call` |
| Service Call | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallType` |
| Service Call Assigned Unit Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Assigned Unit Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-assigned-unit-reference` |
| Service Call Assigned Unit Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Assigned Unit Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallAssignedUnit` |
| Service Call Assisting Unit Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Assisting Unit Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-assisting-unit-reference` |
| Service Call Assisting Unit Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Assisting Unit Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallAssistingUnit` |
| Service Call Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-category` |
| Service Call Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallCategoryText` |
| Service Call Clearance | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Clearance | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-clearance` |
| Service Call Clearance | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Clearance | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallClearanceText` |
| Service Call Dispatched Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Dispatched Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-dispatched-official-reference` |
| Service Call Dispatched Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Dispatched Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallDispatchedOfficial` |
| Service Call Dispatcher Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Dispatcher Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-dispatcher-reference` |
| Service Call Dispatcher Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Dispatcher Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallDispatcher` |
| Service Call Mechanism | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Mechanism | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-mechanism` |
| Service Call Mechanism | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Mechanism | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallMechanismText` |
| Service Call Operator Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Operator Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-operator-reference` |
| Service Call Operator Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Operator Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallOperator` |
| Service Call Originator Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Originator Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-originator-reference` |
| Service Call Originator Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Originator Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallOriginator` |
| Service Call Placed Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Placed Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-placed-location-reference` |
| Service Call Placed Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Placed Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallPlacedLocation` |
| Service Call Response Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Response Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-response-location-reference` |
| Service Call Response Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Response Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallResponseLocation` |
| Service Call Response Person Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Response Person Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-response-person-reference` |
| Service Call Response Person Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Response Person Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallResponsePerson` |
| Service Call Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-category-code` |
| Service Call Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ndex/6.0/CADCallCodeSimpleType` |
| Service Call Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallCategoryCode` |
| Service Call Clearance Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Clearance Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-clearance-category-code` |
| Service Call Clearance Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Clearance Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ndex/6.0/CADCallCodeSimpleType` |
| Service Call Clearance Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallClearanceCategoryCode` |
| Service Call Mechanism Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Mechanism Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-mechanism-code` |
| Service Call Mechanism Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Mechanism Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ndex/6.0/CADCallSourceCodeSimpleType` |
| Service Call Mechanism Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallMechanismCode` |
| Service Call Arrived Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Arrived Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-arrived-date` |
| Service Call Arrived Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Arrived Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallArrivedDate` |
| Service Call Cleared Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Cleared Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-cleared-date` |
| Service Call Cleared Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Cleared Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallClearedDate` |
| Service Call Dispatched Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Service Call Dispatched Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-service-call-dispatched-date` |
| Service Call Dispatched Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Service Call Dispatched Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/ServiceCallDispatchedDate` |
| Quarantine Enforcement | `dcterms:publisher` | `https://axius-sdc.com` |
| Quarantine Enforcement | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Quarantine Enforcement | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/quarantine-enforcement` |
| Quarantine Enforcement | `skos:closeMatch` | `https://schema.org/ItemList` |
| Quarantine Enforcement | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-avmmc3r38dol0ghko42yeyp4` |
| Issuing Authority | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q136462915` |
| Issuing Authority | `skos:broadMatch` | `https://schema.org/name` |
| Quarantine Zone | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q356936` |
| Quarantine Zone | `skos:broadMatch` | `https://schema.org/description` |
| Compliance Status | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q752476` |
| Compliance Status | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Compliance Status | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Quarantine End Date | `rdfs:isDefinedBy` | `http://schema.org/endDate` |
| Quarantine End Date | `skos:broadMatch` | `https://schema.org/Date` |
| Quarantine Start Date | `skos:broadMatch` | `https://schema.org/Date` |
| Quarantine Start Date | `rdfs:isDefinedBy` | `http://schema.org/startDate` |
| Court Order | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order` |
| Court Order | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderType` |
| Court Order For Escape Subject Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order For Escape Subject Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-for-escape-subject-indicator` |
| Court Order For Escape Subject Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order For Escape Subject Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderForEscapeSubjectIndicator` |
| Court Order From Other Agency Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order From Other Agency Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-from-other-agency-indicator` |
| Court Order From Other Agency Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order From Other Agency Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderFromOtherAgencyIndicator` |
| Court Order Out Of State Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Out Of State Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-out-of-state-indicator` |
| Court Order Out Of State Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Out Of State Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderOutOfStateIndicator` |
| Court Order Reviewed Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Reviewed Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-reviewed-indicator` |
| Court Order Reviewed Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Reviewed Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderReviewedIndicator` |
| Activity Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/activity-identification` |
| Activity Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Activity Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ActivityIdentification` |
| Court Order Designated Item Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Designated Item Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-designated-item-reference` |
| Court Order Designated Item Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Designated Item Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderDesignatedItem` |
| Court Order Designated Location Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Designated Location Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-designated-location-reference` |
| Court Order Designated Location Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Designated Location Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderDesignatedLocation` |
| Court Order Designated Organization Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Designated Organization Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-designated-organization-reference` |
| Court Order Designated Organization Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Designated Organization Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderDesignatedOrganization` |
| Court Order Designated Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Designated Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-designated-subject-reference` |
| Court Order Designated Subject Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Designated Subject Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderDesignatedSubject` |
| Court Order Enforcement Agency Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Enforcement Agency Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-enforcement-agency-reference` |
| Court Order Enforcement Agency Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Enforcement Agency Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderEnforcementAgency` |
| Court Order Issuing Court Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Issuing Court Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-issuing-court-reference` |
| Court Order Issuing Court Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Issuing Court Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderIssuingCourt` |
| Court Order Issuing Judicial Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Issuing Judicial Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-issuing-judicial-official-reference` |
| Court Order Issuing Judicial Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Issuing Judicial Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderIssuingJudicialOfficial` |
| Court Order Jurisdiction Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Jurisdiction Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-jurisdiction-reference` |
| Court Order Jurisdiction Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Jurisdiction Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderJurisdiction` |
| Court Order Recall Reason | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Recall Reason | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-recall-reason` |
| Court Order Recall Reason | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Recall Reason | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderRecallReasonText` |
| Court Order Receiver Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Receiver Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-receiver-reference` |
| Court Order Receiver Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Receiver Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderReceiver` |
| Court Order Request Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Request Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-request-entity-reference` |
| Court Order Request Entity Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Request Entity Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderRequestEntity` |
| Court Order Request Reason | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Request Reason | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-request-reason` |
| Court Order Request Reason | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Request Reason | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderRequestReasonText` |
| Court Order Service Caution | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Caution | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-caution` |
| Court Order Service Caution | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Caution | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceCautionText` |
| Court Order Service Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-description` |
| Court Order Service Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceDescriptionText` |
| Court Order Service Restriction | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Restriction | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-restriction` |
| Court Order Service Restriction | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Restriction | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceRestrictionText` |
| Court Order Signature Method | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Signature Method | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-signature-method` |
| Court Order Signature Method | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Signature Method | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderSignatureMethodText` |
| Court Order Special Instruction | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Special Instruction | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-special-instruction` |
| Court Order Special Instruction | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Special Instruction | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderSpecialInstructionText` |
| Court Order Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-status` |
| Court Order Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderStatus` |
| Court Order Supervising Agency Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Supervising Agency Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-supervising-agency-reference` |
| Court Order Supervising Agency Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Supervising Agency Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderSupervisingAgency` |
| Activity Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/activity-date` |
| Activity Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Activity Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ActivityDate` |
| Activity Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ihqd7ez63f7ty3zlz1288ldr` |
| Court Order Issuing Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Issuing Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-issuing-date` |
| Court Order Issuing Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Issuing Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderIssuingDate` |
| Court Order Recall Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Recall Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-recall-date` |
| Court Order Recall Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Recall Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderRecallDate` |
| Court Order Request Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Request Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-request-date` |
| Court Order Request Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Request Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderRequestDate` |
| Court Order Service Attempted Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Attempted Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-attempted-date` |
| Court Order Service Attempted Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Attempted Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceAttemptedDate` |
| Court Order Service Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-date` |
| Court Order Service Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceDate` |
| Court Order Service Received Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Court Order Service Received Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-court-order-service-received-date` |
| Court Order Service Received Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Court Order Service Received Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/CourtOrderServiceReceivedDate` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "Law Enforcement Record 4.4.0" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-zdhuex1xwf8s5niriw878e0o.xsd)
- Example instance (dm-zdhuex1xwf8s5niriw878e0o.xml)
- HTML documentation (dm-zdhuex1xwf8s5niriw878e0o.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"Law Enforcement Record 4.4.0" SDC4 schema (dm-zdhuex1xwf8s5niriw878e0o.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"Law Enforcement Record 4.4.0" schema (dm-zdhuex1xwf8s5niriw878e0o.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "Law Enforcement Record 4.4.0" SDC4 schema (dm-zdhuex1xwf8s5niriw878e0o.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "Law Enforcement Record 4.4.0" data model (dm-zdhuex1xwf8s5niriw878e0o.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-zdhuex1xwf8s5niriw878e0o.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-zdhuex1xwf8s5niriw878e0o.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-zdhuex1xwf8s5niriw878e0o.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-zdhuex1xwf8s5niriw878e0o.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-zdhuex1xwf8s5niriw878e0o.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
