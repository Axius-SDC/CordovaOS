# Business Registry 4.4.0

**Model ID**: `dm-nb7gtyimcusmritzx0o0x40o`
**Project**: Cordova
**Description**: Maintain the authoritative registry of business entities in Cordova.

### Dublin Core Metadata
- **Subject**: Business Registry
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal
- **Publisher**: Axius SDC, Inc.

## Package Contents

- `dm-nb7gtyimcusmritzx0o0x40o.xsd` -- XML Schema Definition (data model structure)
- `dm-nb7gtyimcusmritzx0o0x40o.xml` -- XML instance example with sample data
- `dm-nb7gtyimcusmritzx0o0x40o-instance.json` -- JSON instance example (same structure as XML)
- `dm-nb7gtyimcusmritzx0o0x40o.jsonld` -- JSON-LD semantic schema description
- `dm-nb7gtyimcusmritzx0o0x40o.html` -- Human-readable model documentation
- `dm-nb7gtyimcusmritzx0o0x40o_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-nb7gtyimcusmritzx0o0x40o.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-nb7gtyimcusmritzx0o0x40o.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-nb7gtyimcusmritzx0o0x40o.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-nb7gtyimcusmritzx0o0x40o.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **Business Registry Governed Record** | Cluster | `r5q8ldlvkwmdcxigeozlm6r0` | 1 components; 4 sub-cluster(s) |
|   Digital Signature Proof | XdFile | `gug5dhtqfv7exbgmm2raxpkq` | -- |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **Business Registry Office** | Cluster | `ea49fqkwerzzxoo4yvx4p0i6` | 1 components; 1 sub-cluster(s) |
|     Business Registry Number | XdString | `l8f0m7op4xhrxqy1jrnvbuly` | exactLen=10; pattern=`BIZ-[0-9]{6}` |
|     **Organization (NIEM)** | Cluster | `bv2nl062e7l4wgumkv2ng2em` | 22 components; 2 sub-cluster(s) |
|       Organization Active Indicator | XdBoolean | `e5t0xgdy46hfguuwycvwc6dd` | -- |
|       Organization Incorporated Indicator | XdBoolean | `ncop04mgrb74q0oh7g0q6t48` | -- |
|       Organization Abbreviation | XdString | `t70xkidrjlfp0vqdtvlqsbtl` | maxLen=4000 |
|       Organization Branch Name | XdString | `w48pqrn60rdk8g8mj2uoyk2c` | maxLen=255 |
|       Organization Category | XdString | `vbukxb85z1kxdbsng4oni88d` | maxLen=4000 |
|       Organization Description | XdString | `se9bkamsp62q9j5xsjyce9pw` | maxLen=4000 |
|       Organization Doing Business As Name | XdString | `h39s8p16hzlwqlgtlwugchgt` | maxLen=255 |
|       Organization Identification | XdString | `gs7w0xkgwczep8oa2qzcn8rg` | maxLen=64 |
|       Organization Jurisdiction Reference | XdString | `ngkknoglkay9pz4tajcr1kkn` | maxLen=2000; pattern=`\S+` |
|       Organization LEI Identification | XdString | `ts9y9tay6win35ackli12kz6` | maxLen=64 |
|       Organization ORI Identification | XdString | `y4xmf28q5mhb60noq2tt2wif` | maxLen=64 |
|       Organization Parent Organization Reference | XdString | `ayhhnde5u8fw23pr2hq7frzg` | maxLen=2000; pattern=`\S+` |
|       Organization Principal Official Reference | XdString | `hy4elrb7s7djv09luhqytvn1` | maxLen=2000; pattern=`\S+` |
|       Organization Status | XdString | `zmz00hasm7857nienhjc90sg` | maxLen=255 |
|       Organization Sub Unit Name | XdString | `g05gyxydr8ybzxlrk9ly74rr` | maxLen=255 |
|       Organization Tax Identification | XdString | `artqk9ji97lmqvkzmro5tn6g` | maxLen=64 |
|       Organization Unit Name | XdString | `xeqdfbd43aks5bd0ixo09tot` | maxLen=255 |
|       Organization Name | XdString | `xcn8r67fg7soty17homzok44` | minLen=1; maxLen=200 |
|       Organization Category ND Ex Code | XdToken | `wj2nhg5v1hl2d3wa7uo3myz8` | 23 enum(s) |
|       Organization Established Date | XdTemporal | `tvlwdetrfqnlm27nu7x95j39` | -- |
|       Organization Incorporation Date | XdTemporal | `b2iocf5x4d9635bdz9p096md` | -- |
|       Organization Termination Date | XdTemporal | `joxtepir8lkpxw71l64nk03o` | -- |
|       **Contact Information (NIEM)** | Cluster | `v40dwrznm5fwko7b4n6ryrzi` | 3 components; 2 sub-cluster(s) |
|         Contact Entity Description | XdString | `b3yv6tmx5q9tq61zrrbrl8v3` | maxLen=4000 |
|         Contact Information Description | XdString | `m6hyj5gbbwiaepgiioklhtg3` | maxLen=4000 |
|         Contact Information Availability Code | XdToken | `wyevwvpluw19t8wge0psgpjs` | 6 enum(s) |
|         **Address (NIEM)** | Cluster | `doa46sdyoadezgc0tpj379th` | 10 components; 2 sub-cluster(s) |
|           Address Building Name | XdString | `bgn0jx6ubvcjtwa17hxvini2` | maxLen=255 |
|           Address County Name | XdString | `vkbg8z0vmi1a4u99xp1mbsal` | maxLen=255 |
|           Address Delivery Point | XdString | `ep615o1qzzlhz9f2g2quf6sp` | maxLen=4000 |
|           Address Full | XdString | `dwy0u03b1iidzxi4ega2iy5r` | maxLen=4000 |
|           Address Postal Extension Code | XdString | `lckcihuej9hiyqfjhekk6nid` | maxLen=255 |
|           Address Private Mailbox | XdString | `jx13ihzux8cd382oenzlkn05` | maxLen=4000 |
|           Address Recipient Name | XdString | `qcngrwgzzjxvcbxbm9oxonei` | maxLen=255 |
|           Address Secondary Unit | XdString | `fvznldoks6w41g7a4pwvd2ub` | maxLen=4000 |
|           Address Urbanization Name | XdString | `fzjp1m1u66usm20aamjygmun` | maxLen=255 |
|           Address Category Code | XdToken | `k0ixe4ybmx5vp11f7de4k204` | 5 enum(s) |
|           **County (fips)** | Cluster | `bahj0gy7mbmyobqhfy70x190` | 3 components |
|             Code List: fips US County5 Digit | XdLink | `s5u98t1ah8l5069q0x704tdt` | -- |
|             Code Display Text | XdString | `kr8fmao4yji8vr46kiw150me` | maxLen=500 |
|             County Code (fips) | XdString | `dy9dwf3fhe3y6hyf1ka5fbfz` | maxLen=5; pattern=`[0-9]{5,5}` |
|           **International Address** | Cluster | `upawqojmcfg3qsf4ffzi47ho` | 7 components |
|             Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|             Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|             City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|             Postal Code | XdString | `gf841eedvv6cjiegs934srai` | maxLen=15 |
|             Region Name | XdString | `jw1b9q6ulyte599sdsqp2mvp` | maxLen=100 |
|             Address Use | XdToken | `b25dj42zxhm19pih328ga8pl` | 5 enum(s) |
|             Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|         **Contact Point** | Cluster | `d2xwhnb2vqzxw70jcizj9csx` | 6 components |
|           Website URL | XdLink | `wriny2gz8aqcvffmfpwbompk` | -- |
|           Email Address | XdString | `q922mqaon3yn5zlwf2bszf28` | maxLen=254; pattern=`.+@.+\..+` |
|           Fax Number | XdString | `ll6ltsnvakomixuitxkbkxfz` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|           Phone Number | XdString | `zpfwg52r88j6jdypj7rg71ke` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|           Contact Method | XdToken | `miqo30r5b554nyj7ubryw43x` | 7 enum(s) |
|           Contact Use | XdToken | `vmruk4j9y1orvvz8cwafrax5` | 5 enum(s) |
|       **Location (NIEM)** | Cluster | `o01gifxohfe46jfdyh62noig` | 10 components; 3 sub-cluster(s) |
|         Location Category | XdString | `fenldej2l73b84w956gawyqd` | maxLen=4000 |
|         Location Description | XdString | `zlqtx5yr8wdxavl2hc4y9uq4` | maxLen=4000 |
|         Location Directions | XdString | `fwusqzhkfgeh7gwrsgihp0rx` | maxLen=4000 |
|         Location Identification | XdString | `c9n7299dj2fdzlmqe8ixvb2z` | maxLen=64 |
|         Location Landmark Name | XdString | `vw3tuujru1u95k6kavnc946v` | maxLen=255 |
|         Location Name | XdString | `ouramzsx8f7nis27vjj265l9` | maxLen=255 |
|         Location Range Description | XdString | `ces753kz92cp4zdyva7qw530` | maxLen=4000 |
|         Location Surrounding Area Description | XdString | `enu405jym8hdu571utuznru3` | maxLen=4000 |
|         Location Altitude | XdQuantity | `qjl8rgtsnazid1rvxqof65yy` | units=Length Units (SI and customary) |
|         Location Elevation | XdQuantity | `n3luxpr7zt9z2ylpmp2wioy4` | units=Length Units (SI and customary) |
|         **Geolocation** | Cluster | `jwfl94g8mj8aevupivyfsnwj` | 4 components |
|           Geodetic Datum | XdToken | `i3qpmie9hle8ma5kt6ogxqnp` | 3 enum(s) |
|           Altitude | XdQuantity | `scdlxu6vex8iwbfc8sijmjff` | units=Length/Distance (SI - Metric) |
|           Latitude | XdQuantity | `c5e0wv21cmlouukx6ga2o5uz` | units=Degrees (Angle) |
|           Longitude | XdQuantity | `qh625ukiiju3ak4x45tehcnr` | units=Degrees (Angle) |
|         **Locale** | Cluster | `ru0fwf4ubdvcizzaau0mpftg` | 16 components |
|           Locale Census Block ID | XdString | `ji7mja9le7x3k2fnstyflgd9` | maxLen=255 |
|           Locale Census Tract ID | XdString | `b1qnngc94yrhnzw0a0qylc8m` | maxLen=255 |
|           Locale Community Name | XdString | `d62un867sx8pfuoiw9vmyvhc` | maxLen=255 |
|           Locale Description | XdString | `qhmp2uf6xmb86vdwzt9pz0z4` | maxLen=4000 |
|           Locale District Name | XdString | `xrx13kgg5bxgodid3gojzc4u` | maxLen=255 |
|           Locale Emergency Services Jurisdiction ID | XdString | `nmhyp4tz6uzhm9rcbxksrkad` | maxLen=255 |
|           Locale Emergency Services Name | XdString | `zza5jn63yvlxhjgkajypacqi` | maxLen=255 |
|           Locale Fire Jurisdiction ID | XdString | `nvonmskk57e6buoa4bjo4yq5` | maxLen=255 |
|           Locale Judicial District Name | XdString | `ep6d634smvqdn890vnjs8umh` | maxLen=255 |
|           Locale Neighborhood Name | XdString | `hs4ke1zgmxvea6nd41ivepg5` | maxLen=255 |
|           Locale Police Beat | XdString | `dt27rd2aw6bfydiru5ti7gyh` | maxLen=4000 |
|           Locale Police Grid | XdString | `rdk1jsosk7dgsbn7hkq3k10i` | maxLen=4000 |
|           Locale Police Jurisdiction ID | XdString | `end6e085n8tw4850taf7jjl2` | maxLen=255 |
|           Locale Region Name | XdString | `xswwghxc0mdmucw58sa5axse` | maxLen=255 |
|           Locale Subdivision Name | XdString | `f0j0mvmsjdjfccynvpynntd8` | maxLen=255 |
|           Locale Zone Name | XdString | `fypmwmyh1gcv597iesiyxdzd` | maxLen=255 |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: Business Registry 4.4.0
  [Cluster] Business Registry Governed Record
    [XdFile] Digital Signature Proof
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] Business Registry Office
      [XdString] Business Registry Number
      [Cluster] Organization (NIEM)
        [XdBoolean] Organization Active Indicator
        [XdBoolean] Organization Incorporated Indicator
        [XdString] Organization Abbreviation
        [XdString] Organization Branch Name
        [XdString] Organization Category
        [XdString] Organization Description
        [XdString] Organization Doing Business As Name
        [XdString] Organization Identification
        [XdString] Organization Jurisdiction Reference
        [XdString] Organization LEI Identification
        [XdString] Organization ORI Identification
        [XdString] Organization Parent Organization Reference
        [XdString] Organization Principal Official Reference
        [XdString] Organization Status
        [XdString] Organization Sub Unit Name
        [XdString] Organization Tax Identification
        [XdString] Organization Unit Name
        [XdString] Organization Name
        [XdToken] Organization Category ND Ex Code
        [XdTemporal] Organization Established Date
        [XdTemporal] Organization Incorporation Date
        [XdTemporal] Organization Termination Date
        [Cluster] Contact Information (NIEM)
          [XdString] Contact Entity Description
          [XdString] Contact Information Description
          [XdToken] Contact Information Availability Code
          [Cluster] Address (NIEM)
            [XdString] Address Building Name
            [XdString] Address County Name
            [XdString] Address Delivery Point
            [XdString] Address Full
            [XdString] Address Postal Extension Code
            [XdString] Address Private Mailbox
            [XdString] Address Recipient Name
            [XdString] Address Secondary Unit
            [XdString] Address Urbanization Name
            [XdToken] Address Category Code
            [Cluster] County (fips)
              [XdLink] Code List: fips US County5 Digit
              [XdString] Code Display Text
              [XdString] County Code (fips)
            [Cluster] International Address
              [XdString] Address (Line 1)
              [XdString] Address (Line 2)
              [XdString] City Name
              [XdString] Postal Code
              [XdString] Region Name
              [XdToken] Address Use
              [XdToken] Country Code ISO 3166
          [Cluster] Contact Point
            [XdLink] Website URL
            [XdString] Email Address
            [XdString] Fax Number
            [XdString] Phone Number
            [XdToken] Contact Method
            [XdToken] Contact Use
        [Cluster] Location (NIEM)
          [XdString] Location Category
          [XdString] Location Description
          [XdString] Location Directions
          [XdString] Location Identification
          [XdString] Location Landmark Name
          [XdString] Location Name
          [XdString] Location Range Description
          [XdString] Location Surrounding Area Description
          [XdQuantity] Location Altitude
          [XdQuantity] Location Elevation
          [Cluster] Address (NIEM) (circular ref)
          [Cluster] Geolocation
            [XdToken] Geodetic Datum
            [XdQuantity] Altitude
            [XdQuantity] Latitude
            [XdQuantity] Longitude
          [Cluster] Locale
            [XdString] Locale Census Block ID
            [XdString] Locale Census Tract ID
            [XdString] Locale Community Name
            [XdString] Locale Description
            [XdString] Locale District Name
            [XdString] Locale Emergency Services Jurisdiction ID
            [XdString] Locale Emergency Services Name
            [XdString] Locale Fire Jurisdiction ID
            [XdString] Locale Judicial District Name
            [XdString] Locale Neighborhood Name
            [XdString] Locale Police Beat
            [XdString] Locale Police Grid
            [XdString] Locale Police Jurisdiction ID
            [XdString] Locale Region Name
            [XdString] Locale Subdivision Name
            [XdString] Locale Zone Name
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Business Registry Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Business Registry Governed Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Business Registry Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/business-registry-governed-record` |
| Business Registry Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Business Registry Governed Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-og2caskrf2nq0sszcztp3avx` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.w3.org/TR/vc-data-model/#credentials` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q210824` |
| Digital Signature Proof | `skos:broadMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| Business Registry Office | `dcterms:publisher` | `https://axius-sdc.com` |
| Business Registry Office | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Business Registry Office | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/business-registry-office` |
| Business Registry Office | `skos:exactMatch` | `https://schema.org/Organization` |
| Business Registry Office | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l69byv9b04bedudm59pfclvw` |
| Business Registry Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q12047291` |
| Business Registry Number | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| Business Registry Number | `skos:broadMatch` | `https://schema.org/identifier` |
| Organization (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization` |
| Organization (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationType` |
| Organization (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vxyrz6k5ufpohy32eo1zdmcc` |
| Organization Active Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Active Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-active-indicator` |
| Organization Active Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Active Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationActiveIndicator` |
| Organization Incorporated Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Incorporated Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-incorporated-indicator` |
| Organization Incorporated Indicator | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Incorporated Indicator | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationIncorporatedIndicator` |
| Organization Abbreviation | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Abbreviation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-abbreviation` |
| Organization Abbreviation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Abbreviation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationAbbreviationText` |
| Organization Abbreviation | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tloiuyexqfe3bidf7ffzpslz` |
| Organization Branch Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Branch Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-branch-name` |
| Organization Branch Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Branch Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationBranchName` |
| Organization Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-category` |
| Organization Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationCategoryText` |
| Organization Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-description` |
| Organization Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationDescriptionText` |
| Organization Doing Business As Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Doing Business As Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-doing-business-as-name` |
| Organization Doing Business As Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Doing Business As Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationDoingBusinessAsName` |
| Organization Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-identification` |
| Organization Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationIdentification` |
| Organization Jurisdiction Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Jurisdiction Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-jurisdiction-reference` |
| Organization Jurisdiction Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Jurisdiction Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationJurisdiction` |
| Organization LEI Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization LEI Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-lei-identification` |
| Organization LEI Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization LEI Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationLEIIdentification` |
| Organization ORI Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization ORI Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-organization-ori-identification` |
| Organization ORI Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Organization ORI Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/OrganizationORIIdentification` |
| Organization ORI Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-oz5pfkqt10y1acemrmnxfzvw` |
| Organization Parent Organization Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Parent Organization Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-parent-organization-reference` |
| Organization Parent Organization Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Parent Organization Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationParentOrganization` |
| Organization Principal Official Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Principal Official Reference | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-principal-official-reference` |
| Organization Principal Official Reference | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Principal Official Reference | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationPrincipalOfficial` |
| Organization Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Status | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-status` |
| Organization Status | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Status | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationStatus` |
| Organization Sub Unit Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Sub Unit Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-sub-unit-name` |
| Organization Sub Unit Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Sub Unit Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationSubUnitName` |
| Organization Tax Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Tax Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-tax-identification` |
| Organization Tax Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Tax Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationTaxIdentification` |
| Organization Tax Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gu15c6jojx09jy9at1px0ufh` |
| Organization Unit Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Unit Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-unit-name` |
| Organization Unit Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Unit Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationUnitName` |
| Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/organization-name` |
| Organization Name | `dcterms:source` | `https://schema.org/` |
| Organization Name | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C93874` |
| Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Organization Category ND Ex Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Category ND Ex Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/j-organization-category-nd-ex-code` |
| Organization Category ND Ex Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/justice.xsd` |
| Organization Category ND Ex Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/ndex/6.0/OrganizationCategoryCodeSimpleType` |
| Organization Category ND Ex Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/justice/6.0/OrganizationCategoryNDExCode` |
| Organization Established Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Established Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-established-date` |
| Organization Established Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Established Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationEstablishedDate` |
| Organization Incorporation Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Incorporation Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-incorporation-date` |
| Organization Incorporation Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Incorporation Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationIncorporationDate` |
| Organization Termination Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Organization Termination Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/organization-termination-date` |
| Organization Termination Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Organization Termination Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/OrganizationTerminationDate` |
| Contact Information (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Information (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-information` |
| Contact Information (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Information (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationType` |
| Contact Information (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vy0xsgoam40pob60gu6mbrqo` |
| Contact Entity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Entity Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-entity-description` |
| Contact Entity Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Entity Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactEntityDescriptionText` |
| Contact Information Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Information Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-information-description` |
| Contact Information Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Information Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationDescriptionText` |
| Contact Information Availability Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Information Availability Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/contact-information-availability-code` |
| Contact Information Availability Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Contact Information Availability Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationAvailabilityCode` |
| Contact Information Availability Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/ContactInformationAvailabilityCodeSimpleType` |
| Address (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address` |
| Address (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressType` |
| Address (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tfg5f0628p7bajmz49u8k7cd` |
| Address Building Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Building Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-building-name` |
| Address Building Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Building Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressBuildingName` |
| Address County Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address County Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-county-name` |
| Address County Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address County Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCountyName` |
| Address Delivery Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Delivery Point | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-delivery-point` |
| Address Delivery Point | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Delivery Point | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressDeliveryPointText` |
| Address Full | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Full | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-full` |
| Address Full | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Full | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressFullText` |
| Address Postal Extension Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Postal Extension Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-postal-extension-code` |
| Address Postal Extension Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Postal Extension Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressPostalExtensionCode` |
| Address Private Mailbox | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Private Mailbox | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-private-mailbox` |
| Address Private Mailbox | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Private Mailbox | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressPrivateMailboxText` |
| Address Recipient Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Recipient Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-recipient-name` |
| Address Recipient Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Recipient Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressRecipientName` |
| Address Secondary Unit | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Secondary Unit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-secondary-unit` |
| Address Secondary Unit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Secondary Unit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressSecondaryUnitText` |
| Address Secondary Unit | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rng9tofh09ezkym5u5d8o6kr` |
| Address Urbanization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Urbanization Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-urbanization-name` |
| Address Urbanization Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Urbanization Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressUrbanizationName` |
| Address Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-category-code` |
| Address Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCategoryCode` |
| Address Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCategoryCodeSimpleType` |
| County (fips) | `dcterms:publisher` | `https://axius-sdc.com` |
| County (fips) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| County (fips) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/fips-county` |
| County (fips) | `skos:closeMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| County (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/CountyCode` |
| Code List: fips US County5 Digit | `dcterms:publisher` | `https://axius-sdc.com` |
| Code List: fips US County5 Digit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| Code List: fips US County5 Digit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/system-fips-us-county5-digit` |
| Code List: fips US County5 Digit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/code-display-text` |
| Code Display Text | `dcterms:source` | `https://www.w3.org/TR/skos-reference/` |
| Code Display Text | `skos:exactMatch` | `http://www.w3.org/2004/02/skos/core#prefLabel` |
| County Code (fips) | `dcterms:publisher` | `https://axius-sdc.com` |
| County Code (fips) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| County Code (fips) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/fips-county-code` |
| County Code (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/CountyCode` |
| County Code (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| International Address | `dcterms:publisher` | `https://axius-sdc.com` |
| International Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/international-address` |
| International Address | `dcterms:source` | `https://schema.org/` |
| International Address | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| International Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-g6qfe9l84vekq97kgvhtu3qw` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| Postal Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Postal Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/postal-code` |
| Postal Code | `dcterms:source` | `https://schema.org/` |
| Postal Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| Postal Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kgbwgi00bhxyyt176bsmulf0` |
| Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/region-name` |
| Region Name | `dcterms:source` | `https://schema.org/` |
| Region Name | `skos:exactMatch` | `https://schema.org/addressRegion` |
| Region Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fvgk640ozbukdci5swd6wytt` |
| Address Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Address Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-use` |
| Address Use | `skos:exactMatch` | `http://hl7.org/fhir/address-use` |
| Address Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-offwpyuzrbirkryvvbzqqg31` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Contact Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Point | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-point` |
| Contact Point | `dcterms:source` | `https://schema.org/` |
| Contact Point | `skos:exactMatch` | `https://schema.org/ContactPoint` |
| Contact Point | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pet65c3gbwhp7j2fyiglwv5q` |
| Website URL | `dcterms:publisher` | `https://axius-sdc.com` |
| Website URL | `dcterms:identifier` | `https://axius-sdc.com/library/default/website-url` |
| Website URL | `dcterms:source` | `https://schema.org/` |
| Website URL | `skos:exactMatch` | `https://schema.org/url` |
| Website URL | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t4fl1c1qbhmgyem3fczjdq16` |
| Email Address | `dcterms:publisher` | `https://axius-sdc.com` |
| Email Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/email-address` |
| Email Address | `dcterms:source` | `https://www.rfc-editor.org/rfc/rfc5321` |
| Email Address | `skos:exactMatch` | `https://schema.org/email` |
| Email Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uvl0tla5aocdzsdrby589b6l` |
| Fax Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Fax Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Fax Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/fax-number` |
| Fax Number | `skos:exactMatch` | `https://schema.org/faxNumber` |
| Fax Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hzpld81b2ddnp5qywombgpls` |
| Phone Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Phone Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Phone Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/phone-number` |
| Phone Number | `skos:exactMatch` | `https://schema.org/telephone` |
| Phone Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ma9dwgbrvprfyypwldni2qfx` |
| Contact Method | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Method | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Method | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-method` |
| Contact Method | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-system` |
| Contact Method | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tf5wlywn6meurn6o1sz8yuaq` |
| Contact Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-use` |
| Contact Use | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-use` |
| Contact Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-klgho4tqvbu5iyt6zzx1ioi9` |
| Location (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Location (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location` |
| Location (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationType` |
| Location (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-k2gzmlxjixdm6l1moo5rhwrn` |
| Location Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-category` |
| Location Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationCategoryText` |
| Location Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-description` |
| Location Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationDescriptionText` |
| Location Directions | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Directions | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-directions` |
| Location Directions | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Directions | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationDirectionsText` |
| Location Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-identification` |
| Location Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationIdentification` |
| Location Landmark Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Landmark Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-landmark-name` |
| Location Landmark Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Landmark Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationLandmarkName` |
| Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-name` |
| Location Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationName` |
| Location Range Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Range Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-range-description` |
| Location Range Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Range Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationRangeDescriptionText` |
| Location Surrounding Area Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Surrounding Area Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-surrounding-area-description` |
| Location Surrounding Area Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Surrounding Area Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationSurroundingAreaDescriptionText` |
| Location Altitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Altitude | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-altitude` |
| Location Altitude | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Altitude | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationAltitude` |
| Location Elevation | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Elevation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-elevation` |
| Location Elevation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Elevation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationElevation` |
| Geolocation | `dcterms:publisher` | `https://axius-sdc.com` |
| Geolocation | `dcterms:identifier` | `https://axius-sdc.com/library/default/geolocation` |
| Geolocation | `dcterms:source` | `https://schema.org/` |
| Geolocation | `skos:exactMatch` | `https://schema.org/GeoCoordinates` |
| Geodetic Datum | `dcterms:publisher` | `https://axius-sdc.com` |
| Geodetic Datum | `dcterms:source` | `https://epsg.org/` |
| Geodetic Datum | `dcterms:identifier` | `https://axius-sdc.com/library/default/geodetic-datum` |
| Geodetic Datum | `skos:closeMatch` | `http://www.wikidata.org/entity/Q182643` |
| Altitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Altitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/altitude` |
| Altitude | `dcterms:source` | `http://qudt.org/` |
| Altitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Altitude` |
| Altitude | `skos:exactMatch` | `https://schema.org/elevation` |
| Latitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Latitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/latitude` |
| Latitude | `dcterms:source` | `http://qudt.org/` |
| Latitude | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68642` |
| Latitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Angle` |
| Latitude | `skos:exactMatch` | `https://schema.org/latitude` |
| Latitude | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sws9fskrdla5e99x7cn4trwo` |
| Longitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Longitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/longitude` |
| Longitude | `dcterms:source` | `http://qudt.org/` |
| Longitude | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68643` |
| Longitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Angle` |
| Longitude | `skos:exactMatch` | `https://schema.org/longitude` |
| Longitude | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ecyu6tt7kkjq4rzhthe74ed6` |
| Locale | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale` |
| Locale | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleType` |
| Locale Census Block ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Census Block ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-census-block-id` |
| Locale Census Block ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Census Block ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCensusBlockID` |
| Locale Census Tract ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Census Tract ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-census-tract-id` |
| Locale Census Tract ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Census Tract ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCensusTractID` |
| Locale Community Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Community Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-community-name` |
| Locale Community Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Community Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCommunityName` |
| Locale Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-description` |
| Locale Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleDescriptionText` |
| Locale District Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale District Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-district-name` |
| Locale District Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale District Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleDistrictName` |
| Locale Emergency Services Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Emergency Services Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-emergency-services-jurisdiction-id` |
| Locale Emergency Services Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Emergency Services Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleEmergencyServicesJurisdictionID` |
| Locale Emergency Services Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Emergency Services Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-emergency-services-name` |
| Locale Emergency Services Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Emergency Services Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleEmergencyServicesName` |
| Locale Fire Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Fire Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-fire-jurisdiction-id` |
| Locale Fire Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Fire Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleFireJurisdictionID` |
| Locale Judicial District Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Judicial District Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-judicial-district-name` |
| Locale Judicial District Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Judicial District Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleJudicialDistrictName` |
| Locale Neighborhood Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Neighborhood Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-neighborhood-name` |
| Locale Neighborhood Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Neighborhood Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleNeighborhoodName` |
| Locale Police Beat | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Beat | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-beat` |
| Locale Police Beat | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Beat | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceBeatText` |
| Locale Police Grid | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Grid | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-grid` |
| Locale Police Grid | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Grid | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceGridText` |
| Locale Police Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-jurisdiction-id` |
| Locale Police Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceJurisdictionID` |
| Locale Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-region-name` |
| Locale Region Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Region Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleRegionName` |
| Locale Subdivision Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Subdivision Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-subdivision-name` |
| Locale Subdivision Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Subdivision Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleSubdivisionName` |
| Locale Zone Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Zone Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-zone-name` |
| Locale Zone Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Zone Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleZoneName` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "Business Registry 4.4.0" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-nb7gtyimcusmritzx0o0x40o.xsd)
- Example instance (dm-nb7gtyimcusmritzx0o0x40o.xml)
- HTML documentation (dm-nb7gtyimcusmritzx0o0x40o.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"Business Registry 4.4.0" SDC4 schema (dm-nb7gtyimcusmritzx0o0x40o.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"Business Registry 4.4.0" schema (dm-nb7gtyimcusmritzx0o0x40o.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "Business Registry 4.4.0" SDC4 schema (dm-nb7gtyimcusmritzx0o0x40o.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "Business Registry 4.4.0" data model (dm-nb7gtyimcusmritzx0o0x40o.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-nb7gtyimcusmritzx0o0x40o.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-nb7gtyimcusmritzx0o0x40o.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-nb7gtyimcusmritzx0o0x40o.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-nb7gtyimcusmritzx0o0x40o.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-nb7gtyimcusmritzx0o0x40o.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
