# Civil Registry 4.4.0

**Model ID**: `dm-etkbxubkngv0v81yvqz77xrs`
**Project**: Cordova
**Description**: Maintain the authoritative identity record for every person in Cordova.

### Dublin Core Metadata
- **Subject**: Civil Registry
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal
- **Publisher**: Axius SDC, Inc.

## Package Contents

- `dm-etkbxubkngv0v81yvqz77xrs.xsd` -- XML Schema Definition (data model structure)
- `dm-etkbxubkngv0v81yvqz77xrs.xml` -- XML instance example with sample data
- `dm-etkbxubkngv0v81yvqz77xrs-instance.json` -- JSON instance example (same structure as XML)
- `dm-etkbxubkngv0v81yvqz77xrs.jsonld` -- JSON-LD semantic schema description
- `dm-etkbxubkngv0v81yvqz77xrs.html` -- Human-readable model documentation
- `dm-etkbxubkngv0v81yvqz77xrs_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-etkbxubkngv0v81yvqz77xrs.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-etkbxubkngv0v81yvqz77xrs.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-etkbxubkngv0v81yvqz77xrs.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-etkbxubkngv0v81yvqz77xrs.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **Civil Registry Governed Record** | Cluster | `jkl2gufrtpbp8gpno35b7wiy` | 1 components; 4 sub-cluster(s) |
|   Digital Signature Proof | XdFile | `gug5dhtqfv7exbgmm2raxpkq` | -- |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **Civil Registry Record** | Cluster | `rl1fs239itr2hdik6iz311t4` | 3 components; 4 sub-cluster(s) |
|     National ID (CID) | XdString | `nj7s1gk45tfgyooxpz0qaha3` | exactLen=16; pattern=`COR-(AL|BR|CE)0[1-3]-[0-9]{6}` |
|     Person Gender Identity Code | XdToken | `jehcvvbkw36i1ecd5ooqbwp9` | 9 enum(s) |
|     Marital Status | XdToken | `z11vs0cvonack540omgwhxhz` | 11 enum(s) |
|     **Address (Cordova)** | Cluster | `hsy6giqwj6g3eeh7ahp44j6h` | 5 components |
|       Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|       Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|       Postal Code | XdString | `gf841eedvv6cjiegs934srai` | maxLen=15 |
|       City | XdToken | `atdtdfzruh7tya0iv5cz365l` | 9 enum(s) |
|       Province | XdToken | `kv5qqs3o4jwcwz9javgw1pzh` | 3 enum(s) |
|     **Contact Point** | Cluster | `d2xwhnb2vqzxw70jcizj9csx` | 6 components |
|       Website URL | XdLink | `wriny2gz8aqcvffmfpwbompk` | -- |
|       Email Address | XdString | `q922mqaon3yn5zlwf2bszf28` | maxLen=254; pattern=`.+@.+\..+` |
|       Fax Number | XdString | `ll6ltsnvakomixuitxkbkxfz` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|       Phone Number | XdString | `zpfwg52r88j6jdypj7rg71ke` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|       Contact Method | XdToken | `miqo30r5b554nyj7ubryw43x` | 7 enum(s) |
|       Contact Use | XdToken | `vmruk4j9y1orvvz8cwafrax5` | 5 enum(s) |
|     **Family Relationship** | Cluster | `rzvgv4tknabti2p61p3ebhbw` | 2 components; 1 sub-cluster(s) |
|       National ID (CID) | XdString | `nj7s1gk45tfgyooxpz0qaha3` | exactLen=16; pattern=`COR-(AL|BR|CE)0[1-3]-[0-9]{6}` |
|       Relationship to Subject | XdToken | `i2vrm5bvxw03tcoesvgnft64` | 18 enum(s) |
|       **Date Range** | Cluster | `ru9u47yxhe337pslpxm6cflx` | 2 components |
|         Date Range End | XdTemporal | `moo2lije2b05ylq8q4t52lcb` | -- |
|         Date Range Start | XdTemporal | `bcyjfdwobh9q60umle1amw0w` | -- |
|     **Person (Demographics)** | Cluster | `vag4j8x1v4bp92xkmks7q4to` | 4 components; 1 sub-cluster(s) |
|       Administrative Gender | XdToken | `gxzbm758mhdz51xd4bawlfhh` | 4 enum(s) |
|       Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|       Language Code | XdToken | `no649c8yiebkyujhlbwjuppx` | 184 enum(s) |
|       Date of Birth | XdTemporal | `js564tazefb6udqlh12rj04l` | -- |
|       **Full Name (Person)** | Cluster | `ytw6qjtq5gilrvkfsohsrlkh` | 6 components |
|         Given Name (Person) | XdString | `l9l169co9r23e6fftpvdz4e3` | minLen=1; maxLen=100 |
|         Middle Name (Person) | XdString | `zcf4f5kjjo497jeb9vtt9rmr` | minLen=1; maxLen=100 |
|         Name Prefix | XdString | `yahxccv0l1z6ykjxayzkdlkq` | maxLen=20 |
|         Name Suffix | XdString | `l509t0zajfl5atns64d5kl97` | maxLen=20 |
|         Surname (Person) | XdString | `jc1lfk3ovt6l8frhxvx8b669` | minLen=1; maxLen=100 |
|         Name Use | XdToken | `bfqinvm7qrgi9jjw1i637moh` | 7 enum(s) |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: Civil Registry 4.4.0
  [Cluster] Civil Registry Governed Record
    [XdFile] Digital Signature Proof
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] Civil Registry Record
      [XdString] National ID (CID)
      [XdToken] Person Gender Identity Code
      [XdToken] Marital Status
      [Cluster] Address (Cordova)
        [XdString] Address (Line 1)
        [XdString] Address (Line 2)
        [XdString] Postal Code
        [XdToken] City
        [XdToken] Province
      [Cluster] Contact Point
        [XdLink] Website URL
        [XdString] Email Address
        [XdString] Fax Number
        [XdString] Phone Number
        [XdToken] Contact Method
        [XdToken] Contact Use
      [Cluster] Family Relationship
        [XdString] National ID (CID)
        [XdToken] Relationship to Subject
        [Cluster] Date Range
          [XdTemporal] Date Range End
          [XdTemporal] Date Range Start
      [Cluster] Person (Demographics)
        [XdToken] Administrative Gender
        [XdToken] Country Code ISO 3166
        [XdToken] Language Code
        [XdTemporal] Date of Birth
        [Cluster] Full Name (Person)
          [XdString] Given Name (Person)
          [XdString] Middle Name (Person)
          [XdString] Name Prefix
          [XdString] Name Suffix
          [XdString] Surname (Person)
          [XdToken] Name Use
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Civil Registry Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Civil Registry Governed Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Civil Registry Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/civil-registry-governed-record` |
| Civil Registry Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Civil Registry Governed Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-aan7382wp8e2f58m9a2hvmkp` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.w3.org/TR/vc-data-model/#credentials` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q210824` |
| Digital Signature Proof | `skos:broadMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| Civil Registry Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Civil Registry Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Civil Registry Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/civil-registry-record` |
| Civil Registry Record | `skos:exactMatch` | `https://schema.org/Person` |
| Civil Registry Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bgjt4mvgvkxcn6hurg37u21b` |
| National ID (CID) | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| National ID (CID) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1140371` |
| National ID (CID) | `skos:broadMatch` | `https://schema.org/identifier` |
| Person Gender Identity Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Gender Identity Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/hs-person-gender-identity-code` |
| Person Gender Identity Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/domains/hs.xsd` |
| Person Gender Identity Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/humanServices/6.0/PersonGenderIdentityCode` |
| Person Gender Identity Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/domains/humanServices/6.0/PersonGenderIdentityCodeSimpleType` |
| Marital Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Marital Status | `dcterms:source` | `http://terminology.hl7.org/` |
| Marital Status | `dcterms:identifier` | `https://axius-sdc.com/library/default/marital-status` |
| Marital Status | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25188` |
| Marital Status | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-MaritalStatus` |
| Address (Cordova) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Cordova) | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Address (Cordova) | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/cordova-address` |
| Address (Cordova) | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| Address (Cordova) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ytctcqbr30kxsmvx4jk7lae2` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| Postal Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Postal Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/postal-code` |
| Postal Code | `dcterms:source` | `https://schema.org/` |
| Postal Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| Postal Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kgbwgi00bhxyyt176bsmulf0` |
| City | `rdfs:isDefinedBy` | `http://schema.org/City` |
| City | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| City | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Province | `rdfs:isDefinedBy` | `http://schema.org/AdministrativeArea` |
| Province | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Province | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Province | `rdfs:isDefinedBy` | `https://schema.org/State` |
| Contact Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Point | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-point` |
| Contact Point | `dcterms:source` | `https://schema.org/` |
| Contact Point | `skos:exactMatch` | `https://schema.org/ContactPoint` |
| Contact Point | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pet65c3gbwhp7j2fyiglwv5q` |
| Website URL | `dcterms:publisher` | `https://axius-sdc.com` |
| Website URL | `dcterms:identifier` | `https://axius-sdc.com/library/default/website-url` |
| Website URL | `dcterms:source` | `https://schema.org/` |
| Website URL | `skos:exactMatch` | `https://schema.org/url` |
| Website URL | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t4fl1c1qbhmgyem3fczjdq16` |
| Email Address | `dcterms:publisher` | `https://axius-sdc.com` |
| Email Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/email-address` |
| Email Address | `dcterms:source` | `https://www.rfc-editor.org/rfc/rfc5321` |
| Email Address | `skos:exactMatch` | `https://schema.org/email` |
| Email Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uvl0tla5aocdzsdrby589b6l` |
| Fax Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Fax Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Fax Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/fax-number` |
| Fax Number | `skos:exactMatch` | `https://schema.org/faxNumber` |
| Fax Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hzpld81b2ddnp5qywombgpls` |
| Phone Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Phone Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Phone Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/phone-number` |
| Phone Number | `skos:exactMatch` | `https://schema.org/telephone` |
| Phone Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ma9dwgbrvprfyypwldni2qfx` |
| Contact Method | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Method | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Method | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-method` |
| Contact Method | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-system` |
| Contact Method | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tf5wlywn6meurn6o1sz8yuaq` |
| Contact Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-use` |
| Contact Use | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-use` |
| Contact Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-klgho4tqvbu5iyt6zzx1ioi9` |
| Family Relationship | `dcterms:publisher` | `https://axius-sdc.com` |
| Family Relationship | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Family Relationship | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/family-relationship` |
| Family Relationship | `skos:exactMatch` | `https://schema.org/relatedTo` |
| Family Relationship | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l9k2fmlc5vn477r3kpi1ufal` |
| National ID (CID) | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| National ID (CID) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1140371` |
| National ID (CID) | `skos:broadMatch` | `https://schema.org/identifier` |
| Relationship to Subject | `dcterms:publisher` | `https://axius-sdc.com` |
| Relationship to Subject | `dcterms:source` | `http://terminology.hl7.org/` |
| Relationship to Subject | `dcterms:identifier` | `https://axius-sdc.com/library/default/relationship-to-subject` |
| Relationship to Subject | `skos:closeMatch` | `http://hl7.org/fhir/ValueSet/relatedperson-relationshiptype` |
| Relationship to Subject | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-RoleCode` |
| Date Range | `dcterms:publisher` | `https://axius-sdc.com` |
| Date Range | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-range` |
| Date Range | `dcterms:source` | `https://schema.org/` |
| Date Range | `skos:closeMatch` | `http://www.wikidata.org/entity/Q186081` |
| Date Range | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vpbi3zvbq0kt3r68nqydukrw` |
| Date Range End | `dcterms:publisher` | `https://axius-sdc.com` |
| Date Range End | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-range-end` |
| Date Range End | `dcterms:source` | `https://schema.org/` |
| Date Range End | `skos:exactMatch` | `https://schema.org/endDate` |
| Date Range End | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m6qw6eek8jbyjxxlmy9rmiju` |
| Date Range Start | `dcterms:publisher` | `https://axius-sdc.com` |
| Date Range Start | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-range-start` |
| Date Range Start | `dcterms:source` | `https://schema.org/` |
| Date Range Start | `skos:exactMatch` | `https://schema.org/startDate` |
| Date Range Start | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kazur5ajt4axnp93b4ha5t7x` |
| Person (Demographics) | `dcterms:publisher` | `https://axius-sdc.com` |
| Person (Demographics) | `dcterms:identifier` | `https://axius-sdc.com/library/default/person-demographics` |
| Person (Demographics) | `dcterms:source` | `https://schema.org/` |
| Person (Demographics) | `skos:exactMatch` | `https://schema.org/Person` |
| Administrative Gender | `dcterms:publisher` | `https://axius-sdc.com` |
| Administrative Gender | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Administrative Gender | `dcterms:identifier` | `https://axius-sdc.com/library/default/administrative-gender` |
| Administrative Gender | `skos:exactMatch` | `http://hl7.org/fhir/administrative-gender` |
| Administrative Gender | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tnyh2ude3db9smwfin0vai5h` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Language Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Language Code | `dcterms:source` | `https://www.iso.org/iso-639-language-code` |
| Language Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/language-code` |
| Language Code | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C16779` |
| Language Code | `skos:exactMatch` | `https://schema.org/inLanguage` |
| Language Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w7t802u535su9576z02uw71o` |
| Date of Birth | `dcterms:publisher` | `https://axius-sdc.com` |
| Date of Birth | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-of-birth` |
| Date of Birth | `dcterms:source` | `https://schema.org/` |
| Date of Birth | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68615` |
| Date of Birth | `skos:exactMatch` | `https://schema.org/birthDate` |
| Full Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Full Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/full-name-person` |
| Full Name (Person) | `dcterms:source` | `https://schema.org/` |
| Full Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q1071027` |
| Full Name (Person) | `skos:exactMatch` | `https://schema.org/Person` |
| Full Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gwpvlduwrtpog4kpidaenshn` |
| Given Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Given Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/given-name-person` |
| Given Name (Person) | `dcterms:source` | `https://schema.org/` |
| Given Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q202444` |
| Given Name (Person) | `skos:exactMatch` | `https://schema.org/givenName` |
| Given Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kfyzf8u8gdafcpt5kfh2qg3q` |
| Middle Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Middle Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/middle-name-person` |
| Middle Name (Person) | `dcterms:source` | `https://schema.org/` |
| Middle Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q245025` |
| Middle Name (Person) | `skos:exactMatch` | `https://schema.org/additionalName` |
| Middle Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-oit0ueglhjfcyq80z22kl2z3` |
| Name Prefix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Prefix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-prefix` |
| Name Prefix | `dcterms:source` | `https://schema.org/` |
| Name Prefix | `skos:exactMatch` | `https://schema.org/honorificPrefix` |
| Name Prefix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-u9x2b6frfi0rbydeoncijfp1` |
| Name Suffix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Suffix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-suffix` |
| Name Suffix | `dcterms:source` | `https://schema.org/` |
| Name Suffix | `skos:exactMatch` | `https://schema.org/honorificSuffix` |
| Name Suffix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zldtbpvyouzi7t1dorc07rb3` |
| Surname (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Surname (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/surname-person` |
| Surname (Person) | `dcterms:source` | `https://schema.org/` |
| Surname (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q101352` |
| Surname (Person) | `skos:exactMatch` | `https://schema.org/familyName` |
| Surname (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-v8jgjo2sml12jo7zrb8swoxi` |
| Name Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Name Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-use` |
| Name Use | `skos:exactMatch` | `http://hl7.org/fhir/name-use` |
| Name Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zlg3riiu515tsg0mdkx5brkc` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "Civil Registry 4.4.0" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-etkbxubkngv0v81yvqz77xrs.xsd)
- Example instance (dm-etkbxubkngv0v81yvqz77xrs.xml)
- HTML documentation (dm-etkbxubkngv0v81yvqz77xrs.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"Civil Registry 4.4.0" SDC4 schema (dm-etkbxubkngv0v81yvqz77xrs.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"Civil Registry 4.4.0" schema (dm-etkbxubkngv0v81yvqz77xrs.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "Civil Registry 4.4.0" SDC4 schema (dm-etkbxubkngv0v81yvqz77xrs.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "Civil Registry 4.4.0" data model (dm-etkbxubkngv0v81yvqz77xrs.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-etkbxubkngv0v81yvqz77xrs.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-etkbxubkngv0v81yvqz77xrs.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-etkbxubkngv0v81yvqz77xrs.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-etkbxubkngv0v81yvqz77xrs.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-etkbxubkngv0v81yvqz77xrs.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
