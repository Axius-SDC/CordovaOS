# Property Registry 4.4.0

**Model ID**: `dm-goc13fg5a97ghcqv64h782af`
**Project**: Cordova
**Description**: Maintain the authoritative registry of land and property ownership in Cordova.

### Dublin Core Metadata
- **Subject**: Property Record
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal
- **Publisher**: Axius SDC, Inc.

## Package Contents

- `dm-goc13fg5a97ghcqv64h782af.xsd` -- XML Schema Definition (data model structure)
- `dm-goc13fg5a97ghcqv64h782af.xml` -- XML instance example with sample data
- `dm-goc13fg5a97ghcqv64h782af-instance.json` -- JSON instance example (same structure as XML)
- `dm-goc13fg5a97ghcqv64h782af.jsonld` -- JSON-LD semantic schema description
- `dm-goc13fg5a97ghcqv64h782af.html` -- Human-readable model documentation
- `dm-goc13fg5a97ghcqv64h782af_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-goc13fg5a97ghcqv64h782af.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-goc13fg5a97ghcqv64h782af.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-goc13fg5a97ghcqv64h782af.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-goc13fg5a97ghcqv64h782af.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **Property Registry Governed Record** | Cluster | `a79m06519b9qglqbhaulto7h` | 1 components; 4 sub-cluster(s) |
|   Digital Signature Proof | XdFile | `gug5dhtqfv7exbgmm2raxpkq` | -- |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **Property Record** | Cluster | `l9bhdtigs94bwmsu3t1n9xp1` | 7 components; 4 sub-cluster(s) |
|     National ID (CID) | XdString | `nj7s1gk45tfgyooxpz0qaha3` | exactLen=16; pattern=`COR-(AL|BR|CE)0[1-3]-[0-9]{6}` |
|     Parcel Number | XdString | `hs7197k4s33eg7wbspgudu4u` | exactLen=12; pattern=`(AL|BR|CE)-0[1-3]-[0-9]{6}` |
|     City | XdToken | `atdtdfzruh7tya0iv5cz365l` | 9 enum(s) |
|     Property Status | XdToken | `xtljf8q6rfyfewdkgu4e5ouj` | 5 enum(s) |
|     Property Type (Cordova) | XdToken | `l79ua955rihnjbrxyhu7z5ac` | 5 enum(s) |
|     Province | XdToken | `kv5qqs3o4jwcwz9javgw1pzh` | 3 enum(s) |
|     Registration Date | XdTemporal | `vo9jtmexkaaol3y657fm0xn8` | -- |
|     **Lien** | Cluster | `kamsjtflanpnhfffiexw366w` | 5 components |
|       Lien Holder | XdString | `in6swdxnzwkj4rv1lpdgo9s8` | minLen=1; maxLen=100 |
|       Lien Status | XdToken | `kzalko16uuwdw74yohvr5t50` | 3 enum(s) |
|       Lien Type | XdToken | `cy92p3uebrmjf191wcs07t3o` | 5 enum(s) |
|       Lien Amount | XdQuantity | `da261k0tox4747gnkmmek15i` | min=0.00000; units=Cordova Córdoba (COR) |
|       Lien Date | XdTemporal | `zicto01f2grmzuqtgdonv83w` | -- |
|     **Location (NIEM)** | Cluster | `o01gifxohfe46jfdyh62noig` | 10 components; 3 sub-cluster(s) |
|       Location Category | XdString | `fenldej2l73b84w956gawyqd` | maxLen=4000 |
|       Location Description | XdString | `zlqtx5yr8wdxavl2hc4y9uq4` | maxLen=4000 |
|       Location Directions | XdString | `fwusqzhkfgeh7gwrsgihp0rx` | maxLen=4000 |
|       Location Identification | XdString | `c9n7299dj2fdzlmqe8ixvb2z` | maxLen=64 |
|       Location Landmark Name | XdString | `vw3tuujru1u95k6kavnc946v` | maxLen=255 |
|       Location Name | XdString | `ouramzsx8f7nis27vjj265l9` | maxLen=255 |
|       Location Range Description | XdString | `ces753kz92cp4zdyva7qw530` | maxLen=4000 |
|       Location Surrounding Area Description | XdString | `enu405jym8hdu571utuznru3` | maxLen=4000 |
|       Location Altitude | XdQuantity | `qjl8rgtsnazid1rvxqof65yy` | units=Length Units (SI and customary) |
|       Location Elevation | XdQuantity | `n3luxpr7zt9z2ylpmp2wioy4` | units=Length Units (SI and customary) |
|       **Address (NIEM)** | Cluster | `doa46sdyoadezgc0tpj379th` | 10 components; 2 sub-cluster(s) |
|         Address Building Name | XdString | `bgn0jx6ubvcjtwa17hxvini2` | maxLen=255 |
|         Address County Name | XdString | `vkbg8z0vmi1a4u99xp1mbsal` | maxLen=255 |
|         Address Delivery Point | XdString | `ep615o1qzzlhz9f2g2quf6sp` | maxLen=4000 |
|         Address Full | XdString | `dwy0u03b1iidzxi4ega2iy5r` | maxLen=4000 |
|         Address Postal Extension Code | XdString | `lckcihuej9hiyqfjhekk6nid` | maxLen=255 |
|         Address Private Mailbox | XdString | `jx13ihzux8cd382oenzlkn05` | maxLen=4000 |
|         Address Recipient Name | XdString | `qcngrwgzzjxvcbxbm9oxonei` | maxLen=255 |
|         Address Secondary Unit | XdString | `fvznldoks6w41g7a4pwvd2ub` | maxLen=4000 |
|         Address Urbanization Name | XdString | `fzjp1m1u66usm20aamjygmun` | maxLen=255 |
|         Address Category Code | XdToken | `k0ixe4ybmx5vp11f7de4k204` | 5 enum(s) |
|         **County (fips)** | Cluster | `bahj0gy7mbmyobqhfy70x190` | 3 components |
|           Code List: fips US County5 Digit | XdLink | `s5u98t1ah8l5069q0x704tdt` | -- |
|           Code Display Text | XdString | `kr8fmao4yji8vr46kiw150me` | maxLen=500 |
|           County Code (fips) | XdString | `dy9dwf3fhe3y6hyf1ka5fbfz` | maxLen=5; pattern=`[0-9]{5,5}` |
|         **International Address** | Cluster | `upawqojmcfg3qsf4ffzi47ho` | 7 components |
|           Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|           Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|           City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|           Postal Code | XdString | `gf841eedvv6cjiegs934srai` | maxLen=15 |
|           Region Name | XdString | `jw1b9q6ulyte599sdsqp2mvp` | maxLen=100 |
|           Address Use | XdToken | `b25dj42zxhm19pih328ga8pl` | 5 enum(s) |
|           Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|       **Geolocation** | Cluster | `jwfl94g8mj8aevupivyfsnwj` | 4 components |
|         Geodetic Datum | XdToken | `i3qpmie9hle8ma5kt6ogxqnp` | 3 enum(s) |
|         Altitude | XdQuantity | `scdlxu6vex8iwbfc8sijmjff` | units=Length/Distance (SI - Metric) |
|         Latitude | XdQuantity | `c5e0wv21cmlouukx6ga2o5uz` | units=Degrees (Angle) |
|         Longitude | XdQuantity | `qh625ukiiju3ak4x45tehcnr` | units=Degrees (Angle) |
|       **Locale** | Cluster | `ru0fwf4ubdvcizzaau0mpftg` | 16 components |
|         Locale Census Block ID | XdString | `ji7mja9le7x3k2fnstyflgd9` | maxLen=255 |
|         Locale Census Tract ID | XdString | `b1qnngc94yrhnzw0a0qylc8m` | maxLen=255 |
|         Locale Community Name | XdString | `d62un867sx8pfuoiw9vmyvhc` | maxLen=255 |
|         Locale Description | XdString | `qhmp2uf6xmb86vdwzt9pz0z4` | maxLen=4000 |
|         Locale District Name | XdString | `xrx13kgg5bxgodid3gojzc4u` | maxLen=255 |
|         Locale Emergency Services Jurisdiction ID | XdString | `nmhyp4tz6uzhm9rcbxksrkad` | maxLen=255 |
|         Locale Emergency Services Name | XdString | `zza5jn63yvlxhjgkajypacqi` | maxLen=255 |
|         Locale Fire Jurisdiction ID | XdString | `nvonmskk57e6buoa4bjo4yq5` | maxLen=255 |
|         Locale Judicial District Name | XdString | `ep6d634smvqdn890vnjs8umh` | maxLen=255 |
|         Locale Neighborhood Name | XdString | `hs4ke1zgmxvea6nd41ivepg5` | maxLen=255 |
|         Locale Police Beat | XdString | `dt27rd2aw6bfydiru5ti7gyh` | maxLen=4000 |
|         Locale Police Grid | XdString | `rdk1jsosk7dgsbn7hkq3k10i` | maxLen=4000 |
|         Locale Police Jurisdiction ID | XdString | `end6e085n8tw4850taf7jjl2` | maxLen=255 |
|         Locale Region Name | XdString | `xswwghxc0mdmucw58sa5axse` | maxLen=255 |
|         Locale Subdivision Name | XdString | `f0j0mvmsjdjfccynvpynntd8` | maxLen=255 |
|         Locale Zone Name | XdString | `fypmwmyh1gcv597iesiyxdzd` | maxLen=255 |
|     **Property Transfer** | Cluster | `pouommkb153by3zlgatw2sbt` | 4 components |
|       Ownership Type | XdToken | `oj7tiljm1n0v15lb2xl4hlul` | 5 enum(s) |
|       Transfer Amount | XdQuantity | `j8gn6xsrzbnzkqlnpk2dkwam` | min=0.00000; units=Cordova Córdoba (COR) |
|       Ownership Start Date | XdTemporal | `mp2ge4fzelcyl3cdqlxgxm0x` | -- |
|       Transfer Date | XdTemporal | `y6isg5qaxfpt1qpg102uwkn4` | -- |
|     **Property Value Assessment** | Cluster | `xrakhaoak886x5on0wvy4mv0` | 3 components |
|       Assessment Status | XdToken | `j3y76yob1s958dry2d551tew` | 3 enum(s) |
|       Assessed Value | XdQuantity | `hlg1jmx1v9t4zkq16c1i66bg` | min=0.00000; units=Cordova Córdoba (COR) |
|       Area | XdQuantity | `r9n1kjak5b0c2bjzwji49kza` | units=Area (SI - Metric) |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: Property Registry 4.4.0
  [Cluster] Property Registry Governed Record
    [XdFile] Digital Signature Proof
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] Property Record
      [XdString] National ID (CID)
      [XdString] Parcel Number
      [XdToken] City
      [XdToken] Property Status
      [XdToken] Property Type (Cordova)
      [XdToken] Province
      [XdTemporal] Registration Date
      [Cluster] Lien
        [XdString] Lien Holder
        [XdToken] Lien Status
        [XdToken] Lien Type
        [XdQuantity] Lien Amount
        [XdTemporal] Lien Date
      [Cluster] Location (NIEM)
        [XdString] Location Category
        [XdString] Location Description
        [XdString] Location Directions
        [XdString] Location Identification
        [XdString] Location Landmark Name
        [XdString] Location Name
        [XdString] Location Range Description
        [XdString] Location Surrounding Area Description
        [XdQuantity] Location Altitude
        [XdQuantity] Location Elevation
        [Cluster] Address (NIEM)
          [XdString] Address Building Name
          [XdString] Address County Name
          [XdString] Address Delivery Point
          [XdString] Address Full
          [XdString] Address Postal Extension Code
          [XdString] Address Private Mailbox
          [XdString] Address Recipient Name
          [XdString] Address Secondary Unit
          [XdString] Address Urbanization Name
          [XdToken] Address Category Code
          [Cluster] County (fips)
            [XdLink] Code List: fips US County5 Digit
            [XdString] Code Display Text
            [XdString] County Code (fips)
          [Cluster] International Address
            [XdString] Address (Line 1)
            [XdString] Address (Line 2)
            [XdString] City Name
            [XdString] Postal Code
            [XdString] Region Name
            [XdToken] Address Use
            [XdToken] Country Code ISO 3166
        [Cluster] Geolocation
          [XdToken] Geodetic Datum
          [XdQuantity] Altitude
          [XdQuantity] Latitude
          [XdQuantity] Longitude
        [Cluster] Locale
          [XdString] Locale Census Block ID
          [XdString] Locale Census Tract ID
          [XdString] Locale Community Name
          [XdString] Locale Description
          [XdString] Locale District Name
          [XdString] Locale Emergency Services Jurisdiction ID
          [XdString] Locale Emergency Services Name
          [XdString] Locale Fire Jurisdiction ID
          [XdString] Locale Judicial District Name
          [XdString] Locale Neighborhood Name
          [XdString] Locale Police Beat
          [XdString] Locale Police Grid
          [XdString] Locale Police Jurisdiction ID
          [XdString] Locale Region Name
          [XdString] Locale Subdivision Name
          [XdString] Locale Zone Name
      [Cluster] Property Transfer
        [XdToken] Ownership Type
        [XdQuantity] Transfer Amount
        [XdTemporal] Ownership Start Date
        [XdTemporal] Transfer Date
      [Cluster] Property Value Assessment
        [XdToken] Assessment Status
        [XdQuantity] Assessed Value
        [XdQuantity] Area
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Property Registry Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Property Registry Governed Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Property Registry Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/property-registry-governed-record` |
| Property Registry Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Property Registry Governed Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jyx3v449tku745yxm6hte0eg` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.w3.org/TR/vc-data-model/#credentials` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q210824` |
| Digital Signature Proof | `skos:broadMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| Property Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Property Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Property Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/property-record` |
| Property Record | `skos:exactMatch` | `https://schema.org/Place` |
| Property Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bgc4n3424bzb8gpgnjhxxha9` |
| National ID (CID) | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| National ID (CID) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1140371` |
| National ID (CID) | `skos:broadMatch` | `https://schema.org/identifier` |
| Parcel Number | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| Parcel Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q47161795` |
| Parcel Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q66502406` |
| Parcel Number | `skos:broadMatch` | `https://schema.org/identifier` |
| City | `rdfs:isDefinedBy` | `http://schema.org/City` |
| City | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| City | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Property Status | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q937228` |
| Property Status | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Property Status | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Property Type (Cordova) | `rdfs:isDefinedBy` | `http://schema.org/Property` |
| Property Type (Cordova) | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Property Type (Cordova) | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Province | `rdfs:isDefinedBy` | `http://schema.org/AdministrativeArea` |
| Province | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Province | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Province | `rdfs:isDefinedBy` | `https://schema.org/State` |
| Registration Date | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q137375576` |
| Registration Date | `skos:broadMatch` | `https://schema.org/Date` |
| Lien | `dcterms:publisher` | `https://axius-sdc.com` |
| Lien | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Lien | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/lien` |
| Lien | `skos:closeMatch` | `https://schema.org/ItemList` |
| Lien | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tjkw46wy20kstzgg1y60clxx` |
| Lien Holder | `skos:broadMatch` | `https://schema.org/name` |
| Lien Holder | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q123496152` |
| Lien Status | `rdfs:isDefinedBy` | `https://spec.edmcouncil.org/fibo/ontology/FBC/DebtAndEquities/Debt/LienStatus` |
| Lien Status | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Lien Status | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Lien Type | `rdfs:isDefinedBy` | `https://spec.edmcouncil.org/fibo/ontology/FND/Agreements/Agreements/LienType` |
| Lien Type | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Lien Type | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Lien Amount | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q4469383` |
| Lien Amount | `rdfs:isDefinedBy` | `https://schema.org/MonetaryAmount` |
| Lien Amount | `skos:broadMatch` | `http://qudt.org/vocab/quantitykind/Currency` |
| Lien Date | `rdfs:isDefinedBy` | `http://release.niem.gov/niem/niem-core/6.0/niem-core.owl#LienRecordedDate` |
| Lien Date | `skos:broadMatch` | `https://schema.org/Date` |
| Location (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Location (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location` |
| Location (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationType` |
| Location (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-k2gzmlxjixdm6l1moo5rhwrn` |
| Location Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Category | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-category` |
| Location Category | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Category | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationCategoryText` |
| Location Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-description` |
| Location Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationDescriptionText` |
| Location Directions | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Directions | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-directions` |
| Location Directions | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Directions | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationDirectionsText` |
| Location Identification | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Identification | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-identification` |
| Location Identification | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Identification | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationIdentification` |
| Location Landmark Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Landmark Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-landmark-name` |
| Location Landmark Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Landmark Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationLandmarkName` |
| Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-name` |
| Location Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationName` |
| Location Range Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Range Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-range-description` |
| Location Range Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Range Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationRangeDescriptionText` |
| Location Surrounding Area Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Surrounding Area Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-surrounding-area-description` |
| Location Surrounding Area Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Surrounding Area Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationSurroundingAreaDescriptionText` |
| Location Altitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Altitude | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-altitude` |
| Location Altitude | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Altitude | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationAltitude` |
| Location Elevation | `dcterms:publisher` | `https://axius-sdc.com` |
| Location Elevation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/location-elevation` |
| Location Elevation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Location Elevation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocationElevation` |
| Address (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address` |
| Address (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressType` |
| Address (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tfg5f0628p7bajmz49u8k7cd` |
| Address Building Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Building Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-building-name` |
| Address Building Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Building Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressBuildingName` |
| Address County Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address County Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-county-name` |
| Address County Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address County Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCountyName` |
| Address Delivery Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Delivery Point | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-delivery-point` |
| Address Delivery Point | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Delivery Point | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressDeliveryPointText` |
| Address Full | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Full | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-full` |
| Address Full | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Full | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressFullText` |
| Address Postal Extension Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Postal Extension Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-postal-extension-code` |
| Address Postal Extension Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Postal Extension Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressPostalExtensionCode` |
| Address Private Mailbox | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Private Mailbox | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-private-mailbox` |
| Address Private Mailbox | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Private Mailbox | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressPrivateMailboxText` |
| Address Recipient Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Recipient Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-recipient-name` |
| Address Recipient Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Recipient Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressRecipientName` |
| Address Secondary Unit | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Secondary Unit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-secondary-unit` |
| Address Secondary Unit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Secondary Unit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressSecondaryUnitText` |
| Address Secondary Unit | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rng9tofh09ezkym5u5d8o6kr` |
| Address Urbanization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Urbanization Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-urbanization-name` |
| Address Urbanization Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Urbanization Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressUrbanizationName` |
| Address Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/address-category-code` |
| Address Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Address Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCategoryCode` |
| Address Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/AddressCategoryCodeSimpleType` |
| County (fips) | `dcterms:publisher` | `https://axius-sdc.com` |
| County (fips) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| County (fips) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/fips-county` |
| County (fips) | `skos:closeMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| County (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/CountyCode` |
| Code List: fips US County5 Digit | `dcterms:publisher` | `https://axius-sdc.com` |
| Code List: fips US County5 Digit | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| Code List: fips US County5 Digit | `dcterms:identifier` | `https://axius-sdc.com/library/niem/system-fips-us-county5-digit` |
| Code List: fips US County5 Digit | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/niem/code-display-text` |
| Code Display Text | `dcterms:source` | `https://www.w3.org/TR/skos-reference/` |
| Code Display Text | `skos:exactMatch` | `http://www.w3.org/2004/02/skos/core#prefLabel` |
| County Code (fips) | `dcterms:publisher` | `https://axius-sdc.com` |
| County Code (fips) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/codes/fips.xsd` |
| County Code (fips) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/fips-county-code` |
| County Code (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/CountyCode` |
| County Code (fips) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/codes/fips/6.0/USCounty5DigitCodeSimpleType` |
| International Address | `dcterms:publisher` | `https://axius-sdc.com` |
| International Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/international-address` |
| International Address | `dcterms:source` | `https://schema.org/` |
| International Address | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| International Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-g6qfe9l84vekq97kgvhtu3qw` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| Postal Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Postal Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/postal-code` |
| Postal Code | `dcterms:source` | `https://schema.org/` |
| Postal Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| Postal Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kgbwgi00bhxyyt176bsmulf0` |
| Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/region-name` |
| Region Name | `dcterms:source` | `https://schema.org/` |
| Region Name | `skos:exactMatch` | `https://schema.org/addressRegion` |
| Region Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fvgk640ozbukdci5swd6wytt` |
| Address Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Address Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-use` |
| Address Use | `skos:exactMatch` | `http://hl7.org/fhir/address-use` |
| Address Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-offwpyuzrbirkryvvbzqqg31` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Geolocation | `dcterms:publisher` | `https://axius-sdc.com` |
| Geolocation | `dcterms:identifier` | `https://axius-sdc.com/library/default/geolocation` |
| Geolocation | `dcterms:source` | `https://schema.org/` |
| Geolocation | `skos:exactMatch` | `https://schema.org/GeoCoordinates` |
| Geodetic Datum | `dcterms:publisher` | `https://axius-sdc.com` |
| Geodetic Datum | `dcterms:source` | `https://epsg.org/` |
| Geodetic Datum | `dcterms:identifier` | `https://axius-sdc.com/library/default/geodetic-datum` |
| Geodetic Datum | `skos:closeMatch` | `http://www.wikidata.org/entity/Q182643` |
| Altitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Altitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/altitude` |
| Altitude | `dcterms:source` | `http://qudt.org/` |
| Altitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Altitude` |
| Altitude | `skos:exactMatch` | `https://schema.org/elevation` |
| Latitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Latitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/latitude` |
| Latitude | `dcterms:source` | `http://qudt.org/` |
| Latitude | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68642` |
| Latitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Angle` |
| Latitude | `skos:exactMatch` | `https://schema.org/latitude` |
| Latitude | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sws9fskrdla5e99x7cn4trwo` |
| Longitude | `dcterms:publisher` | `https://axius-sdc.com` |
| Longitude | `dcterms:identifier` | `https://axius-sdc.com/library/default/longitude` |
| Longitude | `dcterms:source` | `http://qudt.org/` |
| Longitude | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68643` |
| Longitude | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Angle` |
| Longitude | `skos:exactMatch` | `https://schema.org/longitude` |
| Longitude | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ecyu6tt7kkjq4rzhthe74ed6` |
| Locale | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale` |
| Locale | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleType` |
| Locale Census Block ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Census Block ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-census-block-id` |
| Locale Census Block ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Census Block ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCensusBlockID` |
| Locale Census Tract ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Census Tract ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-census-tract-id` |
| Locale Census Tract ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Census Tract ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCensusTractID` |
| Locale Community Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Community Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-community-name` |
| Locale Community Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Community Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleCommunityName` |
| Locale Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Description | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-description` |
| Locale Description | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Description | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleDescriptionText` |
| Locale District Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale District Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-district-name` |
| Locale District Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale District Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleDistrictName` |
| Locale Emergency Services Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Emergency Services Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-emergency-services-jurisdiction-id` |
| Locale Emergency Services Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Emergency Services Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleEmergencyServicesJurisdictionID` |
| Locale Emergency Services Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Emergency Services Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-emergency-services-name` |
| Locale Emergency Services Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Emergency Services Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleEmergencyServicesName` |
| Locale Fire Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Fire Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-fire-jurisdiction-id` |
| Locale Fire Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Fire Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleFireJurisdictionID` |
| Locale Judicial District Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Judicial District Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-judicial-district-name` |
| Locale Judicial District Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Judicial District Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleJudicialDistrictName` |
| Locale Neighborhood Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Neighborhood Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-neighborhood-name` |
| Locale Neighborhood Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Neighborhood Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleNeighborhoodName` |
| Locale Police Beat | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Beat | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-beat` |
| Locale Police Beat | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Beat | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceBeatText` |
| Locale Police Grid | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Grid | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-grid` |
| Locale Police Grid | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Grid | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceGridText` |
| Locale Police Jurisdiction ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Police Jurisdiction ID | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-police-jurisdiction-id` |
| Locale Police Jurisdiction ID | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Police Jurisdiction ID | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocalePoliceJurisdictionID` |
| Locale Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-region-name` |
| Locale Region Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Region Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleRegionName` |
| Locale Subdivision Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Subdivision Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-subdivision-name` |
| Locale Subdivision Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Subdivision Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleSubdivisionName` |
| Locale Zone Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Locale Zone Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/locale-zone-name` |
| Locale Zone Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Locale Zone Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/LocaleZoneName` |
| Property Transfer | `dcterms:publisher` | `https://axius-sdc.com` |
| Property Transfer | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Property Transfer | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/property-transfer` |
| Property Transfer | `skos:closeMatch` | `https://schema.org/ItemList` |
| Property Transfer | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vdf0oczbk8uxsm2le09l27ke` |
| Ownership Type | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q114829385` |
| Ownership Type | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Ownership Type | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Transfer Amount | `rdfs:isDefinedBy` | `https://schema.org/MonetaryAmount` |
| Transfer Amount | `skos:broadMatch` | `http://qudt.org/vocab/quantitykind/Currency` |
| Transfer Amount | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q56139218` |
| Ownership Start Date | `skos:broadMatch` | `https://schema.org/Date` |
| Ownership Start Date | `rdfs:isDefinedBy` | `http://schema.org/startDate` |
| Transfer Date | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q5347252` |
| Transfer Date | `skos:broadMatch` | `https://schema.org/Date` |
| Property Value Assessment | `dcterms:publisher` | `https://axius-sdc.com` |
| Property Value Assessment | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Property Value Assessment | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/property-value-assessment` |
| Property Value Assessment | `skos:closeMatch` | `https://schema.org/ItemList` |
| Property Value Assessment | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-cexrgb7uy29kn6w27tpmujtv` |
| Assessment Status | `rdfs:isDefinedBy` | `http://schema.org/ActionStatusType` |
| Assessment Status | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Assessment Status | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Assessed Value | `rdfs:isDefinedBy` | `https://schema.org/MonetaryAmount` |
| Assessed Value | `skos:broadMatch` | `http://qudt.org/vocab/quantitykind/Currency` |
| Assessed Value | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q512599` |
| Area | `dcterms:publisher` | `https://axius-sdc.com` |
| Area | `dcterms:identifier` | `https://axius-sdc.com/library/default/area` |
| Area | `dcterms:source` | `http://qudt.org/` |
| Area | `skos:exactMatch` | `http://qudt.org/vocab/quantitykind/Area` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "Property Registry 4.4.0" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-goc13fg5a97ghcqv64h782af.xsd)
- Example instance (dm-goc13fg5a97ghcqv64h782af.xml)
- HTML documentation (dm-goc13fg5a97ghcqv64h782af.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"Property Registry 4.4.0" SDC4 schema (dm-goc13fg5a97ghcqv64h782af.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"Property Registry 4.4.0" schema (dm-goc13fg5a97ghcqv64h782af.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "Property Registry 4.4.0" SDC4 schema (dm-goc13fg5a97ghcqv64h782af.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "Property Registry 4.4.0" data model (dm-goc13fg5a97ghcqv64h782af.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-goc13fg5a97ghcqv64h782af.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-goc13fg5a97ghcqv64h782af.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-goc13fg5a97ghcqv64h782af.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-goc13fg5a97ghcqv64h782af.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-goc13fg5a97ghcqv64h782af.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
