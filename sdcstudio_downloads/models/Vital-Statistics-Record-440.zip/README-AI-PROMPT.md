# Vital Statistics Record 4.4.0

**Model ID**: `dm-sokc3go551qsp4s72lo6ys9c`
**Project**: Cordova
**Description**: Maintain the authoritative registry of life events in Cordova.

### Dublin Core Metadata
- **Subject**: Vital Statistics
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal
- **Publisher**: Axius SDC, Inc.

## Package Contents

- `dm-sokc3go551qsp4s72lo6ys9c.xsd` -- XML Schema Definition (data model structure)
- `dm-sokc3go551qsp4s72lo6ys9c.xml` -- XML instance example with sample data
- `dm-sokc3go551qsp4s72lo6ys9c-instance.json` -- JSON instance example (same structure as XML)
- `dm-sokc3go551qsp4s72lo6ys9c.jsonld` -- JSON-LD semantic schema description
- `dm-sokc3go551qsp4s72lo6ys9c.html` -- Human-readable model documentation
- `dm-sokc3go551qsp4s72lo6ys9c_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-sokc3go551qsp4s72lo6ys9c.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-sokc3go551qsp4s72lo6ys9c.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-sokc3go551qsp4s72lo6ys9c.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-sokc3go551qsp4s72lo6ys9c.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **Vital Statistics Governed Record** | Cluster | `b45zgli90sy6lohbyubjk3sq` | 1 components; 4 sub-cluster(s) |
|   Digital Signature Proof | XdFile | `gug5dhtqfv7exbgmm2raxpkq` | -- |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |
|   **Vital Event** | Cluster | `dfitqmq2as6ttu6q5004jnxv` | 7 components; 4 sub-cluster(s) |
|     Certificate Number | XdString | `ajfsyoyrz38094hswxh13i3x` | minLen=1; maxLen=50 |
|     City | XdToken | `atdtdfzruh7tya0iv5cz365l` | 9 enum(s) |
|     Event Type | XdToken | `jz7vc6ikueqig8g0lvb2czzr` | 4 enum(s) |
|     Province | XdToken | `kv5qqs3o4jwcwz9javgw1pzh` | 3 enum(s) |
|     Record Status | XdToken | `yri6g628ipi0jqoa0ijnzxxu` | 3 enum(s) |
|     Event Date | XdTemporal | `e3sfb43zh1vjlgceb5guh0mj` | -- |
|     Registration Date | XdTemporal | `vo9jtmexkaaol3y657fm0xn8` | -- |
|     **Birth Record** | Cluster | `r9b12bwve6bbeyw9ib3k4nn0` | 4 components; 1 sub-cluster(s) |
|       Birth Facility | XdString | `m21mv7pyouct7a4uxgkxzj54` | minLen=1; maxLen=200 |
|       National ID (CID) | XdString | `nj7s1gk45tfgyooxpz0qaha3` | exactLen=16; pattern=`COR-(AL|BR|CE)0[1-3]-[0-9]{6}` |
|       Sex (Recorded) | XdToken | `k23bvcgmc8clpad6tpkpngu0` | 4 enum(s) |
|       Date of Birth | XdTemporal | `js564tazefb6udqlh12rj04l` | -- |
|       **Person Name (NIEM)** | Cluster | `lsdkohl5wl6z1zr0jmrqes9g` | 7 components; 1 sub-cluster(s) |
|         Person Maiden Name | XdString | `cnzj3ios9huld8zie5s0owdr` | maxLen=255 |
|         Person Name Salutation | XdString | `a2jxt7hvgtgl63n2qd1ebhi2` | maxLen=4000 |
|         Person Official Given Name | XdString | `gblsu8lmv6tx3qrp36lhmo0y` | maxLen=255 |
|         Person Preferred Name | XdString | `m2xu9d43k8xjng7n9vt7ggz2` | maxLen=255 |
|         Person Sur Name Prefix | XdString | `v50gp8o31f1u0p5evnjgezbk` | maxLen=4000 |
|         Person Name Category Code | XdToken | `jgwnnjpxifxgrkws2powhftp` | 4 enum(s) |
|         Effective Date | XdTemporal | `wumhbfo7ckp3f0n0vsjzhq3q` | -- |
|         **Full Name (Person)** | Cluster | `ytw6qjtq5gilrvkfsohsrlkh` | 6 components |
|           Given Name (Person) | XdString | `l9l169co9r23e6fftpvdz4e3` | minLen=1; maxLen=100 |
|           Middle Name (Person) | XdString | `zcf4f5kjjo497jeb9vtt9rmr` | minLen=1; maxLen=100 |
|           Name Prefix | XdString | `yahxccv0l1z6ykjxayzkdlkq` | maxLen=20 |
|           Name Suffix | XdString | `l509t0zajfl5atns64d5kl97` | maxLen=20 |
|           Surname (Person) | XdString | `jc1lfk3ovt6l8frhxvx8b669` | minLen=1; maxLen=100 |
|           Name Use | XdToken | `bfqinvm7qrgi9jjw1i637moh` | 7 enum(s) |
|     **Death Record** | Cluster | `ngn42fw0tdhtnenvrbuxlk24` | 4 components; 2 sub-cluster(s) |
|       National ID (CID) | XdString | `nj7s1gk45tfgyooxpz0qaha3` | exactLen=16; pattern=`COR-(AL|BR|CE)0[1-3]-[0-9]{6}` |
|       Manner of Death | XdToken | `ftuxt5nrrffwjb2vymn80yx2` | 6 enum(s) |
|       Place of Death | XdToken | `dsoyfaplxw8ide1opo5w8fxg` | 3 enum(s) |
|       Person Death Date | XdTemporal | `tdy3p61df18rg09tgipjx4sm` | -- |
|       **Diagnosis (ICD-10-CM)** | Cluster | `jk4cboqk4me0yj2i04m8c2ad` | 3 components |
|         Code System: ICD-10-CM | XdLink | `jwgx8nvbtsim7ck4uqmpqyl2` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Diagnosis Code (ICD-10-CM) | XdString | `efimv7gxg5ompt8m6xb2b6k5` | maxLen=40; pattern=`[A-TV-Z][0-9][0-9AB](\.[0-9A-TV-Z]{1,4})?` |
|     **Divorce Record** | Cluster | `tbchrry02w3gs6fhgihh1og8` | 3 components; 1 sub-cluster(s) |
|       Marriage Certificate Number | XdString | `ycujkecjszwwrcd6dhxesk73` | minLen=1; maxLen=50 |
|       National ID (CID) | XdString | `nj7s1gk45tfgyooxpz0qaha3` | exactLen=16; pattern=`COR-(AL|BR|CE)0[1-3]-[0-9]{6}` |
|       Decree Date | XdTemporal | `ft4kk6m3r1goxkte0d7wflk8` | -- |
|     **Marriage Record** | Cluster | `uj4jkz29qdjfjm48fm8q2fr9` | 3 components; 1 sub-cluster(s) |
|       Marriage Certificate Number | XdString | `ycujkecjszwwrcd6dhxesk73` | minLen=1; maxLen=50 |
|       National ID (CID) | XdString | `nj7s1gk45tfgyooxpz0qaha3` | exactLen=16; pattern=`COR-(AL|BR|CE)0[1-3]-[0-9]{6}` |
|       Officiant Title | XdString | `hrf8anjydeb8rl6x3wv26r73` | minLen=1; maxLen=200 |

## Structural Hierarchy

```
DM: Vital Statistics Record 4.4.0
  [Cluster] Vital Statistics Governed Record
    [XdFile] Digital Signature Proof
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
    [Cluster] Vital Event
      [XdString] Certificate Number
      [XdToken] City
      [XdToken] Event Type
      [XdToken] Province
      [XdToken] Record Status
      [XdTemporal] Event Date
      [XdTemporal] Registration Date
      [Cluster] Birth Record
        [XdString] Birth Facility
        [XdString] National ID (CID)
        [XdToken] Sex (Recorded)
        [XdTemporal] Date of Birth
        [Cluster] Person Name (NIEM)
          [XdString] Person Maiden Name
          [XdString] Person Name Salutation
          [XdString] Person Official Given Name
          [XdString] Person Preferred Name
          [XdString] Person Sur Name Prefix
          [XdToken] Person Name Category Code
          [XdTemporal] Effective Date
          [Cluster] Full Name (Person)
            [XdString] Given Name (Person)
            [XdString] Middle Name (Person)
            [XdString] Name Prefix
            [XdString] Name Suffix
            [XdString] Surname (Person)
            [XdToken] Name Use
      [Cluster] Death Record
        [XdString] National ID (CID)
        [XdToken] Manner of Death
        [XdToken] Place of Death
        [XdTemporal] Person Death Date
        [Cluster] Diagnosis (ICD-10-CM)
          [XdLink] Code System: ICD-10-CM
          [XdString] Code Display Text
          [XdString] Diagnosis Code (ICD-10-CM)
        [Cluster] Person Name (NIEM) (circular ref)
      [Cluster] Divorce Record
        [XdString] Marriage Certificate Number
        [XdString] National ID (CID)
        [XdTemporal] Decree Date
        [Cluster] Person Name (NIEM) (circular ref)
      [Cluster] Marriage Record
        [XdString] Marriage Certificate Number
        [XdString] National ID (CID)
        [XdString] Officiant Title
        [Cluster] Person Name (NIEM) (circular ref)
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Vital Statistics Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Vital Statistics Governed Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Vital Statistics Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/vital-statistics-governed-record` |
| Vital Statistics Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Vital Statistics Governed Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-r2g662g70dx34eq12v9n4ng7` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.w3.org/TR/vc-data-model/#credentials` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q210824` |
| Digital Signature Proof | `skos:broadMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |
| Vital Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Vital Event | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Vital Event | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/vital-event` |
| Vital Event | `skos:exactMatch` | `https://schema.org/Event` |
| Vital Event | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tard9hhq13m95hinbh4h7k5j` |
| Certificate Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q108891191` |
| Certificate Number | `skos:broadMatch` | `https://schema.org/identifier` |
| City | `rdfs:isDefinedBy` | `http://schema.org/City` |
| City | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| City | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Event Type | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q108586636` |
| Event Type | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Event Type | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Province | `rdfs:isDefinedBy` | `http://schema.org/AdministrativeArea` |
| Province | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Province | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Province | `rdfs:isDefinedBy` | `https://schema.org/State` |
| Record Status | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q65720124` |
| Record Status | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Record Status | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Event Date | `skos:broadMatch` | `https://schema.org/Date` |
| Event Date | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q7911665` |
| Registration Date | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q137375576` |
| Registration Date | `skos:broadMatch` | `https://schema.org/Date` |
| Birth Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Birth Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Birth Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/birth-record` |
| Birth Record | `skos:exactMatch` | `https://schema.org/birthDate` |
| Birth Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-az8kem3v58y9zenys7mthqxe` |
| Birth Facility | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1322263` |
| Birth Facility | `skos:broadMatch` | `https://schema.org/name` |
| National ID (CID) | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| National ID (CID) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1140371` |
| National ID (CID) | `skos:broadMatch` | `https://schema.org/identifier` |
| Sex (Recorded) | `dcterms:publisher` | `https://axius-sdc.com` |
| Sex (Recorded) | `dcterms:identifier` | `https://axius-sdc.com/library/default/sex-recorded` |
| Sex (Recorded) | `dcterms:source` | `https://ncithesaurus.nci.nih.gov/` |
| Sex (Recorded) | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C28421` |
| Date of Birth | `dcterms:publisher` | `https://axius-sdc.com` |
| Date of Birth | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-of-birth` |
| Date of Birth | `dcterms:source` | `https://schema.org/` |
| Date of Birth | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68615` |
| Date of Birth | `skos:exactMatch` | `https://schema.org/birthDate` |
| Person Name (NIEM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Name (NIEM) | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-name` |
| Person Name (NIEM) | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Person Name (NIEM) | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonNameType` |
| Person Name (NIEM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-z66oajf345nq7leq3xaqxfmx` |
| Person Maiden Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Maiden Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-maiden-name` |
| Person Maiden Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Person Maiden Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonMaidenName` |
| Person Name Salutation | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Name Salutation | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-name-salutation` |
| Person Name Salutation | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Person Name Salutation | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonNameSalutationText` |
| Person Official Given Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Official Given Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-official-given-name` |
| Person Official Given Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Person Official Given Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonOfficialGivenName` |
| Person Preferred Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Preferred Name | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-preferred-name` |
| Person Preferred Name | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Person Preferred Name | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonPreferredName` |
| Person Sur Name Prefix | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Sur Name Prefix | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-sur-name-prefix` |
| Person Sur Name Prefix | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Person Sur Name Prefix | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonSurNamePrefixText` |
| Person Name Category Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Name Category Code | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-name-category-code` |
| Person Name Category Code | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Person Name Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonNameCategoryCode` |
| Person Name Category Code | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonNameCategoryCodeSimpleType` |
| Effective Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Effective Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/effective-date` |
| Effective Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Effective Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/EffectiveDate` |
| Full Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Full Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/full-name-person` |
| Full Name (Person) | `dcterms:source` | `https://schema.org/` |
| Full Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q1071027` |
| Full Name (Person) | `skos:exactMatch` | `https://schema.org/Person` |
| Full Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gwpvlduwrtpog4kpidaenshn` |
| Given Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Given Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/given-name-person` |
| Given Name (Person) | `dcterms:source` | `https://schema.org/` |
| Given Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q202444` |
| Given Name (Person) | `skos:exactMatch` | `https://schema.org/givenName` |
| Given Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kfyzf8u8gdafcpt5kfh2qg3q` |
| Middle Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Middle Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/middle-name-person` |
| Middle Name (Person) | `dcterms:source` | `https://schema.org/` |
| Middle Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q245025` |
| Middle Name (Person) | `skos:exactMatch` | `https://schema.org/additionalName` |
| Middle Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-oit0ueglhjfcyq80z22kl2z3` |
| Name Prefix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Prefix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-prefix` |
| Name Prefix | `dcterms:source` | `https://schema.org/` |
| Name Prefix | `skos:exactMatch` | `https://schema.org/honorificPrefix` |
| Name Prefix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-u9x2b6frfi0rbydeoncijfp1` |
| Name Suffix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Suffix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-suffix` |
| Name Suffix | `dcterms:source` | `https://schema.org/` |
| Name Suffix | `skos:exactMatch` | `https://schema.org/honorificSuffix` |
| Name Suffix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zldtbpvyouzi7t1dorc07rb3` |
| Surname (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Surname (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/surname-person` |
| Surname (Person) | `dcterms:source` | `https://schema.org/` |
| Surname (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q101352` |
| Surname (Person) | `skos:exactMatch` | `https://schema.org/familyName` |
| Surname (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-v8jgjo2sml12jo7zrb8swoxi` |
| Name Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Name Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-use` |
| Name Use | `skos:exactMatch` | `http://hl7.org/fhir/name-use` |
| Name Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zlg3riiu515tsg0mdkx5brkc` |
| Death Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Death Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Death Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/death-record` |
| Death Record | `skos:exactMatch` | `https://schema.org/deathDate` |
| Death Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tdz3pxrf7k6z2df2bfm7ebcp` |
| National ID (CID) | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| National ID (CID) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1140371` |
| National ID (CID) | `skos:broadMatch` | `https://schema.org/identifier` |
| Manner of Death | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q2438541` |
| Manner of Death | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Manner of Death | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Place of Death | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q18658526` |
| Place of Death | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Place of Death | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Person Death Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Person Death Date | `dcterms:identifier` | `https://axius-sdc.com/library/niem/person-death-date` |
| Person Death Date | `dcterms:source` | `https://docs.oasis-open.org/niemopen/niem-model/v6.0/ps02/xsd/niem-core.xsd` |
| Person Death Date | `skos:exactMatch` | `https://docs.oasis-open.org/niemopen/ns/model/niem-core/6.0/PersonDeathDate` |
| Diagnosis (ICD-10-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis (ICD-10-CM) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Diagnosis (ICD-10-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diagnosis-icd10cm` |
| Diagnosis (ICD-10-CM) | `skos:closeMatch` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Diagnosis (ICD-10-CM) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.code` |
| Code System: ICD-10-CM | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: ICD-10-CM | `dcterms:source` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Code System: ICD-10-CM | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-icd10cm` |
| Code System: ICD-10-CM | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Diagnosis Code (ICD-10-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis Code (ICD-10-CM) | `dcterms:source` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Diagnosis Code (ICD-10-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diagnosis-icd10cm-code` |
| Diagnosis Code (ICD-10-CM) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.code` |
| Diagnosis Code (ICD-10-CM) | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Diagnosis Code (ICD-10-CM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gnssdkny454dgbykbs16wuew` |
| Divorce Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Divorce Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Divorce Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/divorce-record` |
| Divorce Record | `skos:closeMatch` | `https://schema.org/ItemList` |
| Divorce Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-obybok0oaoa79b11b0ync1zf` |
| Marriage Certificate Number | `skos:broadMatch` | `https://www.wikidata.org/wiki/Q820655` |
| Marriage Certificate Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1299632` |
| National ID (CID) | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| National ID (CID) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1140371` |
| National ID (CID) | `skos:broadMatch` | `https://schema.org/identifier` |
| Decree Date | `rdfs:isDefinedBy` | `http://release.niem.gov/niem/niem-core/5.0/DocumentIssueDate` |
| Decree Date | `skos:broadMatch` | `https://schema.org/Date` |
| Marriage Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Marriage Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Marriage Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/marriage-record` |
| Marriage Record | `skos:closeMatch` | `https://schema.org/ItemList` |
| Marriage Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-chtyne5i6qcwbrby29vbuh2k` |
| Marriage Certificate Number | `skos:broadMatch` | `https://www.wikidata.org/wiki/Q820655` |
| Marriage Certificate Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1299632` |
| National ID (CID) | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| National ID (CID) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1140371` |
| National ID (CID) | `skos:broadMatch` | `https://schema.org/identifier` |
| Officiant Title | `rdfs:isDefinedBy` | `http://schema.org/jobTitle` |
| Officiant Title | `skos:broadMatch` | `https://schema.org/name` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "Vital Statistics Record 4.4.0" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-sokc3go551qsp4s72lo6ys9c.xsd)
- Example instance (dm-sokc3go551qsp4s72lo6ys9c.xml)
- HTML documentation (dm-sokc3go551qsp4s72lo6ys9c.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"Vital Statistics Record 4.4.0" SDC4 schema (dm-sokc3go551qsp4s72lo6ys9c.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"Vital Statistics Record 4.4.0" schema (dm-sokc3go551qsp4s72lo6ys9c.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "Vital Statistics Record 4.4.0" SDC4 schema (dm-sokc3go551qsp4s72lo6ys9c.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "Vital Statistics Record 4.4.0" data model (dm-sokc3go551qsp4s72lo6ys9c.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-sokc3go551qsp4s72lo6ys9c.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-sokc3go551qsp4s72lo6ys9c.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-sokc3go551qsp4s72lo6ys9c.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-sokc3go551qsp4s72lo6ys9c.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-sokc3go551qsp4s72lo6ys9c.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
