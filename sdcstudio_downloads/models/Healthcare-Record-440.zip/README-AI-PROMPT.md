# Healthcare Record 4.4.0

**Model ID**: `dm-dcsd8bxr8a6lzcptwwyms44t`
**Project**: Cordova
**Description**: Maintain basic medical records for all persons in Cordova.

### Dublin Core Metadata
- **Subject**: Healthcare Record
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal
- **Publisher**: Axius SDC, Inc.

## Package Contents

- `dm-dcsd8bxr8a6lzcptwwyms44t.xsd` -- XML Schema Definition (data model structure)
- `dm-dcsd8bxr8a6lzcptwwyms44t.xml` -- XML instance example with sample data
- `dm-dcsd8bxr8a6lzcptwwyms44t-instance.json` -- JSON instance example (same structure as XML)
- `dm-dcsd8bxr8a6lzcptwwyms44t.jsonld` -- JSON-LD semantic schema description
- `dm-dcsd8bxr8a6lzcptwwyms44t.html` -- Human-readable model documentation
- `dm-dcsd8bxr8a6lzcptwwyms44t_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-dcsd8bxr8a6lzcptwwyms44t.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-dcsd8bxr8a6lzcptwwyms44t.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-dcsd8bxr8a6lzcptwwyms44t.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-dcsd8bxr8a6lzcptwwyms44t.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **Healthcare Governed Record** | Cluster | `ffh1o5rta29osqbm0jg7a1l7` | 1 components; 4 sub-cluster(s) |
|   Digital Signature Proof | XdFile | `gug5dhtqfv7exbgmm2raxpkq` | -- |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **Patient Record** | Cluster | `yyrztf21qkyi0xk612rzxfzd` | 1 components; 7 sub-cluster(s) |
|     National ID (CID) | XdString | `nj7s1gk45tfgyooxpz0qaha3` | exactLen=16; pattern=`COR-(AL|BR|CE)0[1-3]-[0-9]{6}` |
|     **Allergy Intolerance** | Cluster | `yeaa0k87yietfbfonbr4wgqs` | 9 components; 2 sub-cluster(s) |
|       Allergy Note | XdString | `q8unjlqm15pc443iclif64on` | maxLen=4000 |
|       Allergy Category | XdToken | `ludhh6euu3lc99wpik2pyjcc` | 4 enum(s) |
|       Allergy Clinical Status | XdToken | `gvahkpl47rdq5nv27sokv05f` | 3 enum(s) |
|       Allergy Criticality | XdToken | `sku0vf9wdpful1lrthu2eyyd` | 3 enum(s) |
|       Allergy Type | XdToken | `pnuuxh2172pozj03h5hxyfgb` | 2 enum(s) |
|       Allergy Verification Status | XdToken | `p39nkyal7bbx36vs8raozozz` | 4 enum(s) |
|       Allergy Onset Date | XdTemporal | `lvms8v52hnfpiqinfbwwtw37` | -- |
|       Allergy Recorded Date | XdTemporal | `ivpplvmgnxhdyqtax1ipdzwu` | -- |
|       Last Reaction Date | XdTemporal | `mrti6abfhdeferd4xsm9kz1b` | -- |
|       **Allergen (SNOMED CT)** | Cluster | `rjzh4p0afw8eqsmfqvdlgh30` | 3 components |
|         Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|         Allergen Code (SNOMED CT) | XdString | `y16hwsqc3wjfn8pc16gnbdvv` | maxLen=40; pattern=`[0-9]{6,18}` |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|       **Allergy Reaction** | Cluster | `t6s62iijsont6r7h2xss3i81` | 3 components; 3 sub-cluster(s) |
|         Reaction Description | XdString | `mf5zu92mgdam65gs9djp1t4g` | maxLen=4000 |
|         Reaction Severity | XdToken | `kmy0slqyv5ztfu0bevpz9zv1` | 3 enum(s) |
|         Reaction Onset | XdTemporal | `m11tmjzf44tof6c48hnjxbz3` | -- |
|         **Exposure Route (SNOMED CT)** | Cluster | `dnxnysrxf7fa59c52bi6cowy` | 3 components |
|           Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|           Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|           Exposure Route Code (SNOMED CT) | XdString | `h0bvntw0ad89wpdpf2jys47k` | maxLen=40; pattern=`[0-9]{6,18}` |
|         **Reaction Manifestation (SNOMED CT)** | Cluster | `j1bdmep57zuwign9kec5o3x8` | 3 components |
|           Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|           Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|           Reaction Manifestation Code (SNOMED CT) | XdString | `jtblqgn629vsvw007hgm2oik` | maxLen=40; pattern=`[0-9]{6,18}` |
|         **Reaction Substance (SNOMED CT)** | Cluster | `vdesx5dijp738m2a134rhosl` | 3 components |
|           Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|           Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|           Reaction Substance Code (SNOMED CT) | XdString | `jml0ks91rhylvkyjkp4tgi3c` | maxLen=40; pattern=`[0-9]{6,18}` |
|     **Condition** | Cluster | `gus7i559nu8qnrmy86tn9ih3` | 5 components; 3 sub-cluster(s) |
|       Condition Category | XdToken | `omljcynidrw37kgl9cmayi16` | 2 enum(s) |
|       Condition Clinical Status | XdToken | `gedv32ehs79son03jwbo6meg` | 6 enum(s) |
|       Condition Verification Status | XdToken | `al2zqxi3n5tqxc9zsh6cee0w` | 6 enum(s) |
|       Abatement Date | XdTemporal | `rf9lf370z6ynvfu36wlvw35x` | -- |
|       Onset Date | XdTemporal | `cdt3eno621fle59qg7k0ojr4` | -- |
|       **Condition Severity (SNOMED CT)** | Cluster | `k97rf7pd7y72z48d57x2j7to` | 3 components |
|         Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Condition Severity Code (SNOMED CT) | XdString | `vbuzhg8ibermpz3xxmyx5gbv` | maxLen=40; pattern=`[0-9]{6,18}` |
|       **Diagnosis (ICD-10-CM)** | Cluster | `jk4cboqk4me0yj2i04m8c2ad` | 3 components |
|         Code System: ICD-10-CM | XdLink | `jwgx8nvbtsim7ck4uqmpqyl2` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Diagnosis Code (ICD-10-CM) | XdString | `efimv7gxg5ompt8m6xb2b6k5` | maxLen=40; pattern=`[A-TV-Z][0-9][0-9AB](\.[0-9A-TV-Z]{1,4})?` |
|       **Diagnosis (SNOMED CT)** | Cluster | `fv8e2asumlgp9l4o9p3i2jsf` | 3 components |
|         Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Diagnosis Code (SNOMED CT) | XdString | `khpm67tzpl0myig6xgvwczpx` | maxLen=40; pattern=`[0-9]{6,18}` |
|     **Encounter** | Cluster | `rghkif2x2xhe0e82mc85qwvm` | 6 components; 2 sub-cluster(s) |
|       Encounter Class | XdToken | `f8vsfzqb1m8ecfosdzhc9out` | 11 enum(s) |
|       Encounter Priority | XdToken | `jcsoakfsmdndfvw6p0nh879m` | 15 enum(s) |
|       Encounter Status | XdToken | `mpkqsp6zn1gbc1zhqai9y40b` | 9 enum(s) |
|       Encounter Length | XdQuantity | `gdcfl9ghwkswdbmxww4senbt` | units=Time Units |
|       Encounter End | XdTemporal | `pkren9mdq1ve6mdcn5hdu4xq` | -- |
|       Encounter Start | XdTemporal | `anbcg4rhacgmv8lkfofymmv0` | -- |
|       **Encounter Reason (SNOMED CT)** | Cluster | `u6u23oip0dinxve95ub0kwma` | 3 components |
|         Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Encounter Reason Code (SNOMED CT) | XdString | `cmtzyf0esp2hbf8ze2q0d3bh` | maxLen=40; pattern=`[0-9]{6,18}` |
|       **Hospitalization** | Cluster | `fnxiiamw1uk1hvsxmjgsu1xy` | 2 components |
|         Admit Source | XdToken | `awvbv44gmq5co6prxcnhdz09` | 10 enum(s) |
|         Discharge Disposition | XdToken | `wd1txyosw8ha21sohphne92e` | 11 enum(s) |
|     **Immunization** | Cluster | `qu29fbyziraov263ga9mpzqk` | 9 components; 4 sub-cluster(s) |
|       Is Subpotent | XdBoolean | `lt7xu3wvixu66e818ii8d3qf` | -- |
|       Primary Source Indicator | XdBoolean | `w3ym3y9yu0hzm4nzcpkalgug` | -- |
|       Immunization Note | XdString | `o44rw2x2h5twxv0exry40xld` | maxLen=4000 |
|       Vaccine Lot Number | XdString | `jwas9cfzfnv9sm42kaum11ry` | maxLen=64 |
|       Immunization Status | XdToken | `ftatuy5pcs3k2s1cmil9nb2d` | 3 enum(s) |
|       Injection Site | XdToken | `p3z2snw4ppeltxv8sf4g2z6g` | 56 enum(s) |
|       Dose Quantity Administered | XdQuantity | `evzi9namajsr73zvfmu6yk5n` | units=Dose Units |
|       Vaccination Date | XdTemporal | `z0tvxqq7rue6z6d1kc10numz` | -- |
|       Vaccine Expiration Date | XdTemporal | `oqr71irdt8saycxt7dmaza7h` | -- |
|       **Administration Route (SNOMED CT)** | Cluster | `c2ezzwg0q7fwuarfn7aiouyt` | 3 components |
|         Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|         Administration Route Code (SNOMED CT) | XdString | `j3gl4by3v02vva0vntjjoay5` | maxLen=40; pattern=`[0-9]{6,18}` |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|       **Immunization Reaction** | Cluster | `ksv53g8pkbx6u6bklv297cvf` | 2 components |
|         Immunization Reaction Reported | XdBoolean | `myydvf1ehbqoor9vaddpdvt1` | -- |
|         Immunization Reaction Date | XdTemporal | `ztndn12tfffpqywgqcx7mk4x` | -- |
|       **Vaccine (CVX)** | Cluster | `rjqnxs7c79unjaudwwbc5gye` | 3 components |
|         Code System: CVX | XdLink | `z32af7v9iahzr79olizcfu5s` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Vaccine Code (CVX) | XdString | `uot3qq1t3l45bhgqle8add8t` | maxLen=40; pattern=`[0-9]{1,3}` |
|       **Vaccine Protocol** | Cluster | `n1jgl05vzoekh3069ujw0obp` | 3 components; 1 sub-cluster(s) |
|         Protocol Series Name | XdString | `jvv615y8hoxm8k91jbnc6phw` | maxLen=255 |
|         Dose Number in Series | XdCount | `rhvtlnzhx0us7j4hmhgkdiz6` | units=Items |
|         Doses in Series | XdCount | `qtgpjcj7h89ts1yo528eitzu` | units=Items |
|         **Target Disease (SNOMED CT)** | Cluster | `qdrv0ncyx03ay4n7tte6inme` | 3 components |
|           Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|           Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|           Target Disease Code (SNOMED CT) | XdString | `mt8638gzmop40mv6u6251irh` | maxLen=40; pattern=`[0-9]{6,18}` |
|     **Medication Order** | Cluster | `hpjg3dmqr1yc27r2po4ffxi0` | 6 components; 3 sub-cluster(s) |
|       Prescriber Reference | XdString | `w7hbkej93xho09imq7f9hglr` | maxLen=2000; pattern=`\S+` |
|       Dose Frequency | XdToken | `ikja2z5kffq6hd5ljio3hzn6` | 12 enum(s) |
|       Medication Request Intent | XdToken | `e9i4r60oql8x8dlq7e9ff8nz` | 8 enum(s) |
|       Medication Request Status | XdToken | `he6sxdsnp6dgjc0somgx2m2v` | 8 enum(s) |
|       Dose Quantity | XdQuantity | `nwt80dp2we8k4r2goylvfxrj` | units=Dose Units |
|       Prescription Date | XdTemporal | `pq2ua8kgjfg3ugm1rkompjxd` | -- |
|       **Dispense Request** | Cluster | `ou1erxdrjvg7fd0jekomsyyl` | 3 components |
|         Substitution Allowed | XdBoolean | `v6bwjabmhxzl4m62cdmylkbi` | -- |
|         Dispense Quantity | XdCount | `g7dmkv2mq6b6j9i6wjzgp9px` | units=Items |
|         Number of Refills | XdCount | `ond4lfpjkr28o8zhx6ee1mea` | units=Items |
|       **Medication Route (SNOMED CT)** | Cluster | `oyz3k6rovf1ip7d91bdivgux` | 3 components |
|         Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Medication Route Code (SNOMED CT) | XdString | `dleacf69t8nyhv6qf3qel6vq` | maxLen=40; pattern=`[0-9]{6,18}` |
|       **Medication (RxNorm)** | Cluster | `jxjvqsheyabf3148aj60svvq` | 3 components |
|         Code System: RxNorm | XdLink | `hipwsqy6c4of62xr7ul4ksog` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Medication Code (RxNorm) | XdString | `zht48k1ocjm7ugkes1mpn3e6` | maxLen=40; pattern=`[0-9]{1,8}` |
|     **Patient** | Cluster | `sgbjo7daa5cvoc98ic0m91ud` | 9 components; 3 sub-cluster(s) |
|       Deceased Indicator | XdBoolean | `fnr5q1tfq42ez9jia9dqueho` | -- |
|       Language Preferred | XdBoolean | `atmov6klp3a57hmokoxlx77t` | -- |
|       Multiple Birth Indicator | XdBoolean | `oe6dnqrrspu4fffjs8jcrdur` | -- |
|       General Practitioner Reference | XdString | `ezb3mjzu7ya2vsrfkt00t8mu` | maxLen=2000; pattern=`\S+` |
|       Managing Organization Reference | XdString | `k1ahxtkgbqehv11vx9aw2fzz` | maxLen=2000; pattern=`\S+` |
|       Medical Record Number | XdString | `vxylrfo79n8ijkxeae68hhj4` | maxLen=64 |
|       Marital Status | XdToken | `z11vs0cvonack540omgwhxhz` | 11 enum(s) |
|       Multiple Birth Order | XdCount | `u9xinstuoneeuzzarqut6gtz` | units=Items |
|       Deceased Date | XdTemporal | `vnlhr9c3ykayyegumhb09snf` | -- |
|       **Contact Point** | Cluster | `d2xwhnb2vqzxw70jcizj9csx` | 6 components |
|         Website URL | XdLink | `wriny2gz8aqcvffmfpwbompk` | -- |
|         Email Address | XdString | `q922mqaon3yn5zlwf2bszf28` | maxLen=254; pattern=`.+@.+\..+` |
|         Fax Number | XdString | `ll6ltsnvakomixuitxkbkxfz` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|         Phone Number | XdString | `zpfwg52r88j6jdypj7rg71ke` | maxLen=20; pattern=`\+?\d[\d\s\-\(\)]{6,18}` |
|         Contact Method | XdToken | `miqo30r5b554nyj7ubryw43x` | 7 enum(s) |
|         Contact Use | XdToken | `vmruk4j9y1orvvz8cwafrax5` | 5 enum(s) |
|       **International Address** | Cluster | `upawqojmcfg3qsf4ffzi47ho` | 7 components |
|         Address (Line 1) | XdString | `ncxxt7wgs7soxw7kbmapxvg3` | maxLen=200 |
|         Address (Line 2) | XdString | `sexw93x5276zwsn1qx15htpv` | maxLen=200 |
|         City Name | XdString | `toysvef93azt57fgh8rwpd4b` | maxLen=100 |
|         Postal Code | XdString | `gf841eedvv6cjiegs934srai` | maxLen=15 |
|         Region Name | XdString | `jw1b9q6ulyte599sdsqp2mvp` | maxLen=100 |
|         Address Use | XdToken | `b25dj42zxhm19pih328ga8pl` | 5 enum(s) |
|         Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|       **Person (Demographics)** | Cluster | `vag4j8x1v4bp92xkmks7q4to` | 4 components; 1 sub-cluster(s) |
|         Administrative Gender | XdToken | `gxzbm758mhdz51xd4bawlfhh` | 4 enum(s) |
|         Country Code ISO 3166 | XdToken | `f2jicaigehz7xmwcp1gm5gh0` | 249 enum(s) |
|         Language Code | XdToken | `no649c8yiebkyujhlbwjuppx` | 184 enum(s) |
|         Date of Birth | XdTemporal | `js564tazefb6udqlh12rj04l` | -- |
|         **Full Name (Person)** | Cluster | `ytw6qjtq5gilrvkfsohsrlkh` | 6 components |
|           Given Name (Person) | XdString | `l9l169co9r23e6fftpvdz4e3` | minLen=1; maxLen=100 |
|           Middle Name (Person) | XdString | `zcf4f5kjjo497jeb9vtt9rmr` | minLen=1; maxLen=100 |
|           Name Prefix | XdString | `yahxccv0l1z6ykjxayzkdlkq` | maxLen=20 |
|           Name Suffix | XdString | `l509t0zajfl5atns64d5kl97` | maxLen=20 |
|           Surname (Person) | XdString | `jc1lfk3ovt6l8frhxvx8b669` | minLen=1; maxLen=100 |
|           Name Use | XdToken | `bfqinvm7qrgi9jjw1i637moh` | 7 enum(s) |
|     **Vital Signs Panel** | Cluster | `atvd5lzut4pjzc7dpv1ykb92` | 9 components; 1 sub-cluster(s) |
|       Observation Status | XdToken | `q9vmn1cvdclgr757aer5v1rg` | 8 enum(s) |
|       Body Height | XdQuantity | `z1ezf3vzksp7qpgd9l3uxvqo` | units=Length/Distance (SI - Metric) |
|       Body Mass Index | XdQuantity | `dchiej5tv7tyhfwr6h3ync1i` | units=Body Mass Index Units |
|       Body Temperature | XdQuantity | `ppqdmkbjmd3gn0p2i74ue3ox` | units=Temperature (SI - Metric) |
|       Body Weight | XdQuantity | `doxdajuj6j1mk480zd1k7ssz` | units=Mass/Weight (SI - Metric) |
|       Heart Rate | XdQuantity | `oy0jwif5pi86xtimzxzhapvu` | units=Rate |
|       Oxygen Saturation | XdQuantity | `htr0gulg01caowd76j6v4ukh` | units=Percentage |
|       Respiratory Rate | XdQuantity | `nzq70mbegncgc6hdfp7vtu46` | units=Rate |
|       Observation Date Time | XdTemporal | `dkyyj01tksb7h7akq2w7moum` | -- |
|       **Blood Pressure** | Cluster | `wyk9e1d74y5xrgv97o9y75ib` | 4 components; 1 sub-cluster(s) |
|         Observation Status | XdToken | `q9vmn1cvdclgr757aer5v1rg` | 8 enum(s) |
|         Diastolic Blood Pressure | XdQuantity | `s3qzwxxz9b42lcd2wryok8jd` | units=Pressure |
|         Systolic Blood Pressure | XdQuantity | `r1ve12xphsb5hu2yjmhksw5h` | units=Pressure |
|         Observation Date Time | XdTemporal | `dkyyj01tksb7h7akq2w7moum` | -- |
|         **Body Site (SNOMED CT)** | Cluster | `r5koa840csi3zcewts0uo0r5` | 3 components |
|           Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|           Body Site Code (SNOMED CT) | XdString | `vi7yvq0b8nler3g6alaamrzm` | maxLen=40; pattern=`[0-9]{6,18}` |
|           Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: Healthcare Record 4.4.0
  [Cluster] Healthcare Governed Record
    [XdFile] Digital Signature Proof
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] Patient Record
      [XdString] National ID (CID)
      [Cluster] Allergy Intolerance
        [XdString] Allergy Note
        [XdToken] Allergy Category
        [XdToken] Allergy Clinical Status
        [XdToken] Allergy Criticality
        [XdToken] Allergy Type
        [XdToken] Allergy Verification Status
        [XdTemporal] Allergy Onset Date
        [XdTemporal] Allergy Recorded Date
        [XdTemporal] Last Reaction Date
        [Cluster] Allergen (SNOMED CT)
          [XdLink] Code System: SNOMED CT
          [XdString] Allergen Code (SNOMED CT)
          [XdString] Code Display Text
        [Cluster] Allergy Reaction
          [XdString] Reaction Description
          [XdToken] Reaction Severity
          [XdTemporal] Reaction Onset
          [Cluster] Exposure Route (SNOMED CT)
            [XdLink] Code System: SNOMED CT
            [XdString] Code Display Text
            [XdString] Exposure Route Code (SNOMED CT)
          [Cluster] Reaction Manifestation (SNOMED CT)
            [XdLink] Code System: SNOMED CT
            [XdString] Code Display Text
            [XdString] Reaction Manifestation Code (SNOMED CT)
          [Cluster] Reaction Substance (SNOMED CT)
            [XdLink] Code System: SNOMED CT
            [XdString] Code Display Text
            [XdString] Reaction Substance Code (SNOMED CT)
      [Cluster] Condition
        [XdToken] Condition Category
        [XdToken] Condition Clinical Status
        [XdToken] Condition Verification Status
        [XdTemporal] Abatement Date
        [XdTemporal] Onset Date
        [Cluster] Condition Severity (SNOMED CT)
          [XdLink] Code System: SNOMED CT
          [XdString] Code Display Text
          [XdString] Condition Severity Code (SNOMED CT)
        [Cluster] Diagnosis (ICD-10-CM)
          [XdLink] Code System: ICD-10-CM
          [XdString] Code Display Text
          [XdString] Diagnosis Code (ICD-10-CM)
        [Cluster] Diagnosis (SNOMED CT)
          [XdLink] Code System: SNOMED CT
          [XdString] Code Display Text
          [XdString] Diagnosis Code (SNOMED CT)
      [Cluster] Encounter
        [XdToken] Encounter Class
        [XdToken] Encounter Priority
        [XdToken] Encounter Status
        [XdQuantity] Encounter Length
        [XdTemporal] Encounter End
        [XdTemporal] Encounter Start
        [Cluster] Encounter Reason (SNOMED CT)
          [XdLink] Code System: SNOMED CT
          [XdString] Code Display Text
          [XdString] Encounter Reason Code (SNOMED CT)
        [Cluster] Hospitalization
          [XdToken] Admit Source
          [XdToken] Discharge Disposition
      [Cluster] Immunization
        [XdBoolean] Is Subpotent
        [XdBoolean] Primary Source Indicator
        [XdString] Immunization Note
        [XdString] Vaccine Lot Number
        [XdToken] Immunization Status
        [XdToken] Injection Site
        [XdQuantity] Dose Quantity Administered
        [XdTemporal] Vaccination Date
        [XdTemporal] Vaccine Expiration Date
        [Cluster] Administration Route (SNOMED CT)
          [XdLink] Code System: SNOMED CT
          [XdString] Administration Route Code (SNOMED CT)
          [XdString] Code Display Text
        [Cluster] Immunization Reaction
          [XdBoolean] Immunization Reaction Reported
          [XdTemporal] Immunization Reaction Date
        [Cluster] Vaccine (CVX)
          [XdLink] Code System: CVX
          [XdString] Code Display Text
          [XdString] Vaccine Code (CVX)
        [Cluster] Vaccine Protocol
          [XdString] Protocol Series Name
          [XdCount] Dose Number in Series
          [XdCount] Doses in Series
          [Cluster] Target Disease (SNOMED CT)
            [XdLink] Code System: SNOMED CT
            [XdString] Code Display Text
            [XdString] Target Disease Code (SNOMED CT)
      [Cluster] Medication Order
        [XdString] Prescriber Reference
        [XdToken] Dose Frequency
        [XdToken] Medication Request Intent
        [XdToken] Medication Request Status
        [XdQuantity] Dose Quantity
        [XdTemporal] Prescription Date
        [Cluster] Dispense Request
          [XdBoolean] Substitution Allowed
          [XdCount] Dispense Quantity
          [XdCount] Number of Refills
        [Cluster] Medication Route (SNOMED CT)
          [XdLink] Code System: SNOMED CT
          [XdString] Code Display Text
          [XdString] Medication Route Code (SNOMED CT)
        [Cluster] Medication (RxNorm)
          [XdLink] Code System: RxNorm
          [XdString] Code Display Text
          [XdString] Medication Code (RxNorm)
      [Cluster] Patient
        [XdBoolean] Deceased Indicator
        [XdBoolean] Language Preferred
        [XdBoolean] Multiple Birth Indicator
        [XdString] General Practitioner Reference
        [XdString] Managing Organization Reference
        [XdString] Medical Record Number
        [XdToken] Marital Status
        [XdCount] Multiple Birth Order
        [XdTemporal] Deceased Date
        [Cluster] Contact Point
          [XdLink] Website URL
          [XdString] Email Address
          [XdString] Fax Number
          [XdString] Phone Number
          [XdToken] Contact Method
          [XdToken] Contact Use
        [Cluster] International Address
          [XdString] Address (Line 1)
          [XdString] Address (Line 2)
          [XdString] City Name
          [XdString] Postal Code
          [XdString] Region Name
          [XdToken] Address Use
          [XdToken] Country Code ISO 3166
        [Cluster] Person (Demographics)
          [XdToken] Administrative Gender
          [XdToken] Country Code ISO 3166
          [XdToken] Language Code
          [XdTemporal] Date of Birth
          [Cluster] Full Name (Person)
            [XdString] Given Name (Person)
            [XdString] Middle Name (Person)
            [XdString] Name Prefix
            [XdString] Name Suffix
            [XdString] Surname (Person)
            [XdToken] Name Use
      [Cluster] Vital Signs Panel
        [XdToken] Observation Status
        [XdQuantity] Body Height
        [XdQuantity] Body Mass Index
        [XdQuantity] Body Temperature
        [XdQuantity] Body Weight
        [XdQuantity] Heart Rate
        [XdQuantity] Oxygen Saturation
        [XdQuantity] Respiratory Rate
        [XdTemporal] Observation Date Time
        [Cluster] Blood Pressure
          [XdToken] Observation Status
          [XdQuantity] Diastolic Blood Pressure
          [XdQuantity] Systolic Blood Pressure
          [XdTemporal] Observation Date Time
          [Cluster] Body Site (SNOMED CT)
            [XdLink] Code System: SNOMED CT
            [XdString] Body Site Code (SNOMED CT)
            [XdString] Code Display Text
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Healthcare Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Healthcare Governed Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Healthcare Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/healthcare-governed-record` |
| Healthcare Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Healthcare Governed Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w0lu0us3nbxaedfum9i8itpc` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.w3.org/TR/vc-data-model/#credentials` |
| Digital Signature Proof | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q210824` |
| Digital Signature Proof | `skos:broadMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| Patient Record | `dcterms:publisher` | `https://axius-sdc.com` |
| Patient Record | `dcterms:source` | `https://github.com/Axius-SDC/CordovaOS` |
| Patient Record | `dcterms:identifier` | `https://axius-sdc.com/library/cordova/patient-record` |
| Patient Record | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Patient` |
| Patient Record | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ygtbvvmzcw3ukfsg3axqry97` |
| National ID (CID) | `rdfs:isDefinedBy` | `http://schema.org/identifier` |
| National ID (CID) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1140371` |
| National ID (CID) | `skos:broadMatch` | `https://schema.org/identifier` |
| Allergy Intolerance | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Intolerance | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Intolerance | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-intolerance` |
| Allergy Intolerance | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AllergyIntolerance` |
| Allergy Intolerance | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jg237gbd0oumwtcdmitblqyj` |
| Allergy Note | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Note | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Note | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-note` |
| Allergy Note | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.note` |
| Allergy Note | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hqhu62uxrukln0uzb4yvmibw` |
| Allergy Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Category | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Category | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-category` |
| Allergy Category | `skos:closeMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.category` |
| Allergy Category | `skos:exactMatch` | `http://hl7.org/fhir/allergy-intolerance-category` |
| Allergy Category | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dmzga6k8s3ewhptvgcw7bemy` |
| Allergy Clinical Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Clinical Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Clinical Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-clinical-status` |
| Allergy Clinical Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.clinicalStatus` |
| Allergy Clinical Status | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical` |
| Allergy Clinical Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-p85c9mgvp67mkjp817lg5ewb` |
| Allergy Criticality | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Criticality | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Criticality | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-criticality` |
| Allergy Criticality | `skos:closeMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.criticality` |
| Allergy Criticality | `skos:exactMatch` | `http://hl7.org/fhir/allergy-intolerance-criticality` |
| Allergy Criticality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-q352iktefdex7h51q9s8assi` |
| Allergy Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Type | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-type` |
| Allergy Type | `skos:closeMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.type` |
| Allergy Type | `skos:exactMatch` | `http://hl7.org/fhir/allergy-intolerance-type` |
| Allergy Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rlpsriyd64bu41j63fl8kmc7` |
| Allergy Verification Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Verification Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Verification Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-verification-status` |
| Allergy Verification Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.verificationStatus` |
| Allergy Verification Status | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/allergyintolerance-verification` |
| Allergy Verification Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bmhcgxjlske7hmd4397m7ijl` |
| Allergy Onset Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Onset Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Onset Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-onset-date` |
| Allergy Onset Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.onsetDateTime` |
| Allergy Onset Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vsb9m1e7vmm8sz58hm9qaiay` |
| Allergy Recorded Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Recorded Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Recorded Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-recorded-date` |
| Allergy Recorded Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.recordedDate` |
| Allergy Recorded Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bqv6o5zjrh3cidr9xjahyx2y` |
| Last Reaction Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Last Reaction Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Last Reaction Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/last-reaction-date` |
| Last Reaction Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.lastOccurrence` |
| Last Reaction Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dxfyi0b20o30te7jjq8btf6w` |
| Allergen (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergen (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergen (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergen` |
| Allergen (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Allergen (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.code` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Allergen Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergen Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergen-code` |
| Allergen Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.code` |
| Allergen Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Allergen Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Allergen Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-r5ex1j6m9yr3w6paunqj1a02` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Allergy Reaction | `dcterms:publisher` | `https://axius-sdc.com` |
| Allergy Reaction | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Allergy Reaction | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/allergy-reaction` |
| Allergy Reaction | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction` |
| Allergy Reaction | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lzssn85tddy96vq796jhpndt` |
| Reaction Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Reaction Description | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Reaction Description | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/reaction-description` |
| Reaction Description | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction.description` |
| Reaction Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-byizx3nh3rzaeks1wf7x1m28` |
| Reaction Severity | `dcterms:publisher` | `https://axius-sdc.com` |
| Reaction Severity | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Reaction Severity | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/reaction-severity` |
| Reaction Severity | `skos:closeMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction.severity` |
| Reaction Severity | `skos:exactMatch` | `http://hl7.org/fhir/reaction-event-severity` |
| Reaction Severity | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rlachb9hs2lhj05pvkb1oab5` |
| Reaction Onset | `dcterms:publisher` | `https://axius-sdc.com` |
| Reaction Onset | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Reaction Onset | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/reaction-onset` |
| Reaction Onset | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction.onset` |
| Reaction Onset | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t5b4k4qm91gu6f328pfdoa22` |
| Exposure Route (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Exposure Route (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Exposure Route (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/exposure-route` |
| Exposure Route (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Exposure Route (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction.exposureRoute` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Exposure Route Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Exposure Route Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/exposure-route-code` |
| Exposure Route Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction.exposureRoute` |
| Exposure Route Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Exposure Route Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Exposure Route Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-iobq9jihvgj5u5i39uipuwbn` |
| Reaction Manifestation (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Reaction Manifestation (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Reaction Manifestation (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/reaction-manifestation` |
| Reaction Manifestation (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Reaction Manifestation (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction.manifestation` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Reaction Manifestation Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Reaction Manifestation Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/reaction-manifestation-code` |
| Reaction Manifestation Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction.manifestation` |
| Reaction Manifestation Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Reaction Manifestation Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Reaction Manifestation Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-opvy8aukwkwinjocm5cwwfa5` |
| Reaction Substance (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Reaction Substance (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Reaction Substance (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/reaction-substance` |
| Reaction Substance (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Reaction Substance (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction.substance` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Reaction Substance Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Reaction Substance Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/reaction-substance-code` |
| Reaction Substance Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/allergyintolerance-definitions.html#AllergyIntolerance.reaction.substance` |
| Reaction Substance Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Reaction Substance Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Reaction Substance Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eo9ptysefvvbeufhoqwisgjb` |
| Condition | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Condition | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/condition` |
| Condition | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Condition` |
| Condition | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ukojkiin8dhm5z9ch2bnxf2b` |
| Condition Category | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Category | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Condition Category | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/condition-category` |
| Condition Category | `skos:closeMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.category` |
| Condition Category | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/condition-category` |
| Condition Category | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lh9wl322t27liogmn5eiplv0` |
| Condition Clinical Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Clinical Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Condition Clinical Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/condition-clinical-status` |
| Condition Clinical Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.clinicalStatus` |
| Condition Clinical Status | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/condition-clinical` |
| Condition Clinical Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t9hihjjlpyognm35in9b4zem` |
| Condition Verification Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Verification Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Condition Verification Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/condition-verification-status` |
| Condition Verification Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.verificationStatus` |
| Condition Verification Status | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/condition-ver-status` |
| Condition Verification Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dnrmz7hasy6rpajbqz6mzqp5` |
| Abatement Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Abatement Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Abatement Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/abatement-date` |
| Abatement Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.abatementDateTime` |
| Abatement Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nm3mgan9439kf90rnv6nl7te` |
| Onset Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Onset Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Onset Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/onset-date` |
| Onset Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.onsetDateTime` |
| Onset Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dk1gtajq2zff7gx324j93m86` |
| Condition Severity (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Severity (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Condition Severity (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/condition-severity` |
| Condition Severity (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Condition Severity (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.severity` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Condition Severity Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Severity Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/condition-severity-code` |
| Condition Severity Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.severity` |
| Condition Severity Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Condition Severity Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Condition Severity Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fcdvbwgijq5jou7rp1k04szz` |
| Diagnosis (ICD-10-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis (ICD-10-CM) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Diagnosis (ICD-10-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diagnosis-icd10cm` |
| Diagnosis (ICD-10-CM) | `skos:closeMatch` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Diagnosis (ICD-10-CM) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.code` |
| Code System: ICD-10-CM | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: ICD-10-CM | `dcterms:source` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Code System: ICD-10-CM | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-icd10cm` |
| Code System: ICD-10-CM | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Diagnosis Code (ICD-10-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis Code (ICD-10-CM) | `dcterms:source` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Diagnosis Code (ICD-10-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diagnosis-icd10cm-code` |
| Diagnosis Code (ICD-10-CM) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.code` |
| Diagnosis Code (ICD-10-CM) | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Diagnosis Code (ICD-10-CM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gnssdkny454dgbykbs16wuew` |
| Diagnosis (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Diagnosis (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diagnosis-snomed` |
| Diagnosis (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Diagnosis (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.code` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Diagnosis Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diagnosis-snomed-code` |
| Diagnosis Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.code` |
| Diagnosis Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Diagnosis Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Diagnosis Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t6homk7yna5gg6nh1z82u4dk` |
| Encounter | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter` |
| Encounter | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Encounter` |
| Encounter | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixcrz5r9vrahm36nzsol3xea` |
| Encounter Class | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Class | `dcterms:source` | `http://terminology.hl7.org/` |
| Encounter Class | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-class` |
| Encounter Class | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.class` |
| Encounter Class | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActCode` |
| Encounter Class | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-mogsgkfr8h5hk18jvqysphpq` |
| Encounter Priority | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Priority | `dcterms:source` | `http://terminology.hl7.org/` |
| Encounter Priority | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-priority` |
| Encounter Priority | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.priority` |
| Encounter Priority | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActPriority` |
| Encounter Priority | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bf6yz6dbpwau77wke189an3c` |
| Encounter Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-status` |
| Encounter Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.status` |
| Encounter Status | `skos:exactMatch` | `http://hl7.org/fhir/encounter-status` |
| Encounter Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yq8mjdfv83g4l9cauiwxaxof` |
| Encounter Length | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Length | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter Length | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-length` |
| Encounter Length | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.length` |
| Encounter Length | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y2bp9qn2xbkpnyj4el6489bs` |
| Encounter End | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter End | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter End | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-end` |
| Encounter End | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.period.end` |
| Encounter End | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-q2f2ixoppgfbosedoytboovu` |
| Encounter Start | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Start | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter Start | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-start` |
| Encounter Start | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.period.start` |
| Encounter Start | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n0nymcfopzp382j8kc6t3k2z` |
| Encounter Reason (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Reason (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter Reason (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-reason` |
| Encounter Reason (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Encounter Reason (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.reasonCode` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Encounter Reason Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Reason Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-reason-code` |
| Encounter Reason Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.reasonCode` |
| Encounter Reason Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Encounter Reason Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Encounter Reason Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-s7dqnduaqd5go4ztlhai2uzs` |
| Hospitalization | `dcterms:publisher` | `https://axius-sdc.com` |
| Hospitalization | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Hospitalization | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/hospitalization` |
| Hospitalization | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.hospitalization` |
| Hospitalization | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qxa1fowjvhe4zb0xbdxnf4yc` |
| Admit Source | `dcterms:publisher` | `https://axius-sdc.com` |
| Admit Source | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Admit Source | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/admit-source` |
| Admit Source | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.hospitalization.admitSource` |
| Admit Source | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/admit-source` |
| Admit Source | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-d6fhrxgpx4yrg0wyqu29ryvv` |
| Discharge Disposition | `dcterms:publisher` | `https://axius-sdc.com` |
| Discharge Disposition | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Discharge Disposition | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/discharge-disposition` |
| Discharge Disposition | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.hospitalization.dischargeDisposition` |
| Discharge Disposition | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/discharge-disposition` |
| Discharge Disposition | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t7iyfamfrzty7ev82gl15w4g` |
| Immunization | `dcterms:publisher` | `https://axius-sdc.com` |
| Immunization | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Immunization | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/immunization` |
| Immunization | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Immunization` |
| Immunization | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ag2xcojcsp0cjpp4mg61d4z4` |
| Is Subpotent | `dcterms:publisher` | `https://axius-sdc.com` |
| Is Subpotent | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Is Subpotent | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/is-subpotent` |
| Is Subpotent | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.isSubpotent` |
| Is Subpotent | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-cblq6fw17gdebo4u89638rn9` |
| Primary Source Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Primary Source Indicator | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Primary Source Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/primary-source-indicator` |
| Primary Source Indicator | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.primarySource` |
| Primary Source Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dl0yuhqlvong2f9mg97qe6wh` |
| Immunization Note | `dcterms:publisher` | `https://axius-sdc.com` |
| Immunization Note | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Immunization Note | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/immunization-note` |
| Immunization Note | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.note` |
| Immunization Note | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j290nt621ogkt7tij4n0zvrb` |
| Vaccine Lot Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Vaccine Lot Number | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Vaccine Lot Number | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/vaccine-lot-number` |
| Vaccine Lot Number | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.lotNumber` |
| Vaccine Lot Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-i2k80lxxr5ssbeyq9pqgap68` |
| Immunization Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Immunization Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Immunization Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/immunization-status` |
| Immunization Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.status` |
| Immunization Status | `skos:exactMatch` | `http://hl7.org/fhir/event-status` |
| Immunization Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-wz2ztz6z0roqalkr73gnittf` |
| Injection Site | `dcterms:publisher` | `https://axius-sdc.com` |
| Injection Site | `dcterms:source` | `http://terminology.hl7.org/` |
| Injection Site | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/injection-site` |
| Injection Site | `skos:closeMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.site` |
| Injection Site | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActSite` |
| Injection Site | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j21zdcjveksechh7xkq9k4u0` |
| Dose Quantity Administered | `dcterms:publisher` | `https://axius-sdc.com` |
| Dose Quantity Administered | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Dose Quantity Administered | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/dose-quantity-administered` |
| Dose Quantity Administered | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.doseQuantity` |
| Dose Quantity Administered | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-e93mljwgnily73scayhppm4d` |
| Vaccination Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Vaccination Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Vaccination Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/vaccination-date` |
| Vaccination Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.occurrenceDateTime` |
| Vaccination Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o1ka7yz3zw4yaoukwmj6cf8i` |
| Vaccine Expiration Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Vaccine Expiration Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Vaccine Expiration Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/vaccine-expiration-date` |
| Vaccine Expiration Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.expirationDate` |
| Vaccine Expiration Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-c47z5yt391o2hda5bxzp3p3g` |
| Administration Route (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Administration Route (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Administration Route (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/administration-route` |
| Administration Route (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Administration Route (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.route` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Administration Route Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Administration Route Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/administration-route-code` |
| Administration Route Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.route` |
| Administration Route Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Administration Route Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Administration Route Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hv6z7sv804aji7v31blv07z8` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Immunization Reaction | `dcterms:publisher` | `https://axius-sdc.com` |
| Immunization Reaction | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Immunization Reaction | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/immunization-reaction` |
| Immunization Reaction | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.reaction` |
| Immunization Reaction | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-wsk7y0ikqh55nvy131mt3ai6` |
| Immunization Reaction Reported | `dcterms:publisher` | `https://axius-sdc.com` |
| Immunization Reaction Reported | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Immunization Reaction Reported | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/immunization-reaction-reported` |
| Immunization Reaction Reported | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.reaction.reported` |
| Immunization Reaction Reported | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rzdgsf3aabgupdv5im1mp7yc` |
| Immunization Reaction Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Immunization Reaction Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Immunization Reaction Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/immunization-reaction-date` |
| Immunization Reaction Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.reaction.date` |
| Immunization Reaction Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tpf17twjzzopqhl2sd9ojtjf` |
| Vaccine (CVX) | `dcterms:publisher` | `https://axius-sdc.com` |
| Vaccine (CVX) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Vaccine (CVX) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/vaccine` |
| Vaccine (CVX) | `skos:closeMatch` | `http://hl7.org/fhir/sid/cvx` |
| Vaccine (CVX) | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.vaccineCode` |
| Code System: CVX | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: CVX | `dcterms:source` | `http://hl7.org/fhir/sid/cvx` |
| Code System: CVX | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-cvx` |
| Code System: CVX | `skos:exactMatch` | `http://hl7.org/fhir/sid/cvx` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Vaccine Code (CVX) | `dcterms:publisher` | `https://axius-sdc.com` |
| Vaccine Code (CVX) | `dcterms:source` | `http://hl7.org/fhir/sid/cvx` |
| Vaccine Code (CVX) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/vaccine-code` |
| Vaccine Code (CVX) | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.vaccineCode` |
| Vaccine Code (CVX) | `skos:exactMatch` | `http://hl7.org/fhir/sid/cvx` |
| Vaccine Code (CVX) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jyl4aeg6gpv2exktsxim1ubb` |
| Vaccine Protocol | `dcterms:publisher` | `https://axius-sdc.com` |
| Vaccine Protocol | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Vaccine Protocol | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/vaccine-protocol` |
| Vaccine Protocol | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.protocolApplied` |
| Vaccine Protocol | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o87o6jy035jshtx4w32jk6rj` |
| Protocol Series Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Protocol Series Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Protocol Series Name | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/protocol-series-name` |
| Protocol Series Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.protocolApplied.series` |
| Protocol Series Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ety8lxn8eu72odk3hmmu5pb9` |
| Dose Number in Series | `dcterms:publisher` | `https://axius-sdc.com` |
| Dose Number in Series | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Dose Number in Series | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/dose-number-in-series` |
| Dose Number in Series | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.protocolApplied.doseNumber_x_` |
| Dose Number in Series | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dstof9401vy5l9w56hnkbgdy` |
| Doses in Series | `dcterms:publisher` | `https://axius-sdc.com` |
| Doses in Series | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Doses in Series | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/doses-in-series` |
| Doses in Series | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.protocolApplied.seriesDoses_x_` |
| Doses in Series | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tpwvzk5erc7ch0dx2970j53i` |
| Target Disease (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Target Disease (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Target Disease (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/target-disease` |
| Target Disease (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Target Disease (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.protocolApplied.targetDisease` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Target Disease Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Target Disease Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/target-disease-code` |
| Target Disease Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/immunization-definitions.html#Immunization.protocolApplied.targetDisease` |
| Target Disease Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Target Disease Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Target Disease Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l3a552ow4oot6h2yug26dwlv` |
| Medication Order | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication Order | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Medication Order | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/medication-order` |
| Medication Order | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/MedicationRequest` |
| Medication Order | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-c55wstv55y7a1zy9vjkwlrge` |
| Prescriber Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Prescriber Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Prescriber Reference | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/prescriber-reference` |
| Prescriber Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.requester` |
| Prescriber Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hmb8oyylyydfsasazlst57ld` |
| Dose Frequency | `dcterms:publisher` | `https://axius-sdc.com` |
| Dose Frequency | `dcterms:source` | `http://terminology.hl7.org/` |
| Dose Frequency | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/dose-frequency` |
| Dose Frequency | `skos:closeMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.dosageInstruction.timing` |
| Dose Frequency | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-GTSAbbreviation` |
| Dose Frequency | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-apkkhqmahmwpz5lr2epwnn64` |
| Medication Request Intent | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication Request Intent | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Medication Request Intent | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/medication-request-intent` |
| Medication Request Intent | `skos:closeMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.intent` |
| Medication Request Intent | `skos:exactMatch` | `http://hl7.org/fhir/CodeSystem/medicationrequest-intent` |
| Medication Request Intent | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-c7ignw6ghutsdxdetpinbknb` |
| Medication Request Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication Request Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Medication Request Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/medication-request-status` |
| Medication Request Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.status` |
| Medication Request Status | `skos:exactMatch` | `http://hl7.org/fhir/CodeSystem/medicationrequest-status` |
| Medication Request Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gbc75akfxtdpd88ao97ulf3o` |
| Dose Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Dose Quantity | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Dose Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/dose-quantity` |
| Dose Quantity | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.dosageInstruction` |
| Dose Quantity | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xiczzydlusxkx0ko6zta2xyl` |
| Prescription Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Prescription Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Prescription Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/prescription-date` |
| Prescription Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.authoredOn` |
| Prescription Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bnckpkdal5y0jxawc9y0pl4f` |
| Dispense Request | `dcterms:publisher` | `https://axius-sdc.com` |
| Dispense Request | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Dispense Request | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/dispense-request` |
| Dispense Request | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.dispenseRequest` |
| Dispense Request | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-k42d6n6a6vcadtauro9ujzu7` |
| Substitution Allowed | `dcterms:publisher` | `https://axius-sdc.com` |
| Substitution Allowed | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Substitution Allowed | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/substitution-allowed` |
| Substitution Allowed | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.substitution.allowedBoolean` |
| Substitution Allowed | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-unmfutdga3ub012rloswqfkh` |
| Dispense Quantity | `dcterms:publisher` | `https://axius-sdc.com` |
| Dispense Quantity | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Dispense Quantity | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/dispense-quantity` |
| Dispense Quantity | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.dispenseRequest.quantity` |
| Dispense Quantity | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-no7p1utoc7kq4zmo4mywmi0j` |
| Number of Refills | `dcterms:publisher` | `https://axius-sdc.com` |
| Number of Refills | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Number of Refills | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/number-of-refills` |
| Number of Refills | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.dispenseRequest.numberOfRepeatsAllowed` |
| Number of Refills | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-f0l4subvsigudb5gw2z4s1vp` |
| Medication Route (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication Route (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Medication Route (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/medication-route` |
| Medication Route (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Medication Route (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.dosageInstruction.route` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Medication Route Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication Route Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/medication-route-code` |
| Medication Route Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.dosageInstruction.route` |
| Medication Route Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Medication Route Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Medication Route Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y1pvsbq8ty6p76fx1uuxcrjo` |
| Medication (RxNorm) | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication (RxNorm) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Medication (RxNorm) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/medication` |
| Medication (RxNorm) | `skos:closeMatch` | `http://www.nlm.nih.gov/research/umls/rxnorm` |
| Medication (RxNorm) | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.medicationCodeableConcept` |
| Code System: RxNorm | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: RxNorm | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-rxnorm` |
| Code System: RxNorm | `dcterms:source` | `http://www.nlm.nih.gov/research/umls/rxnorm` |
| Code System: RxNorm | `skos:exactMatch` | `http://www.nlm.nih.gov/research/umls/rxnorm` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Medication Code (RxNorm) | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication Code (RxNorm) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/medication-code` |
| Medication Code (RxNorm) | `dcterms:source` | `http://www.nlm.nih.gov/research/umls/rxnorm` |
| Medication Code (RxNorm) | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.medicationCodeableConcept` |
| Medication Code (RxNorm) | `skos:exactMatch` | `http://www.nlm.nih.gov/research/umls/rxnorm` |
| Medication Code (RxNorm) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zqexmpkhlcav2aeg6lgaxzle` |
| Patient | `dcterms:publisher` | `https://axius-sdc.com` |
| Patient | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Patient | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/patient` |
| Patient | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Patient` |
| Patient | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fvm2z64bw613rpv4v8zbt1ru` |
| Deceased Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Deceased Indicator | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Deceased Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/deceased-indicator` |
| Deceased Indicator | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.deceasedBoolean` |
| Deceased Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dw20tfw9y0qzzwlyhp6d9koz` |
| Language Preferred | `dcterms:publisher` | `https://axius-sdc.com` |
| Language Preferred | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Language Preferred | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/language-preferred` |
| Language Preferred | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.communication.preferred` |
| Language Preferred | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-he241ao4v19o3g7n4439snm7` |
| Multiple Birth Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Multiple Birth Indicator | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Multiple Birth Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/multiple-birth-indicator` |
| Multiple Birth Indicator | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.multipleBirthBoolean` |
| Multiple Birth Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-h74tkffye8tpmlmcz0ib70y8` |
| General Practitioner Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| General Practitioner Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| General Practitioner Reference | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/general-practitioner-reference` |
| General Practitioner Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.generalPractitioner` |
| General Practitioner Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-g3je4akjobeve11anr2zctpk` |
| Managing Organization Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Managing Organization Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Managing Organization Reference | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/managing-organization-reference` |
| Managing Organization Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.managingOrganization` |
| Managing Organization Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-oc3nx8axdav4s2lc7p5y2ece` |
| Medical Record Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Medical Record Number | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Medical Record Number | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/medical-record-number` |
| Medical Record Number | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.identifier` |
| Medical Record Number | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v2-0203#MR` |
| Medical Record Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-z555cnj6m1wqiihtcw45778d` |
| Marital Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Marital Status | `dcterms:source` | `http://terminology.hl7.org/` |
| Marital Status | `dcterms:identifier` | `https://axius-sdc.com/library/default/marital-status` |
| Marital Status | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25188` |
| Marital Status | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-MaritalStatus` |
| Multiple Birth Order | `dcterms:publisher` | `https://axius-sdc.com` |
| Multiple Birth Order | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Multiple Birth Order | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/multiple-birth-order` |
| Multiple Birth Order | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.multipleBirthInteger` |
| Multiple Birth Order | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-cg6flcs3rfubw683jrvmqedt` |
| Deceased Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Deceased Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Deceased Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/deceased-date` |
| Deceased Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.deceasedDateTime` |
| Deceased Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rqpcsr1pv41osf7sxwlr7lix` |
| Contact Point | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Point | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-point` |
| Contact Point | `dcterms:source` | `https://schema.org/` |
| Contact Point | `skos:exactMatch` | `https://schema.org/ContactPoint` |
| Contact Point | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pet65c3gbwhp7j2fyiglwv5q` |
| Website URL | `dcterms:publisher` | `https://axius-sdc.com` |
| Website URL | `dcterms:identifier` | `https://axius-sdc.com/library/default/website-url` |
| Website URL | `dcterms:source` | `https://schema.org/` |
| Website URL | `skos:exactMatch` | `https://schema.org/url` |
| Website URL | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t4fl1c1qbhmgyem3fczjdq16` |
| Email Address | `dcterms:publisher` | `https://axius-sdc.com` |
| Email Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/email-address` |
| Email Address | `dcterms:source` | `https://www.rfc-editor.org/rfc/rfc5321` |
| Email Address | `skos:exactMatch` | `https://schema.org/email` |
| Email Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uvl0tla5aocdzsdrby589b6l` |
| Fax Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Fax Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Fax Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/fax-number` |
| Fax Number | `skos:exactMatch` | `https://schema.org/faxNumber` |
| Fax Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hzpld81b2ddnp5qywombgpls` |
| Phone Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Phone Number | `dcterms:source` | `https://www.itu.int/rec/T-REC-E.164` |
| Phone Number | `dcterms:identifier` | `https://axius-sdc.com/library/default/phone-number` |
| Phone Number | `skos:exactMatch` | `https://schema.org/telephone` |
| Phone Number | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ma9dwgbrvprfyypwldni2qfx` |
| Contact Method | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Method | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Method | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-method` |
| Contact Method | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-system` |
| Contact Method | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tf5wlywn6meurn6o1sz8yuaq` |
| Contact Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Contact Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Contact Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/contact-use` |
| Contact Use | `skos:exactMatch` | `http://hl7.org/fhir/contact-point-use` |
| Contact Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-klgho4tqvbu5iyt6zzx1ioi9` |
| International Address | `dcterms:publisher` | `https://axius-sdc.com` |
| International Address | `dcterms:identifier` | `https://axius-sdc.com/library/default/international-address` |
| International Address | `dcterms:source` | `https://schema.org/` |
| International Address | `skos:exactMatch` | `https://schema.org/PostalAddress` |
| International Address | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-g6qfe9l84vekq97kgvhtu3qw` |
| Address (Line 1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 1) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-1` |
| Address (Line 1) | `dcterms:source` | `https://schema.org/` |
| Address (Line 1) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 1) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l338k7nlvnq2am0owa19yxfc` |
| Address (Line 2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Address (Line 2) | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-line-2` |
| Address (Line 2) | `dcterms:source` | `https://schema.org/` |
| Address (Line 2) | `skos:exactMatch` | `https://schema.org/streetAddress` |
| Address (Line 2) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ek5h6dsqpd9kz0l4mcckmxpt` |
| City Name | `dcterms:publisher` | `https://axius-sdc.com` |
| City Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/city-name` |
| City Name | `dcterms:source` | `https://schema.org/` |
| City Name | `skos:exactMatch` | `https://schema.org/addressLocality` |
| City Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-baebb08pvhi38pqoerynir1w` |
| Postal Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Postal Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/postal-code` |
| Postal Code | `dcterms:source` | `https://schema.org/` |
| Postal Code | `skos:exactMatch` | `https://schema.org/postalCode` |
| Postal Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kgbwgi00bhxyyt176bsmulf0` |
| Region Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Region Name | `dcterms:identifier` | `https://axius-sdc.com/library/default/region-name` |
| Region Name | `dcterms:source` | `https://schema.org/` |
| Region Name | `skos:exactMatch` | `https://schema.org/addressRegion` |
| Region Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fvgk640ozbukdci5swd6wytt` |
| Address Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Address Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Address Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/address-use` |
| Address Use | `skos:exactMatch` | `http://hl7.org/fhir/address-use` |
| Address Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-offwpyuzrbirkryvvbzqqg31` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Person (Demographics) | `dcterms:publisher` | `https://axius-sdc.com` |
| Person (Demographics) | `dcterms:identifier` | `https://axius-sdc.com/library/default/person-demographics` |
| Person (Demographics) | `dcterms:source` | `https://schema.org/` |
| Person (Demographics) | `skos:exactMatch` | `https://schema.org/Person` |
| Administrative Gender | `dcterms:publisher` | `https://axius-sdc.com` |
| Administrative Gender | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Administrative Gender | `dcterms:identifier` | `https://axius-sdc.com/library/default/administrative-gender` |
| Administrative Gender | `skos:exactMatch` | `http://hl7.org/fhir/administrative-gender` |
| Administrative Gender | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tnyh2ude3db9smwfin0vai5h` |
| Country Code ISO 3166 | `dcterms:publisher` | `https://axius-sdc.com` |
| Country Code ISO 3166 | `dcterms:source` | `https://www.iso.org/iso-3166-country-codes.html` |
| Country Code ISO 3166 | `dcterms:identifier` | `https://axius-sdc.com/library/default/country-code-iso-3166` |
| Country Code ISO 3166 | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20108` |
| Country Code ISO 3166 | `skos:exactMatch` | `https://schema.org/addressCountry` |
| Country Code ISO 3166 | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qm8gmwfrxqbisqbm0fgd4nyz` |
| Language Code | `dcterms:publisher` | `https://axius-sdc.com` |
| Language Code | `dcterms:source` | `https://www.iso.org/iso-639-language-code` |
| Language Code | `dcterms:identifier` | `https://axius-sdc.com/library/default/language-code` |
| Language Code | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C16779` |
| Language Code | `skos:exactMatch` | `https://schema.org/inLanguage` |
| Language Code | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w7t802u535su9576z02uw71o` |
| Date of Birth | `dcterms:publisher` | `https://axius-sdc.com` |
| Date of Birth | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-of-birth` |
| Date of Birth | `dcterms:source` | `https://schema.org/` |
| Date of Birth | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68615` |
| Date of Birth | `skos:exactMatch` | `https://schema.org/birthDate` |
| Full Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Full Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/full-name-person` |
| Full Name (Person) | `dcterms:source` | `https://schema.org/` |
| Full Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q1071027` |
| Full Name (Person) | `skos:exactMatch` | `https://schema.org/Person` |
| Full Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gwpvlduwrtpog4kpidaenshn` |
| Given Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Given Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/given-name-person` |
| Given Name (Person) | `dcterms:source` | `https://schema.org/` |
| Given Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q202444` |
| Given Name (Person) | `skos:exactMatch` | `https://schema.org/givenName` |
| Given Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kfyzf8u8gdafcpt5kfh2qg3q` |
| Middle Name (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Middle Name (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/middle-name-person` |
| Middle Name (Person) | `dcterms:source` | `https://schema.org/` |
| Middle Name (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q245025` |
| Middle Name (Person) | `skos:exactMatch` | `https://schema.org/additionalName` |
| Middle Name (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-oit0ueglhjfcyq80z22kl2z3` |
| Name Prefix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Prefix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-prefix` |
| Name Prefix | `dcterms:source` | `https://schema.org/` |
| Name Prefix | `skos:exactMatch` | `https://schema.org/honorificPrefix` |
| Name Prefix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-u9x2b6frfi0rbydeoncijfp1` |
| Name Suffix | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Suffix | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-suffix` |
| Name Suffix | `dcterms:source` | `https://schema.org/` |
| Name Suffix | `skos:exactMatch` | `https://schema.org/honorificSuffix` |
| Name Suffix | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zldtbpvyouzi7t1dorc07rb3` |
| Surname (Person) | `dcterms:publisher` | `https://axius-sdc.com` |
| Surname (Person) | `dcterms:identifier` | `https://axius-sdc.com/library/default/surname-person` |
| Surname (Person) | `dcterms:source` | `https://schema.org/` |
| Surname (Person) | `skos:closeMatch` | `http://www.wikidata.org/entity/Q101352` |
| Surname (Person) | `skos:exactMatch` | `https://schema.org/familyName` |
| Surname (Person) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-v8jgjo2sml12jo7zrb8swoxi` |
| Name Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Name Use | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Name Use | `dcterms:identifier` | `https://axius-sdc.com/library/default/name-use` |
| Name Use | `skos:exactMatch` | `http://hl7.org/fhir/name-use` |
| Name Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zlg3riiu515tsg0mdkx5brkc` |
| Vital Signs Panel | `dcterms:publisher` | `https://axius-sdc.com` |
| Vital Signs Panel | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Vital Signs Panel | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/vital-signs-panel` |
| Vital Signs Panel | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Observation` |
| Vital Signs Panel | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ns80igp59zsj4arcyys2dkhj` |
| Observation Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-status` |
| Observation Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.status` |
| Observation Status | `skos:exactMatch` | `http://hl7.org/fhir/observation-status` |
| Observation Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uulveklfu0gsttxdsb5w0daw` |
| Body Height | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Height | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Height | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-height` |
| Body Height | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Body Height | `skos:exactMatch` | `https://loinc.org/8302-2/` |
| Body Height | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pzy0atizoa3c2uf5qk4q7wbp` |
| Body Mass Index | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Mass Index | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Mass Index | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/bmi` |
| Body Mass Index | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Body Mass Index | `skos:exactMatch` | `https://loinc.org/39156-5/` |
| Body Mass Index | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-st9s8xlbfyokx2iprntbb74f` |
| Body Temperature | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Temperature | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Temperature | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-temperature` |
| Body Temperature | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Body Temperature | `skos:exactMatch` | `https://loinc.org/8310-5/` |
| Body Temperature | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tulo1e75g24qf8xon4am5f46` |
| Body Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Weight | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Weight | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-weight` |
| Body Weight | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Body Weight | `skos:exactMatch` | `https://loinc.org/29463-7/` |
| Body Weight | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-csn8ymg324e0upnzku4aqrcq` |
| Heart Rate | `dcterms:publisher` | `https://axius-sdc.com` |
| Heart Rate | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Heart Rate | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/heart-rate` |
| Heart Rate | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Heart Rate | `skos:exactMatch` | `https://loinc.org/8867-4/` |
| Heart Rate | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uzyj5sccijtoppr2j7szwaj0` |
| Oxygen Saturation | `dcterms:publisher` | `https://axius-sdc.com` |
| Oxygen Saturation | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Oxygen Saturation | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/oxygen-saturation` |
| Oxygen Saturation | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Oxygen Saturation | `skos:exactMatch` | `https://loinc.org/2708-6/` |
| Oxygen Saturation | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j2xic9nkngxcfhc137pvjbn5` |
| Respiratory Rate | `dcterms:publisher` | `https://axius-sdc.com` |
| Respiratory Rate | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Respiratory Rate | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/respiratory-rate` |
| Respiratory Rate | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Respiratory Rate | `skos:exactMatch` | `https://loinc.org/9279-1/` |
| Respiratory Rate | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uh4kgd9s7bk1403mkz1uuasn` |
| Observation Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Date Time | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-datetime` |
| Observation Date Time | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.effectiveDateTime` |
| Observation Date Time | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uwjplwpntsl4q5mckbmb7lhi` |
| Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Blood Pressure | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/blood-pressure` |
| Blood Pressure | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Observation` |
| Blood Pressure | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-aswsw3sct9bnujj53q8g2r5s` |
| Observation Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-status` |
| Observation Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.status` |
| Observation Status | `skos:exactMatch` | `http://hl7.org/fhir/observation-status` |
| Observation Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uulveklfu0gsttxdsb5w0daw` |
| Diastolic Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Diastolic Blood Pressure | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Diastolic Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diastolic-blood-pressure` |
| Diastolic Blood Pressure | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Diastolic Blood Pressure | `skos:exactMatch` | `https://loinc.org/8462-4/` |
| Diastolic Blood Pressure | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-on1yxktbzpmkrfha7vpy818u` |
| Systolic Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Systolic Blood Pressure | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Systolic Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/systolic-blood-pressure` |
| Systolic Blood Pressure | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Systolic Blood Pressure | `skos:exactMatch` | `https://loinc.org/8480-6/` |
| Systolic Blood Pressure | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zcqdrf41l9x3y4kc6kk472zi` |
| Observation Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Date Time | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-datetime` |
| Observation Date Time | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.effectiveDateTime` |
| Observation Date Time | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uwjplwpntsl4q5mckbmb7lhi` |
| Body Site (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Site (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Site (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-site` |
| Body Site (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Body Site (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.bodySite` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Body Site Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Site Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-site-code` |
| Body Site Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.bodySite` |
| Body Site Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Body Site Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Body Site Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w8ydi05lu9vtr4cxwvnc7cs5` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "Healthcare Record 4.4.0" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-dcsd8bxr8a6lzcptwwyms44t.xsd)
- Example instance (dm-dcsd8bxr8a6lzcptwwyms44t.xml)
- HTML documentation (dm-dcsd8bxr8a6lzcptwwyms44t.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"Healthcare Record 4.4.0" SDC4 schema (dm-dcsd8bxr8a6lzcptwwyms44t.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"Healthcare Record 4.4.0" schema (dm-dcsd8bxr8a6lzcptwwyms44t.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "Healthcare Record 4.4.0" SDC4 schema (dm-dcsd8bxr8a6lzcptwwyms44t.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "Healthcare Record 4.4.0" data model (dm-dcsd8bxr8a6lzcptwwyms44t.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-dcsd8bxr8a6lzcptwwyms44t.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-dcsd8bxr8a6lzcptwwyms44t.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-dcsd8bxr8a6lzcptwwyms44t.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-dcsd8bxr8a6lzcptwwyms44t.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-dcsd8bxr8a6lzcptwwyms44t.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
